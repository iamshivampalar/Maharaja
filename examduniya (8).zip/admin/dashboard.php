<?php
/**
 * ExamDuniya - Admin Control Panel Dashboard
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Enforce Admin or Dev roles
check_role(['Admin', 'Developer']);

// Handle job insertions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_job'])) {
    $title = trim($_POST['title']);
    $org = trim($_POST['organization']);
    $post = trim($_POST['post_name']);
    $vacs = (int)($_POST['total_vacancies'] ?? 100);
    $qual = trim($_POST['qualification']);
    $end_date = $_POST['end_date'] ?? date('Y-m-d', strtotime('+30 days'));
    $desc = trim($_POST['description'] ?? 'Announcement Details');
    
    // Auto slug generator
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
    
    try {
        $stmt_insert = $pdo->prepare("INSERT INTO `jobs` (`title`, `slug`, `organization`, `post_name`, `total_vacancies`, `qualification`, `start_date`, `end_date`, `description`, `status`) VALUES (:title, :slug, :org, :post, :vacs, :qual, NOW(), :end, :desc, 'Active')");
        $stmt_insert->execute([
            ':title' => $title,
            ':slug' => $slug,
            ':org' => $org,
            ':post' => $post,
            ':vacs' => $vacs,
            ':qual' => $qual,
            ':end' => $end_date,
            ':desc' => $desc
        ]);
        
        $broadcast_success = true;
        $broadcast_status_msg = '';
        
        if (isset($_POST['broadcast_telegram']) && $_POST['broadcast_telegram'] == 1) {
            $token = $_SESSION['broadcast_settings']['telegram_bot_token'] ?? '';
            $chat_id = $_SESSION['broadcast_settings']['telegram_channel_id'] ?? '';
            $template = $_SESSION['broadcast_settings']['telegram_template'] ?? '';
            
            if (!empty($token) && !empty($chat_id) && !empty($template)) {
                $apply_url = BASE_URL . "job-detail.php?slug=" . $slug;
                
                $msg = str_replace(
                    ['{title}', '{organization}', '{post_name}', '{total_vacancies}', '{end_date}', '{apply_url}'],
                    [$title, $org, $post, number_format($vacs), date('d-M-Y', strtotime($end_date)), $apply_url],
                    $template
                );
                
                $result = send_telegram_message($token, $chat_id, $msg);
                
                if ($result['success']) {
                    $log = [
                        'id' => rand(1000, 9999),
                        'title' => 'Broadcast: ' . $title,
                        'channel' => 'Telegram Channel',
                        'status' => 'Delivered',
                        'recipients' => s($chat_id),
                        'sent_at' => date('Y-m-d H:i:s')
                    ];
                    $_SESSION['broadcast_logs'] = array_merge([$log], $_SESSION['broadcast_logs'] ?? []);
                } else {
                    $broadcast_success = false;
                    $broadcast_status_msg = $result['error'];
                    $log = [
                        'id' => rand(1000, 9999),
                        'title' => 'Broadcast Failed: ' . $title,
                        'channel' => 'Telegram Channel',
                        'status' => 'Failed',
                        'recipients' => s($chat_id) . ' | Error: ' . s($result['error']),
                        'sent_at' => date('Y-m-d H:i:s')
                    ];
                    $_SESSION['broadcast_logs'] = array_merge([$log], $_SESSION['broadcast_logs'] ?? []);
                }
            }
        }
        
        if ($broadcast_success) {
            set_flash_message('success', 'Job Vacancy published and broadcasted successfully to Telegram!');
        } else {
            set_flash_message('warning', 'Job Vacancy published, but Telegram Broadcast Failed: ' . s($broadcast_status_msg));
        }
    } catch (Exception $e) {
        set_flash_message('danger', 'Error adding job alert: ' . $e->getMessage());
    }
}

// Fetch all jobs
$stmt_admin_jobs = $pdo->query("SELECT * FROM `jobs` ORDER BY `created_at` DESC");
$admin_jobs = $stmt_admin_jobs->fetchAll();

render_header("Admin Office Panel");
?>

<div class="row mb-4 text-dark">
    <div class="col-12">
        <h2 class="fw-bold font-sans text-dark tracking-tight mb-2"><i class="feather-sliders text-primary me-2"></i>Admin Operations HUD</h2>
        <p class="text-muted">Broadcast job alerts, manage admit card updates, and monitor enrollment statistics.</p>
    </div>
</div>

<div class="row g-4 mb-5 text-dark">
    <!-- Admin stats ribbons -->
    <div class="col-md-3">
        <div class="p-3.5 bg-white border rounded shadow-sm d-flex align-items-center">
            <span class="p-3 bg-primary bg-opacity-10 text-primary rounded-circle me-3"><i class="feather-users fs-5"></i></span>
            <div><h4 class="fw-bold mb-0 text-dark">158k</h4><small class="text-muted text-uppercase" style="font-size:10px;">Total Students</small></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="p-3.5 bg-white border rounded shadow-sm d-flex align-items-center">
            <span class="p-3 bg-success bg-opacity-10 text-success rounded-circle me-3"><i class="feather-dollar-sign fs-5"></i></span>
            <div><h4 class="fw-bold mb-0 text-dark">₹4.2 Lakh</h4><small class="text-muted text-uppercase" style="font-size:10px;">Platform billing</small></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="p-3.5 bg-white border rounded shadow-sm d-flex align-items-center">
            <span class="p-3 bg-warning bg-opacity-10 text-warning rounded-circle me-3"><i class="feather-file-text fs-5"></i></span>
            <div><h4 class="fw-bold mb-0 text-dark">4</h4><small class="text-muted text-uppercase" style="font-size:10px;">Active job announcements</small></div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="p-3.5 bg-white border rounded shadow-sm d-flex align-items-center">
            <span class="p-3 bg-info bg-opacity-10 text-info rounded-circle me-3"><i class="feather-award fs-5"></i></span>
            <div><h4 class="fw-bold mb-0 text-dark">2</h4><small class="text-muted text-uppercase" style="font-size:10px;">Live mocks catalog</small></div>
        </div>
    </div>
</div>

<div class="row g-4 text-dark mb-5">
    <!-- Jobs publisher column -->
    <div class="col-lg-7">
        <div class="card p-4 bg-white border-0 shadow-sm rounded-3">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold font-sans text-dark m-0"><i class="feather-briefcase text-primary me-2"></i> Manage Job Notifications</h5>
                <button class="btn btn-primary btn-sm px-3 shadow" data-bs-toggle="modal" data-bs-target="#modalAddJob"><i class="feather-plus me-1"></i> Add Alert</button>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr style="font-size: 11px;">
                            <th class="py-2">Board / Post Title</th>
                            <th class="py-2 text-center">Vacancies</th>
                            <th class="py-2 text-center">End Date</th>
                            <th class="py-2 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody style="font-size: 13px;">
                        <?php foreach ($admin_jobs as $job): ?>
                            <tr>
                                <td class="py-2.5">
                                    <div class="fw-bold text-dark mb-0.5"><?php echo s($job['title']); ?></div>
                                    <span class="badge badge-govt text-uppercase" style="font-size: 9px;"><?php echo s($job['organization']); ?></span>
                                </td>
                                <td class="text-center py-2.5"><?php echo number_format($job['total_vacancies']); ?> Positions</td>
                                <td class="text-center py-2.5 text-danger"><?php echo date('d-m-Y', strtotime($job['end_date'])); ?></td>
                                <td class="text-center py-2.5">
                                    <span class="badge bg-success p-1 text-white border"><i class="feather-edit-2"></i></span>
                                    <span class="badge bg-danger p-1 text-white border ms-1"><i class="feather-trash-2"></i></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <!-- Guidelines side column panel -->
    <div class="col-lg-5">
        <div class="p-4 bg-dark text-white rounded-3 shadow-sm h-100 border border-primary border-opacity-10 d-flex flex-column justify-content-between">
            <div>
                <h5 class="fw-bold font-sans text-primary mb-3" style="color: #60A5FA !important;"><i class="feather-info me-2"></i> Admin Publishing Guidelines</h5>
                <ul class="list-unstyled text-muted small py-1" style="line-height:2; color: #94A3B8 !important;">
                    <li><i class="feather-check text-success me-2 fs-5"></i> <strong>Official Links:</strong> Admin should provide institutional external hyperlinks only.</li>
                    <li><i class="feather-check text-success me-2 fs-5"></i> <strong>Strict Disclaimer:</strong> Disclaimer banner tags must show up clearly in job descriptions.</li>
                    <li><i class="feather-check text-success me-2 fs-5"></i> <strong>No Admit cards database:</strong> ExamDuniya acts as an information bulletin board. Provide direct download links.</li>
                </ul>
            </div>
            
            <div class="p-3 bg-secondary bg-opacity-10 rounded border text-muted" style="font-size:11px; color: #94A3B8 !important;">
                <strong>Developer Integration Link:</strong> Need to add mock tests dynamically using artificial intelligence? Visit the <a href="<?php echo BASE_URL; ?>developer/dashboard.php" class="text-primary fw-medium text-decoration-none">Developer AI Desk</a> to run the Gemini generation suite.
            </div>
        </div>
    </div>
</div>

<!-- Modal Add Job Form -->
<div class="modal fade text-dark" id="modalAddJob" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title fw-bold"><i class="feather-briefcase text-primary me-2"></i> Add New Job Notification</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST" class="modal-body p-4">
                <input type="hidden" name="add_job" value="1">
                
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label small fw-bold">Notification Post Title *</label>
                        <input type="text" name="title" class="form-control" placeholder="UP Police Constable Recruitment Board 2026 Alert" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Organization / Board *</label>
                        <input type="text" name="organization" class="form-control" placeholder="UPPRPB" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Role / Post Name *</label>
                        <input type="text" name="post_name" class="form-control" placeholder="Constable (Civil Police)" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Total Vacant Posts *</label>
                        <input type="number" name="total_vacancies" class="form-control" placeholder="45000" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Key Qualification *</label>
                        <input type="text" name="qualification" class="form-control" placeholder="12th Class Pass or equivalent" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Closing Date of Application *</label>
                        <input type="date" name="end_date" class="form-control" value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>" required>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label small fw-bold">Brief Job Description *</label>
                        <textarea name="description" class="form-control" rows="4" placeholder="Type brief post vacancy instructions..." required></textarea>
                    </div>
                    
                    <div class="col-md-12 mt-3">
                        <div class="form-check form-switch p-3 bg-light rounded border border-primary border-opacity-10 d-flex align-items-center justify-content-between">
                            <div class="ms-1">
                                <label class="form-check-label fw-bold text-dark small" for="broadcast_telegram">Broadcast to Telegram Channel</label>
                                <div class="text-muted small" style="font-size: 11px;">Automatically format and distribute details to your channel instantly after publishing.</div>
                            </div>
                            <input class="form-check-input me-2 mb-0" type="checkbox" name="broadcast_telegram" id="broadcast_telegram" value="1" checked style="width: 44px; height: 22px;">
                        </div>
                    </div>
                </div>
                
                <div class="text-end mt-4 pt-3 border-top">
                    <button type="button" class="btn btn-outline-secondary btn-sm px-4 me-2" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm px-4 border-0" style="background-color: var(--secondary-color);">Publish Job Notification</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
render_footer();
?>
