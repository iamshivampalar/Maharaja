<?php
/**
 * ExamDuniya - Complete Blog & Article CMS Controller
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Route protection
check_role(['Admin', 'Developer']);

// Handle Form Posts
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_article'])) {
        $title = trim($_POST['title']);
        $slug = trim($_POST['slug']);
        if (empty($slug)) {
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        }

        try {
            $stmt_add = $pdo->prepare("INSERT INTO `blogs` (`title`, `slug`, `category`, `tags`, `featured_image`, `status`, `published_at`, `seo_title`, `seo_desc`, `content`) VALUES (:title, :slug, :cat, :tags, :img, :status, :published_at, :seo_title, :seo_desc, :content)");
            $stmt_add->execute([
                ':title' => $title,
                ':slug' => $slug,
                ':cat' => $_POST['category'],
                ':tags' => trim($_POST['tags']),
                ':img' => trim($_POST['featured_image']),
                ':status' => $_POST['status'],
                ':published_at' => $_POST['published_at'] . ' 00:00:00',
                ':seo_title' => trim($_POST['seo_title']),
                ':seo_desc' => trim($_POST['seo_desc']),
                ':content' => trim($_POST['content'])
            ]);
            set_flash_message('success', 'Article "' . s($title) . '" has been added and queued under status: ' . s($_POST['status']) . '!');
        } catch (Exception $e) {
            set_flash_message('danger', 'Error adding article: ' . $e->getMessage());
        }
        header("Location: articles.php");
        exit;
    }

    if (isset($_POST['delete_article'])) {
        $id = (int)$_POST['article_id'];
        try {
            $stmt_del = $pdo->prepare("DELETE FROM `blogs` WHERE `id` = :id");
            $stmt_del->execute([':id' => $id]);
            set_flash_message('warning', 'Article removed successfully.');
        } catch (Exception $e) {
            set_flash_message('danger', 'Error deleting article: ' . $e->getMessage());
        }
        header("Location: articles.php");
        exit;
    }
}

// Fetch articles from database
$stmt_get = $pdo->query("SELECT * FROM `blogs` ORDER BY `published_at` DESC");
$articles = $stmt_get->fetchAll();

render_header("Blog & Article Editor CMS");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 "><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Workspace -->
    <div class="col-lg-9 text-dark">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="feather-file-text text-primary me-2"></i>Blog & Article Management CMS</h3>
                <p class="text-muted small mb-0">Publish education updates, syllabus analysis, strategy guides, and SEO optimized articles.</p>
            </div>
            <button class="btn btn-primary bg-primary border-0 d-flex align-items-center" data-bs-toggle="modal" data-bs-target="#modalAddArticle">
                <i class="feather-plus me-1"></i> Create New Article
            </button>
        </div>

        <div class="card border-0 shadow-sm bg-white p-4 mb-4">
            <h5 class="fw-bold mb-3">SaaS Blog Archive</h5>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light text-uppercase font-sans" style="font-size: 11px;">
                        <tr>
                            <th class="py-3" style="width: 350px;">Article Title</th>
                            <th class="py-3">Category</th>
                            <th class="py-3">Release Schedule</th>
                            <th class="py-3 text-center">Status</th>
                            <th class="py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody style="font-size: 13px;">
                        <?php foreach ($articles as $art): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="<?php echo s($art['featured_image']); ?>" class="rounded me-2 border" style="width: 50px; height: 35px; object-fit: cover;">
                                        <div>
                                            <div class="fw-bold text-dark text-truncate" style="max-width: 280px;"><?php echo s($art['title']); ?></div>
                                            <small class="text-muted text-monospace" style="font-size: 11px;">/<?php echo s($art['slug']); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><span class="badge bg-light text-dark shadow-xs border"><?php echo s($art['category']); ?></span></td>
                                <td><span class="text-muted text-monospace small"><?php echo s($art['published_at']); ?></span></td>
                                <td class="text-center">
                                    <?php if ($art['status'] === 'Published'): ?>
                                        <span class="badge bg-success">Published</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning text-dark">Scheduled</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <form action="" method="POST" onsubmit="return confirm('Do you wish to delete this article?');" class="d-inline">
                                        <input type="hidden" name="article_id" value="<?php echo $art['id']; ?>">
                                        <input type="hidden" name="delete_article" value="1">
                                        <button type="submit" class="btn btn-sm btn-outline-danger p-1 border">
                                            <i class="feather-trash-2"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Article Modal -->
<div class="modal fade" id="modalAddArticle" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content border-0">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title fw-bold"><i class="feather-file-text text-primary me-2"></i> Create SEO Optimized Article</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST" class="modal-body p-4 text-dark text-start">
                <input type="hidden" name="add_article" value="1">
                
                <div class="row g-3">
                    <div class="col-md-8">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Article Main Heading Title *</label>
                            <input type="text" name="title" class="form-control" placeholder="UP Police Board Mock Test series released" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold">Custom URL Permaslug (Option - Else auto generated)</label>
                            <input type="text" name="slug" class="form-control font-mono" placeholder="crack-up-police-mock-test-series">
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold">Featured Main Content Body * (HTML or standard writeups)</label>
                            <textarea name="content" class="form-control" rows="12" placeholder="Write standard rich post detail guidelines..." required></textarea>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="p-3 bg-light rounded border mb-3">
                            <h6 class="fw-bold mb-3 text-uppercase font-sans" style="font-size:12px;">Publish Parameters</h6>
                            
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Category Group *</label>
                                <select name="category" class="form-select" required>
                                    <option value="Exam Prep Tips">Exam Prep Tips</option>
                                    <option value="Syllabus Updates">Syllabus Updates</option>
                                    <option value="Current Affairs News">Current Affairs News</option>
                                    <option value="SaaS Features">SaaS Features</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-bold">Tags (Comma separated) *</label>
                                <input type="text" name="tags" class="form-control form-control-sm" placeholder="prep, up police, syllabus" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-bold">Publish Strategy *</label>
                                <select name="status" class="form-select" required>
                                    <option value="Published">Instant Publish (Live immediately)</option>
                                    <option value="Scheduled">Scheduled Publishing (Auto publish date)</option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-bold">Publish Date & Time *</label>
                                <input type="date" name="published_at" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-bold">Featured Header Image (URL) *</label>
                                <input type="url" name="featured_image" class="form-control" value="https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&q=80&w=600" required>
                            </div>
                        </div>

                        <div class="p-3 bg-light rounded border">
                            <h6 class="fw-bold text-primary mb-3 text-uppercase font-sans" style="font-size:12px;"><i class="feather-search"></i> SEO META Configuration</h6>
                            
                            <div class="mb-2">
                                <label class="form-label small fw-bold">Google Meta Title *</label>
                                <input type="text" name="seo_title" class="form-control form-control-sm" placeholder="Meta Title" required>
                            </div>

                            <div class="mb-2">
                                <label class="form-label small fw-bold">Google Meta Description *</label>
                                <textarea name="seo_desc" class="form-control form-control-sm" rows="3" placeholder="Explain the focus keyword meta description in 160 characters..." required></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="border-top mt-4 pt-3 text-end">
                    <button type="button" class="btn btn-outline-secondary btn-sm px-3 me-2" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm px-4 bg-primary border-0">Save & Broadcast Article</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
render_footer();
?>
