<?php
/**
 * ExamDuniya - Secure real-time PayU Cryptographic Redirection Interstitial
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

check_logged_in();

$sub_id = (int)($_POST['subscription_id'] ?? 1);
$amount = (float)($_POST['total_amount'] ?? 199.00);
$txn_id = 'TXN_PAYU_' . rand(10049281, 99482910);

$user_id = (int)$_SESSION['user_id'];
$firstname = $_SESSION['user_name'] ?? 'Candidate';
$email = $_SESSION['user_email'] ?? 'candidate@examduniya.in';
$phone = $_SESSION['user_phone'] ?? '9999999999';

// Persistent pending transaction registered inside local SQLite/MySQL engine
$pdo->execute("INSERT INTO `payments` (`user_id`, `subscription_id`, `txn_id`, `amount`, `status`) VALUES ($user_id, $sub_id, '$txn_id', $amount, 'Pending')");

// Fetch active keys from database settings
$stmt_key = $pdo->query("SELECT `setting_value` FROM `site_settings` WHERE `setting_key` = 'payu_merchant_key' LIMIT 1");
$merchant_key = trim($stmt_key->fetchColumn() ?: '');

$stmt_salt = $pdo->query("SELECT `setting_value` FROM `site_settings` WHERE `setting_key` = 'payu_salt' LIMIT 1");
$salt = trim($stmt_salt->fetchColumn() ?: '');

// Determine fallback mode if credentials are default samples
$is_live = (!empty($merchant_key) && !empty($salt) && !str_contains($merchant_key, 'DEMO') && !str_contains($salt, 'DEMO') && !str_contains($merchant_key, 'SAMPLE') && !str_contains($salt, 'SAMPLE'));

$productinfo = "SubscriptionPackage_" . $sub_id;
$surl = BASE_URL . 'payu-response.php';
$furl = BASE_URL . 'payu-response.php';

// Construct Standard sha512 PayU Cryptographic Hash Signature
// sha512(key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10|salt)
$udf1 = ''; $udf2 = ''; $udf3 = ''; $udf4 = ''; $udf5 = ''; $udf6 = ''; $udf7 = ''; $udf8 = ''; $udf9 = ''; $udf10 = '';
$hash_sequence = "$merchant_key|$txn_id|$amount|$productinfo|$firstname|$email|$udf1|$udf2|$udf3|$udf4|$udf5|$udf6|$udf7|$udf8|$udf9|$udf10|$salt";
$hash = strtolower(hash('sha512', $hash_sequence));

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PayU Enterprise Handshake - ExamDuniya</title>
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Feather Icons -->
    <link href="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #0F172A;
            color: #E2E8F0;
            min-height: 100vh;
        }
        .payu-card {
            background-color: #1E293B;
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 16px;
            max-width: 580px;
            box-shadow: 0 10px 40px -10px rgba(0, 0, 0, 0.5);
        }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center py-5 px-3">

    <div class="payu-card p-4 p-md-5 w-100">
        <div class="text-center mb-4">
            <div class="p-3 bg-primary bg-opacity-10 text-primary border border-primary border-opacity-20 d-inline-block rounded-circle mb-3">
                <i class="feather-credit-card fs-1"></i>
            </div>
            <h4 class="fw-bold text-white mb-1">PayU Secure Gateway Handshake</h4>
            <p class="text-muted small">Constructing cryptographic payment parameters list for real-time clearance.</p>
        </div>

        <div class="card bg-black bg-opacity-20 border-0 p-3 mb-4 rounded-3 text-start">
            <div class="d-flex justify-content-between mb-2 small">
                <span class="text-muted">Transaction ID (txnid):</span>
                <span class="font-mono text-white fw-medium"><?php echo $txn_id; ?></span>
            </div>
            <div class="d-flex justify-content-between mb-2 small">
                <span class="text-muted">Product Info:</span>
                <span class="text-white fw-medium"><?php echo s($productinfo); ?></span>
            </div>
            <div class="d-flex justify-content-between mb-2 small">
                <span class="text-muted">Candidate Name:</span>
                <span class="text-white fw-medium"><?php echo s($firstname); ?> (<?php echo s($email); ?>)</span>
            </div>
            <div class="d-flex justify-content-between mb-2 small border-bottom border-secondary border-opacity-20 pb-2">
                <span class="text-muted">Gateway Amount:</span>
                <span class="text-success fw-bold font-sans fs-5">₹<?php echo number_format($amount, 2); ?></span>
            </div>
            <div class="pt-2 small">
                <span class="text-muted block d-block mb-1">Generated Cryptographic Signature Hash (sha512):</span>
                <code class="font-mono text-warning text-break small bg-slate-900 px-2 py-1.5 rounded d-block" style="font-size: 11px;"><?php echo $hash; ?></code>
            </div>
        </div>

        <?php if ($is_live): ?>
            <!-- Llive Production Gateway Form -->
            <div class="alert alert-success border-0 bg-success bg-opacity-10 text-success small mb-4 py-3">
                <i class="feather-shield me-2 fs-5"></i>
                <strong>Production Mode Active:</strong> Dynamic credentials checked. Redirecting to official production merchant portal.
            </div>
            
            <form action="https://secure.payu.in/_payment" method="POST" id="payuLiveForm" class="d-grid gap-2">
                <input type="hidden" name="key" value="<?php echo s($merchant_key); ?>">
                <input type="hidden" name="txnid" value="<?php echo s($txn_id); ?>">
                <input type="hidden" name="amount" value="<?php echo s($amount); ?>">
                <input type="hidden" name="productinfo" value="<?php echo s($productinfo); ?>">
                <input type="hidden" name="firstname" value="<?php echo s($firstname); ?>">
                <input type="hidden" name="email" value="<?php echo s($email); ?>">
                <input type="hidden" name="phone" value="<?php echo s($phone); ?>">
                <input type="hidden" name="surl" value="<?php echo s($surl); ?>">
                <input type="hidden" name="furl" value="<?php echo s($furl); ?>">
                <input type="hidden" name="hash" value="<?php echo s($hash); ?>">
                <input type="hidden" name="service_provider" value="payu_paisa">
                
                <button type="submit" class="btn btn-primary py-3 fw-bold border-0" style="background-color: #22C55E;">
                    Redirect to PayU Secure Gateway <i class="feather-arrow-right ms-1"></i>
                </button>
            </form>
            
            <script>
                // Auto post checkout form to live PayU in production
                window.onload = function() {
                    setTimeout(function() {
                        document.getElementById('payuLiveForm').submit();
                    }, 1200);
                };
            </script>
        <?php else: ?>
            <!-- Fallback Interoperable Testing Screen -->
            <div class="alert alert-warning border-0 bg-warning bg-opacity-10 text-warning small mb-4">
                <div class="d-flex">
                    <i class="feather-alert-triangle me-2 mt-1 fs-5"></i>
                    <div>
                        <strong>Demo Keys Configured:</strong> System settings currently hold dummy keys (<code><?php echo s($merchant_key); ?></code>). Change keys in settings for live checkouts. Secure local processing enabled.
                    </div>
                </div>
            </div>

            <form action="payu-response.php" method="POST" class="d-grid gap-2">
                <input type="hidden" name="txn_id" value="<?php echo s($txn_id); ?>">
                <input type="hidden" name="subscription_id" value="<?php echo s($sub_id); ?>">
                <input type="hidden" name="amount" value="<?php echo s($amount); ?>">
                
                <button type="submit" name="payu_status" value="Success" class="btn btn-success py-3 fw-bold border-0">
                    <i class="feather-check-circle me-1"></i> SOLVE TEST TRANSACTION (SUCCESS)
                </button>
                <button type="submit" name="payu_status" value="Failed" class="btn btn-outline-danger py-2 border-secondary text-white-50">
                    Simulate Gateway Reject / Cancel
                </button>
            </form>
        <?php endif; ?>

        <div class="text-center mt-4 pt-1">
            <a href="subscribe.php" class="text-muted text-decoration-none small"><i class="feather-chevron-left me-1"></i> Abort & Go Back</a>
        </div>
    </div>

</body>
</html>
