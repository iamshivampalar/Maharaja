<?php
/**
 * ExamDuniya - Complete Project ZIP Exporter for cPanel Shared Hosting
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Enforce Developer role
check_role(['Developer']);

// Limit execution time to avoid timeouts
set_time_limit(300);

if (isset($_GET['action']) && $_GET['action'] === 'download') {
    // Generate temporary zip path
    $zip_filename = 'examduniya_complete_project_' . date('Y_m_d_His') . '.zip';
    $zip_filepath = sys_get_temp_dir() . '/' . $zip_filename;

    if (!class_exists('ZipArchive')) {
        die("Error: PHP ZipArchive extension is not enabled on this server. Please enable zip in php.ini.");
    }

    $zip = new ZipArchive();
    if ($zip->open($zip_filepath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
        die("Error: Cannot create temporary ZIP file inside " . sys_get_temp_dir());
    }

    $root_path = dirname(__DIR__);

    // Recursive directory iterator
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root_path),
        RecursiveIteratorIterator::LEAVES_ONLY
    );

    foreach ($files as $name => $file) {
        // Skip directories
        if ($file->isDir()) {
            continue;
        }

        $filePath = $file->getRealPath();
        $relativePath = substr($filePath, strlen($root_path) + 1);

        // Normalize paths for cross-platform compatibility
        $relativePath = str_replace('\\', '/', $relativePath);

        // Exclude massive node libraries and runtime folders
        $exclude_patterns = [
            'node_modules/',
            '.git/'
        ];

        $should_exclude = false;
        foreach ($exclude_patterns as $pattern) {
            if (str_contains($relativePath, $pattern) || $relativePath === trim($pattern, '/')) {
                $should_exclude = true;
                break;
            }
        }

        if ($should_exclude) {
            continue;
        }

        // Add file to zip
        $zip->addFile($filePath, $relativePath);
    }

    $zip->close();

    // Check if zip was created and has size
    if (file_exists($zip_filepath) && filesize($zip_filepath) > 0) {
        // Log to DB audit trails
        $log_msg = "Project Exporter: Developer successfully compiled and downloaded complete Clean Production Source ZIP (" . round(filesize($zip_filepath) / 1024 / 1024, 2) . " MB)";
        try {
            $pdo->execute("INSERT INTO `logs` (`level`, `message`) VALUES ('System', '" . addslashes($log_msg) . "')");
        } catch (Exception $e) {}

        // Stream ZIP file
        header('Content-Description: File Transfer');
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zip_filename . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($zip_filepath));
        
        // Clean output buffer to avoid zip corruption
        if (ob_get_level()) {
            ob_end_clean();
        }
        flush();
        readfile($zip_filepath);
        
        // Delete temporary file
        unlink($zip_filepath);
        exit;
    } else {
        die("Error: Generated zip file is empty or missing.");
    }
}

// Render dynamic interface
render_header("Export Complete Project Source");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 text-dark"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="generator.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 text-dark"><i class="feather-cpu me-3"></i>AI Mock Creator</a>
                <a href="blog-generator.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 text-dark"><i class="feather-file-text me-3"></i>AI Blog Creator</a>
                <a href="export-project.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-download-cloud me-3"></i>Export Complete Project</a>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="col-lg-9 text-dark">
        <div class="card p-5 bg-white border rounded-3 shadow-sm text-center">
            <div class="mb-4">
                <div class="mx-auto bg-success bg-opacity-10 text-success rounded-circle d-flex align-items-center justify-content-center mb-3" style="width: 80px; height: 80px;">
                    <i class="feather-package display-5"></i>
                </div>
                <h2 class="fw-bold text-dark font-sans tracking-tight">cPanel Shared Hosting Deployer</h2>
                <p class="text-muted col-lg-8 mx-auto mt-2 fs-6">Pack database schemas, fully custom interactive scripts, administrative portals, and assets with 100% precision! Fast-compiling zip builds eliminate timeout errors automatically.</p>
            </div>

            <div class="p-4 bg-light rounded-3 text-start border border-dashed border-secondary border-opacity-20 mb-4 mx-auto" style="max-width: 650px;">
                <h6 class="fw-bold text-dark"><i class="feather-list text-primary me-2"></i>Included Assets & Exclusions</h6>
                <ul class="mb-0 text-muted small mt-2" style="line-height: 1.8;">
                    <li><strong>Complete PHP Engine:</strong> Mock testing consoles, result lists, payment loops, and login portals.</li>
                    <li><strong>Full Administration Panel:</strong> CMS editor, redirects manager, log viewers, and scheduled broadcasters.</li>
                    <li><strong>Database Schema (database.sql):</strong> Fully synchronized ready-to-run DDL blueprints with mock records.</li>
                    <li><strong>No Bloat:</strong> Discards heavy node libraries such as <code>node_modules</code> to make the source lightweight for quick transfers.</li>
                </ul>
            </div>

            <div class="d-flex flex-column align-items-center justify-content-center gap-3">
                <a href="export-project.php?action=download" class="btn btn-success bg-success border-0 px-5 py-3 fw-bold shadow hover-up d-inline-flex align-items-center gap-2">
                    <i class="feather-download-cloud fs-5"></i> Compile & Download Complete Source (.zip)
                </a>
                <span class="text-muted small" style="font-size: 11px;"><i class="feather-shield text-success me-1"></i> Formatted for root directories (public_html / htdocs) on shared server engines.</span>
            </div>
        </div>
    </div>
</div>

<?php
render_footer();
?>
