<?php
/**
 * ExamDuniya - Blog & Article Public Knowledge Base
 */

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/app/Helpers/functions.php';

// Sync session blog articles fallback if empty
if (empty($_SESSION['blog_articles'])) {
    $_SESSION['blog_articles'] = [
        [
            'id' => 1,
            'title' => 'How to Crack UP Police Written Exam 2026: Expert Mock Strategy',
            'slug' => 'crack-up-police-written-exam-strategy',
            'category' => 'Exam Prep Tips',
            'tags' => 'UP Police, Preparation, Mock Guide',
            'featured_image' => 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&q=80&w=600',
            'status' => 'Published',
            'published_at' => '2026-06-01 10:00:00',
            'seo_title' => 'Crack UP Police Exam 2026 Strategy Guide',
            'seo_desc' => 'Read expert tips, mock test guides, and exam formats to successfully crack the UP Police Written Examination on your very first trial.',
            'content' => 'Preparation for UP Police Constable requires consistency and a strict regimen of computer-based tests. First, review historical cutoffs, practice General Hindi, and solve daily mock trials to gain high velocity. Review previous year paper solutions diligently and align timing pacing filters.'
        ],
        [
            'id' => 2,
            'title' => 'SSC CGL 2026 Tier-1 Syllabus Revision & Pattern Changes Explained',
            'slug' => 'ssc-cgl-tier-1-pattern-revision-changes',
            'category' => 'Syllabus Updates',
            'tags' => 'SSC, CGL, Syllabus',
            'featured_image' => 'https://images.unsplash.com/photo-1513258496099-48168024aec0?auto=format&fit=crop&q=80&w=600',
            'status' => 'Published',
            'published_at' => '2026-05-28 08:30:00',
            'seo_title' => 'SSC CGL Tier 1 Syllabus Change Insights 2026',
            'seo_desc' => 'Important amendments announced in SSC CGL quantitative and verbal section patterns. Check detailed analysis.',
            'content' => 'The Staff Selection Commission revised Tier 1 sectional formats. Reasoning weighting and quantitative algebra models will contain advanced subheadings in coming cycles. Learn how to adapt parameters accordingly.'
        ]
    ];
}

render_header("Sarkari Exam Blog & Preparation Articles");
?>

<!-- Blog Header area -->
<div class="row mb-5 text-dark">
    <div class="col-12 text-center py-4 bg-white border rounded">
        <h1 class="fw-extrabold display-6 font-sans text-dark mb-2">ExamDuniya Knowledge Center</h1>
        <p class="text-muted col-lg-8 mx-auto">Get historical cutoff updates, quantitative shortcuts, English vocabulary patterns, and expert government preparation strategy articles.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Articles List -->
    <div class="col-lg-8 text-dark">
        <div class="row g-4">
            <?php foreach ($_SESSION['blog_articles'] as $art): 
                if ($art['status'] !== 'Published') continue;
            ?>
                <div class="col-md-12">
                    <article class="card glass-card p-0 overflow-hidden border-0 bg-white">
                        <div class="row g-0">
                            <div class="col-md-5">
                                <img src="<?php echo s($art['featured_image']); ?>" class="img-fluid h-100 w-full" style="object-fit: cover;" alt="Featured Image">
                            </div>
                            <div class="col-md-7 p-4">
                                <span class="badge badge-govt text-uppercase mb-2" style="font-size: 10px;"><?php echo s($art['category']); ?></span>
                                <h4 class="fw-bold text-dark font-sans tracking-tight mb-2">
                                    <a href="article-detail.php?slug=<?php echo s($art['slug']); ?>" class="text-dark text-decoration-none hover:text-primary">
                                        <?php echo s($art['title']); ?>
                                    </a>
                                </h4>
                                <p class="text-muted small mb-4">
                                    <?php echo s(substr($art['content'], 0, 150)); ?>...
                                </p>
                                <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                    <span class="text-muted small text-monospace"><i class="feather-calendar me-1"></i><?php echo date('d-M-Y', strtotime($art['published_at'])); ?></span>
                                    <a href="article-detail.php?slug=<?php echo s($art['slug']); ?>" class="btn btn-sm btn-outline-primary shadow-xs px-3 font-sans">Read Strategy</a>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Sidebar widgets -->
    <div class="col-lg-4 text-dark">
        <!-- Search widget -->
        <div class="card p-4 border bg-white rounded-3 shadow-none mb-4">
            <h5 class="fw-bold font-sans text-dark mb-3">Filter Topics</h5>
            <div class="list-group list-group-flush border-0">
                <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center border-0 px-0 py-2">
                    <span><i class="feather-chevron-right text-muted me-2"></i> Exam Prep Tips</span>
                    <span class="badge rounded-pill bg-light text-dark">12</span>
                </a>
                <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center border-0 px-0 py-2">
                    <span><i class="feather-chevron-right text-muted me-2"></i> Syllabus Updates</span>
                    <span class="badge rounded-pill bg-light text-dark">8</span>
                </a>
                <a href="#" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center border-0 px-0 py-2">
                    <span><i class="feather-chevron-right text-muted me-2"></i> Current Affairs News</span>
                    <span class="badge rounded-pill bg-light text-dark">24</span>
                </a>
            </div>
        </div>

        <!-- Inline Advertisement Slot -->
        <div class="card border p-3 bg-light text-center rounded mb-4 shadow-sm">
            <div class="text-uppercase text-muted fs-11 fw-bold tracking-wider mb-2">Advertisement</div>
            <img src="https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?auto=format&fit=crop&q=80&w=400" class="img-fluid rounded border mb-2" alt="Ad">
            <a href="subscribe.php" class="small fw-semibold text-primary">Unlock premium mock test series on ExamDuniya!</a>
        </div>
    </div>
</div>

<?php
render_footer();
?>
