<?php
/**
 * ExamDuniya - AI Blog & Article Generation Hub (Developer Panel)
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Safe route protection for dev only
check_role(['Developer']);

// Unsplash premium preset mapping reference
$unsplash_presets = [
    'exam_hall' => 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&q=80&w=800',
    'laptop_study' => 'https://images.unsplash.com/photo-1513258496099-48168024aec0?auto=format&fit=crop&q=80&w=800',
    'library' => 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&q=80&w=800',
    'motivation' => 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&q=80&w=800',
    'notebook' => 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&q=80&w=800',
    'calendar' => 'https://images.unsplash.com/photo-1506784983877-45594efa4cbe?auto=format&fit=crop&q=80&w=800',
];

$is_draft_ready = false;
$draft = [];

// Settle default session store if empty
if (empty($_SESSION['blog_articles'])) {
    $_SESSION['blog_articles'] = [
        [
            'id' => 1,
            'title' => 'How to Crack UP Police Written Exam 2026: Expert Mock Strategy',
            'slug' => 'crack-up-police-written-exam-strategy',
            'category' => 'Exam Prep Tips',
            'tags' => 'UP Police, Preparation, Mock Guide',
            'featured_image' => 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&q=80&w=600',
            'status' => 'Published',
            'published_at' => date('Y-m-d H:i:s'),
            'seo_title' => 'Crack UP Police Exam 2026 Strategy Guide',
            'seo_desc' => 'Read expert tips, mock test guides, and exam formats to successfully crack the UP Police Written Examination on your very first trial.',
            'content' => 'Preparation for UP Police Constable requires consistency and a strict regimen of computer-based tests. First, review historical cutoffs, practice General Hindi, and solve daily mock trials to gain high velocity. Review previous year paper solutions diligently and align timing pacing filters.'
        ]
    ];
}

// 1. POST ACTION: GENERATE DRAFT USING GEMINI OR SIMULATOR FALLBACK
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_blog_ai'])) {
    $topic = trim($_POST['topic'] ?? 'Sarkari Exam Preparation Strategy');
    $category = trim($_POST['category'] ?? 'Exam Prep Tips');
    $tone = trim($_POST['tone'] ?? 'Professional & Detailed');
    $simulate = isset($_POST['simulate_switch']) && $_POST['simulate_switch'] == 1;

    // Fetch custom API key from settings
    $stmt_key = $pdo->query("SELECT `setting_value` FROM `site_settings` WHERE `setting_key` = 'gemini_api_key' LIMIT 1");
    $gemini_key_db = $stmt_key->fetchColumn() ?: '';
    $api_key = (!empty($gemini_key_db) && !str_contains($gemini_key_db, 'SAMPLE')) ? $gemini_key_db : (getenv('GEMINI_API_KEY') ?: '');

    if (empty($api_key) || $simulate) {
        // ----------------------------------------------------
        // HIGH FIDELITY SIMULATION MODE BACKEND
        // ----------------------------------------------------
        $generated_title = "The Ultimate " . $category . " Path: " . $topic;
        $generated_slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $generated_title)));
        
        $paragraphs = [
            "Preparing for prestigious national competitions requires more than simple rote-memorization. Students targeting $topic must construct a highly integrated study chart that allocates dynamic study blocks to verbal aptitude, numerical precision, and modern general awareness tracks.",
            "A major differentiator for success is the rigorous assessment of mock examinations. Solving computer-based series not only builds core cognitive familiarity with exam patterns, but also teaches students how to handle negative markings on difficult items. Practicing this $category strategy regularly improves accuracy rates tremendously.",
            "Lastly, maintaining excellent physical state and mental endurance is irreplaceable. Maintain a regular review feedback loop, focus on core logic maps, and revise high-weight index questions weekly. Success belongs to candidates who follow structured methodology over simple random attempts."
        ];
        
        $simulated_content = implode("\n\n", $paragraphs);
        $sim_seo_title = substr($generated_title, 0, 55) . " | Strategy Hub";
        $sim_seo_desc = "Get expert advice and master guidelines on " . $topic . " focusing on modern " . $category . ". Solve premium test series to achieve max rank.";

        $draft = [
            'title' => $generated_title,
            'slug' => $generated_slug,
            'category' => $category,
            'tags' => strtolower(str_replace(' ', ', ', $topic)) . ', expert, guide, sarkari',
            'content' => $simulated_content,
            'seo_title' => $sim_seo_title,
            'seo_desc' => $sim_seo_desc,
            'image_keyword' => 'laptop_study'
        ];
        $is_draft_ready = true;
        set_flash_message('success', 'Simulation Mode: Generated high-fidelity mock blog content successfully!');
    } else {
        // ----------------------------------------------------
        // REAL GOOGLE GEMINI NATIVE REST ENDPOINT CALL
        // ----------------------------------------------------
        $prompt = "Write a complete, highly engaging blog article about target topic: '" . $topic . "' in context of candidate preparation catalog for '" . $category . "'. Use a '" . $tone . "' tone. You MUST respond with a RAW, clean JSON layout ONLY. Absolutely do NOT enclose inside any markdown blocks like ```json or similar formatting.
        Use this exact strict JSON structure:
        {
          \"title\": \"A catchy, beautiful title for the blog post\",
          \"slug\": \"url-friendly-slug-representing-the-title-with-hyphens\",
          \"tags\": \"tag1, tag2, tag3, tag4\",
          \"seo_title\": \"SEO Meta Title under 60 characters\",
          \"seo_desc\": \"Search Engine meta description under 155 characters\",
          \"content\": \"Write a rich, detailed, multi-paragraph blog body. Provide comprehensive study tips, resources, schedules, or updates depending on the topic. Keep the content thoroughly informative (at least 200 words). Format the blocks using standard double-breaks between paragraphs without markdown headers.\",
          \"image_keyword\": \"Choose one keyword from: exam_hall, laptop_study, library, motivation, notebook, calendar\"
        }";

        $endpoint_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=" . $api_key;
        
        $payload = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'responseMimeType' => 'application/json'
            ]
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $endpoint_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        
        $server_output = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_code === 200) {
            $response_decoded = json_decode($server_output, true);
            $raw_json_text = $response_decoded['candidates'][0]['content']['parts'][0]['text'] ?? '';
            $api_response_decoded = json_decode(trim($raw_json_text), true);

            if (!empty($api_response_decoded['title'])) {
                $draft = [
                    'title' => $api_response_decoded['title'],
                    'slug' => $api_response_decoded['slug'] ?? strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $api_response_decoded['title']))),
                    'category' => $category,
                    'tags' => $api_response_decoded['tags'] ?? 'education, preps',
                    'content' => $api_response_decoded['content'],
                    'seo_title' => $api_response_decoded['seo_title'] ?? $api_response_decoded['title'],
                    'seo_desc' => $api_response_decoded['seo_desc'] ?? 'Read detailed article on ExamDuniya.',
                    'image_keyword' => $api_response_decoded['image_keyword'] ?? 'notebook'
                ];
                $is_draft_ready = true;
                set_flash_message('success', 'Gemini AI Call Successful! Your drafted article is ready for review.');
            } else {
                set_flash_message('danger', 'Error: Gemini parsed payload format incorrect. Check raw generation.');
            }
        } else {
            set_flash_message('danger', 'Gemini API handshake failed (HTTP ' . $http_code . '). Make sure fallback simulator check is selected or verify your secret key.');
        }
    }
}

// 2. POST ACTION: PUBLISH REVIEWED BLOG TO CANDIDATE NETWORK
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['publish_blog'])) {
    $title = trim($_POST['title']);
    $slug = trim($_POST['slug']);
    if (empty($slug)) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
    }

    $pub_art = [
        'id' => rand(1000, 9999),
        'title' => $title,
        'slug' => $slug,
        'category' => $_POST['category'],
        'tags' => trim($_POST['tags']),
        'featured_image' => trim($_POST['featured_image']),
        'status' => $_POST['status'] ?? 'Published',
        'published_at' => date('Y-m-d H:i:s'),
        'seo_title' => trim($_POST['seo_title']),
        'seo_desc' => trim($_POST['seo_desc']),
        'content' => trim($_POST['content'])
    ];

    $_SESSION['blog_articles'][] = $pub_art;

    // Log the successful creation into DB logs
    $log_msg = "AI Blog Integration: Dev successfully generated and integrated dynamic article '" . addslashes($title) . "' under SEO tags.";
    $pdo->execute("INSERT INTO `logs` (`level`, `message`) VALUES ('AI', '" . addslashes($log_msg) . "')");

    set_flash_message('success', 'Success! Article "' . s($title) . '" has been permanently added to the public catalog with advanced SEO Schema!');
    header("Location: " . BASE_URL . "articles.php");
    exit;
}

render_header("AI Dynamic Blog Generator");
?>

<div class="row mb-4 text-dark">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>index.php" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="dashboard.php" class="text-decoration-none">Developer Closet</a></li>
                <li class="breadcrumb-item active" aria-current="page">AI Blog Gen</li>
            </ol>
        </nav>
        <span class="badge text-white py-1 px-3 bg-primary mb-2 text-white font-sans fw-bold"><i class="feather-cpu me-1"></i> COGNITIVE AI BLOG TEAM</span>
        <h2 class="fw-bold font-sans">AI-Powered Blog & SEO Article Creator</h2>
        <p class="text-muted">Enter target education themes, configure standard core parameters, and let Gemini compile high-quality blog texts with image schemas instantly.</p>
    </div>
</div>

<div class="row g-4 text-dark mb-5">
    <!-- Generator Config form (Left column) -->
    <div class="col-lg-5">
        <div class="card p-4 bg-white border shadow-sm rounded-4">
            <h5 class="fw-bold text-dark font-sans mb-3"><i class="feather-git-pull-request text-primary me-2"></i> 1. Generation Parameters</h5>
            <form action="" method="POST">
                <input type="hidden" name="generate_blog_ai" value="1">

                <div class="mb-3">
                    <label class="form-label small fw-bold">Target Blog Theme / Topic *</label>
                    <input type="text" name="topic" class="form-control" placeholder="e.g. Best Maths tricks for SSC-GD 2026 or Stress Management for Aspirants" value="Best General Studies notes for UP Police Exams" required>
                    <div class="form-text" style="font-size: 11px;">Be descriptive for extremely precise results.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Select Blog Topic Category</label>
                    <select name="category" class="form-select">
                        <option value="Exam Prep Tips" selected>Exam Prep Tips</option>
                        <option value="Syllabus Updates">Syllabus Updates</option>
                        <option value="Motivation">Motivation</option>
                        <option value="Career Guidelines">Career Guidelines</option>
                        <option value="GK & Current Affairs">GK & Current Affairs</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">Narrative Tone Vibe</label>
                    <select name="tone" class="form-select">
                        <option value="Professional & Detailed" selected>Professional & Detailed</option>
                        <option value="Encouraging & Enthusiastic">Encouraging & Enthusiastic</option>
                        <option value="To-the-point & Quick Tips">To-the-point & Quick Tips</option>
                        <option value="Deep Academic Analysis">Deep Academic Analysis</option>
                    </select>
                </div>

                <!-- Simulation Toggle -->
                <div class="form-check form-switch p-3 bg-light rounded border border-warning border-opacity-15 mb-4 d-flex align-items-center justify-content-between">
                    <div class="ms-1">
                        <label class="form-check-label fw-bold text-dark small" for="simulate_switch">Run Simulation Fallback</label>
                        <div class="text-muted small" style="font-size: 11px;">Enable when you do not have an active key. Runs a perfect local copy instantly.</div>
                    </div>
                    <input class="form-check-input me-2" type="checkbox" name="simulate_switch" id="simulate_switch" value="1" checked style="width: 45px; height: 22px;">
                </div>

                <button type="submit" class="btn btn-primary w-100 py-3 border-0 fw-bold rounded font-sans text-uppercase shadow-sm" style="background-color: var(--secondary-color);">
                    <i class="feather-code me-1"></i> Generate AI Blog Draft
                </button>
            </form>
        </div>
    </div>

    <!-- Review Block (Right column) -->
    <div class="col-lg-7">
        <?php if ($is_draft_ready): ?>
            <!-- Perfect Pre-publishing Review form -->
            <div class="card p-4 bg-white border shadow-sm rounded-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold text-dark font-sans m-0"><i class="feather-eye text-success me-2"></i> 2. Edit & Validate SEO Draft</h5>
                    <span class="badge bg-success bg-opacity-10 text-success py-1.5 px-3 rounded-pill fw-semibold font-sans">Ready for Verification</span>
                </div>

                <form action="" method="POST">
                    <input type="hidden" name="publish_blog" value="1">

                    <!-- Title -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">Final Article Title</label>
                        <input type="text" name="title" id="draft_title" class="form-control" value="<?php echo s($draft['title']); ?>" required oninput="calculateSEOScores()">
                        <div id="title_seo_badge" class="mt-1 small"></div>
                    </div>

                    <!-- Slug -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">URL Slug</label>
                        <input type="text" name="slug" class="form-control font-mono" value="<?php echo s($draft['slug']); ?>" required>
                    </div>

                    <!-- Category & Tags -->
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold text-secondary">Category</label>
                            <select name="category" class="form-select">
                                <option value="Exam Prep Tips" <?php echo $draft['category'] === 'Exam Prep Tips' ? 'selected' : ''; ?>>Exam Prep Tips</option>
                                <option value="Syllabus Updates" <?php echo $draft['category'] === 'Syllabus Updates' ? 'selected' : ''; ?>>Syllabus Updates</option>
                                <option value="Motivation" <?php echo $draft['category'] === 'Motivation' ? 'selected' : ''; ?>>Motivation</option>
                                <option value="Career Guidelines" <?php echo $draft['category'] === 'Career Guidelines' ? 'selected' : ''; ?>>Career Guidelines</option>
                                <option value="GK & Current Affairs" <?php echo $draft['category'] === 'GK & Current Affairs' ? 'selected' : ''; ?>>GK & Current Affairs</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold text-secondary">Keywords/Tags</label>
                            <input type="text" name="tags" class="form-control" value="<?php echo s($draft['tags']); ?>">
                        </div>
                    </div>

                    <!-- Image Sourcing Select system -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary d-block">Select Featured Premium Banner Image</label>
                        <div class="row g-2">
                            <?php foreach ($unsplash_presets as $key => $url): 
                                $is_selected_key = ($draft['image_keyword'] === $key);
                            ?>
                                <div class="col-4">
                                    <label class="position-relative w-100 d-block overflow-hidden rounded border border-2 pointer-img <?php echo $is_selected_key ? 'border-primary' : 'border-light'; ?>" style="cursor: pointer; height: 75px;">
                                        <input type="radio" name="featured_image" value="<?php echo s($url); ?>" class="position-absolute opacity-0 d-none" <?php echo $is_selected_key ? 'checked' : ''; ?> onclick="selectImageCard(this)">
                                        <img src="<?php echo s($url); ?>" class="w-100 h-100" style="object-fit: cover;" alt="Preset">
                                        <div class="image-text-overlay position-absolute bottom-0 start-0 w-100 bg-black bg-opacity-65 p-1 text-center text-white font-sans text-monospace" style="font-size: 8px;">
                                            <?php echo ucwords(str_replace('_', ' ', $key)); ?>
                                        </div>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Content -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-secondary">Aesthetic Paragraphs Content (Markdown or HTML)</label>
                        <textarea name="content" id="draft_content" rows="7" class="form-control font-sans" required style="font-size:13.5px; line-height:1.6;" oninput="calculateSEOScores()"><?php echo s($draft['content']); ?></textarea>
                        <div id="content_word_badge" class="mt-1 small"></div>
                    </div>

                    <hr class="text-slate-200">

                    <!-- SEO Section (Optimized fields) -->
                    <div class="p-3 bg-light rounded-3 mb-4">
                        <h6 class="fw-bold text-dark font-sans mb-3"><i class="feather-shield text-info me-1"></i> Core Search Engine Meta Controls</h6>
                        
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Google SERPs SEO Title *</label>
                            <input type="text" name="seo_title" id="draft_seo_title" class="form-control" value="<?php echo s($draft['seo_title']); ?>" required oninput="calculateSEOScores()">
                            <div id="seo_title_badge" class="mt-1 small"></div>
                        </div>

                        <div class="mb-0">
                            <label class="form-label small fw-bold">Google Meta SEO Description *</label>
                            <textarea name="seo_desc" id="draft_seo_desc" rows="2" class="form-control" required style="font-size: 12.5px;" oninput="calculateSEOScores()"><?php echo s($draft['seo_desc']); ?></textarea>
                            <div id="seo_desc_badge" class="mt-1 small"></div>
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-8">
                            <select name="status" class="form-select py-2.5">
                                <option value="Published" selected>Publish Immediately (Candidate Access)</option>
                                <option value="Draft">Save as Draft in Session Mode</option>
                            </select>
                        </div>
                        <div class="col-4">
                            <button type="submit" class="btn btn-success w-100 py-2.5 border-0 fw-bold"><i class="feather-check-circle me-1"></i> Publish Now</button>
                        </div>
                    </div>
                </form>
            </div>
        <?php else: ?>
            <!-- Fallback screen prior to generation -->
            <div class="card p-5 bg-white border rounded-4 text-center text-muted h-100 d-flex flex-column align-items-center justify-content-center">
                <div class="p-4 bg-light rounded-circle mb-3">
                    <i class="feather-file-text display-3 text-muted"></i>
                </div>
                <h5 class="fw-semibold text-dark font-sans mb-1">Pre-publication Sandbox HUD</h5>
                <p class="small text-muted col-lg-8 mx-auto">Fill in the targets on the left side configurations, toggle either Simulator Mode or Live handshake, then execute generation to fetch your draft.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.pointer-img {
    transition: all 0.2s ease;
}
.pointer-img:hover {
    transform: scale(1.02);
}
.pointer-img.border-primary {
    box-shadow: 0 0 10px rgba(37, 99, 235, 0.25);
}
</style>

<script>
function selectImageCard(radioInput) {
    // Clear other border classes
    const labels = document.querySelectorAll('.pointer-img');
    labels.forEach(label => {
        label.classList.remove('border-primary');
        label.classList.add('border-light');
    });
    // Color newly selected labeled frame
    const parentLabel = radioInput.closest('.pointer-img');
    if (parentLabel) {
        parentLabel.classList.remove('border-light');
        parentLabel.classList.add('border-primary');
    }
}

function calculateSEOScores() {
    // 1. Google SEO Title Score (suggested: 40-60 characters)
    const seoTitleNode = document.getElementById('draft_seo_title');
    const seoTitleBadge = document.getElementById('seo_title_badge');
    if (seoTitleNode && seoTitleBadge) {
        const len = seoTitleNode.value.length;
        if (len === 0) {
            seoTitleBadge.innerHTML = '';
        } else if (len >= 40 && len <= 60) {
            seoTitleBadge.innerHTML = `<span class="text-success"><i class="feather-check-circle me-1"></i> Excellent Character Count (${len} chars). Perfectly tailored for Google results.</span>`;
        } else {
            seoTitleBadge.innerHTML = `<span class="text-warning"><i class="feather-info me-1"></i> Length ${len} chars. Try choosing 40-60 chars for maximum layout fit.</span>`;
        }
    }

    // 2. Google Meta SEO Desc Score (suggested: 110-160 characters)
    const seoDescNode = document.getElementById('draft_seo_desc');
    const seoDescBadge = document.getElementById('seo_desc_badge');
    if (seoDescNode && seoDescBadge) {
        const len = seoDescNode.value.length;
        if (len === 0) {
            seoDescBadge.innerHTML = '';
        } else if (len >= 110 && len <= 160) {
            seoDescBadge.innerHTML = `<span class="text-success"><i class="feather-check-circle me-1"></i> Excellent Google Meta description length (${len} chars).</span>`;
        } else {
            seoDescBadge.innerHTML = `<span class="text-warning"><i class="feather-info me-1"></i> Length ${len} chars. Try choosing 110-160 chars to avoid Search engine truncation.</span>`;
        }
    }

    // 3. Main blog Title check (suggested: 20-70 characters)
    const titleNode = document.getElementById('draft_title');
    const titleBadge = document.getElementById('title_seo_badge');
    if (titleNode && titleBadge) {
        const len = titleNode.value.length;
        if (len === 0) {
            titleBadge.innerHTML = '';
        } else if (len >= 20 && len <= 70) {
            titleBadge.innerHTML = `<span class="text-success"><i class="feather-check-circle me-1"></i> Title Length fits nicely (${len} chars).</span>`;
        } else {
            titleBadge.innerHTML = `<span class="text-warning"><i class="feather-alert-triangle me-1"></i> Length ${len} chars. Recommended 20 to 70 chars.</span>`;
        }
    }

    // 4. Content words tracker (suggested: 150+ words)
    const contentNode = document.getElementById('draft_content');
    const contentBadge = document.getElementById('content_word_badge');
    if (contentNode && contentBadge) {
        const val = contentNode.value.trim();
        const wordCount = val === '' ? 0 : val.split(/\s+/).length;
        if (wordCount === 0) {
            contentBadge.innerHTML = '';
        } else if (wordCount >= 150) {
            contentBadge.innerHTML = `<span class="text-success"><i class="feather-check-circle me-1"></i> High Value Academic length checked (${wordCount} words). Great dynamic content payload.</span>`;
        } else {
            contentBadge.innerHTML = `<span class="text-warning"><i class="feather-info me-1"></i> Under 150 words (${wordCount} words). Elaborate more to satisfy candidate search parameters.</span>`;
        }
    }
}

// Trigger initial score diagnostics on load if elements present
window.addEventListener('DOMContentLoaded', () => {
    calculateSEOScores();
});
</script>

<?php
render_footer();
?>
