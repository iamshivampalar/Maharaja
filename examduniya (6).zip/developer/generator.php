<?php
/**
 * ExamDuniya - Gemini AI Mock Exam & Question-Bank Generator
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

check_role(['Developer']);

$is_generated = false;
$generation_summary = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_ai'])) {
    $exam_name = trim($_POST['exam_name']);
    $subject_id = (int)($_POST['subject_id'] ?? 1);
    $topic = trim($_POST['topic']);
    $difficulty = $_POST['difficulty'] ?? 'Medium';
    $qty = (int)($_POST['qty'] ?? 10);
    $simulate = isset($_POST['simulate_switch']) && $_POST['simulate_switch'] == 1;
    
    // Fetch custom API key from settings
    $stmt_key = $pdo->query("SELECT `setting_value` FROM `site_settings` WHERE `setting_key` = 'gemini_api_key' LIMIT 1");
    $gemini_key_db = $stmt_key->fetchColumn() ?: '';
    
    // Fallback to environment secret if db setting is a placeholder
    $api_key = (!empty($gemini_key_db) && !str_contains($gemini_key_db, 'SAMPLE')) ? $gemini_key_db : (getenv('GEMINI_API_KEY') ?: '');

    if (empty($api_key) || $simulate) {
        // ----------------------------------------------------
        // FAILOVER COHESIVE SIMULATOR BACKEND
        // ----------------------------------------------------
        // Simulates the exact response JSON layout we fetch from Google GenAI endpoint.
        // Inserting into DB tables completely to test connectivity!
        
        $sim_json = '{
            "test_title": "AI generated ' . $exam_name . ' (' . $topic . ') Practice Practice",
            "questions": [
                {
                    "question_text": "Which of the following schedules of the Constitution of India deals with anti-defection laws?",
                    "option_a": "Seventh Schedule",
                    "option_b": "Eighth Schedule",
                    "option_c": "Ninth Schedule",
                    "option_d": "Tenth Schedule",
                    "correct_option": "D",
                    "explanation": "The Tenth Schedule of the Indian Constitution, popularly known as the Anti-Defection Act, was inserted by the 52nd Amendment Act in 1985."
                },
                {
                    "question_text": "The fundamental rights enshrined in Part III of the Constitution of India were broadly borrowed from which national constitution?",
                    "option_a": "United States of America",
                    "option_b": "United Kingdom",
                    "option_c": "Soviet Union (USSR)",
                    "option_d": "Australia",
                    "correct_option": "A",
                    "explanation": "The Fundamental Rights in the Indian Constitution are inspired by the Bill of Rights in the US Constitution."
                },
                {
                    "question_text": "Who acts as the ex-officio Chairman of the Rajya Sabha in the Parliament of India?",
                    "option_a": "President of India",
                    "option_b": "Vice-President of India",
                    "option_c": "Prime Minister of India",
                    "option_d": "Speaker of the Lok Sabha",
                    "correct_option": "B",
                    "explanation": "Under Article 64, the Vice-President of India is the ex-officio Chairman of Rajya Sabha (the Council of States)."
                }
            ]
        }';
        
        $api_response_decoded = json_decode($sim_json, true);
        
    } else {
        // ----------------------------------------------------
        // REAL NATIVE GOOGLE GEMINI REST cURL HANDSHAKE
        // ----------------------------------------------------
        $prompt = "Create " . $qty . " multiple-choice questions for the " . $exam_name . " exam focusing on the topic of " . $topic . " with a " . $difficulty . " level. You MUST respond with a RAW, clean JSON layout ONLY. Absolutely do NOT enclose inside any markdown blocks like ```json or similar formatting. Use this strict JSON format:
        {
          \"test_title\": \"AI Gen Mock Test " . $exam_name . " - " . $topic . "\",
          \"questions\": [
            {
              \"question_text\": \"Question content here\",
              \"option_a\": \"content option a\",
              \"option_b\": \"content option b\",
              \"option_c\": \"content option c\",
              \"option_d\": \"content option d\",
              \"correct_option\": \"A\", 
              \"explanation\": \"solution explanation summary here\"
            }
          ]
        }";

        $endpoint_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" . $api_key;
        
        $payload = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'responseMimeType' => 'application/json'
            ]
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $endpoint_url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        
        $server_output = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            $response_decoded = json_decode($server_output, true);
            $raw_json_text = $response_decoded['candidates'][0]['content']['parts'][0]['text'] ?? '';
            $api_response_decoded = json_decode(trim($raw_json_text), true);
        } else {
            set_flash_message('danger', 'Gemini API handshake failed (HTTP ' . $http_code . '). Please check settings or toggle Simulation fallback mode.');
            $api_response_decoded = null;
        }
    }

    // ----------------------------------------------------
    // INJECT DETECTED MOCK AND QUESTIONS INTO MYSQL
    // ----------------------------------------------------
    if (!empty($api_response_decoded['questions'])) {
        $test_title = $api_response_decoded['test_title'] ?? ('AI Mock Test ' . $exam_name);
        
        // 1. Insert into mock_tests
        $stmt_test_ins = $pdo->prepare("INSERT INTO `mock_tests` (`subscription_id`, `title`, `category`, `duration_minutes`, `total_questions`, `difficulty`, `is_free`) VALUES (1, :title, :category, 60, :qty, :diff, 1)");
        $stmt_test_ins->execute([
            ':title' => $test_title,
            ':category' => $exam_name,
            ':qty' => count($api_response_decoded['questions']),
            ':diff' => $difficulty
        ]);
        
        $new_test_id = $pdo->lastInsertId();
        
        // 2. Loop insert questions
        $stmt_q_ins = $pdo->prepare("INSERT INTO `questions` (`mock_test_id`, `subject_id`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `explanation`) VALUES (:tid, :sid, :qtext, :op_a, :op_b, :op_c, :op_d, :correct, :expl)");
        
        $inserted_count = 0;
        foreach ($api_response_decoded['questions'] as $q) {
            $stmt_q_ins->execute([
                ':tid' => $new_test_id,
                ':sid' => $subject_id,
                ':qtext' => $q['question_text'],
                ':op_a' => $q['option_a'],
                ':op_b' => $q['option_b'],
                ':op_c' => $q['option_c'],
                ':op_d' => $q['option_d'],
                ':correct' => strtoupper($q['correct_option']),
                ':expl' => $q['explanation']
            ]);
            $inserted_count++;
        }
        
        // Log operation inside Audit Logs
        $log_msg = "AI Mock Test Generation: successfully created mock test ID #$new_test_id '$test_title' with $inserted_count structured MCQs.";
        $pdo->execute("INSERT INTO `logs` (`level`, `message`) VALUES ('AI', '" . addslashes($log_msg) . "')");
        
        $is_generated = true;
        $generation_summary = [
            'id' => $new_test_id,
            'title' => $test_title,
            'count' => $inserted_count
        ];
        
        set_flash_message('success', 'AI Generation Complete! Integrated ' . $inserted_count . ' MCQs into mock test suite #' . $new_test_id);
    }
}

// Fetch subjects
$stmt_subs = $pdo->query("SELECT * FROM `subjects` ORDER BY `id` ASC");
$subjects = $stmt_subs->fetchAll();

render_header("AI Mock Test Generator");
?>

<div class="row mb-4 text-dark">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>index.php" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="dashboard.php" class="text-decoration-none">Developer Closet</a></li>
                <li class="breadcrumb-item active" aria-current="page">AI Mock Generator</li>
            </ol>
        </nav>
        <span class="badge text-white py-1 px-3 bg-secondary bg-opacity-25 mb-2 text-dark font-sans fw-bold">🧠 GOOGLE GEMINI AI ASSISTANT</span>
        <h2 class="fw-bold font-sans">Autonomous AI Mock Test Generator</h2>
        <p class="text-muted">Define the syllabus specifications, connect to model pipelines, and let artificial intelligence write mock test sheets.</p>
    </div>
</div>

<div class="row g-4 text-dark mb-5">
    <!-- Generator configurations form col -->
    <div class="col-lg-6">
        <div class="card p-4 bg-white border shadow-sm rounded-4 h-100">
            <h5 class="fw-bold text-dark font-sans mb-3"><i class="feather-settings text-primary me-2"></i> Configure Syllabus targets</h5>
            
            <form action="" method="POST">
                <input type="hidden" name="generate_ai" value="1">
                
                <div class="mb-3">
                    <label class="form-label small fw-bold">Target Exam Name</label>
                    <input type="text" name="exam_name" class="form-control" placeholder="SSC CGL Tier 1 or UP Police SI" value="SSC CGL Tier 1" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label small fw-bold">Select Topic / Subject Map</label>
                    <select name="subject_id" class="form-select border-slate-200">
                        <?php foreach ($subjects as $s): ?>
                            <option value="<?php echo s($s['id']); ?>"><?php echo s($s['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label small fw-bold">Specific Chapter / Topic Area</label>
                    <input type="text" name="topic" class="form-control" placeholder="Indian Polity - Fundamental Rights" value="Indian Polity" required>
                </div>
                
                <div class="row g-2 mb-4">
                    <div class="col-6">
                        <label class="form-label small fw-bold">Difficulty Band</label>
                        <select name="difficulty" class="form-select">
                            <option value="Easy">Easy Level</option>
                            <option value="Medium" selected>Medium Level</option>
                            <option value="Hard">Hard Level</option>
                        </select>
                    </div>
                    <div class="col-6">
                        <label class="form-label small fw-bold">MCQs Quantity</label>
                        <input type="number" name="qty" class="form-control text-center" value="3" min="1" max="10" required>
                    </div>
                </div>

                <!-- Simulation switch slider (Useful if user has no api key configured yet!) -->
                <div class="form-check form-switch p-3 bg-light rounded border border-warning border-opacity-20 mb-4 d-flex align-items-center justify-content-between">
                    <div class="ms-1">
                        <label class="form-check-label fw-bold text-dark small" for="simulate_switch">Run Simulation Fallback</label>
                        <div class="text-muted small" style="font-size: 11px;">Enable this to test complete DB pipeline insertions using mock AI response if you do not have a Gemini API key yet!</div>
                    </div>
                    <input class="form-check-input me-2" type="checkbox" name="simulate_switch" id="simulate_switch" value="1" checked style="width: 45px; height: 22px;">
                </div>

                <button type="submit" class="btn btn-primary w-100 py-3 border-0 fw-bold rounded font-sans text-uppercase shadow-sm" style="background-color: var(--secondary-color);">
                    <i class="feather-cpu me-1"></i> Start autonomous generation
                </button>
            </form>
        </div>
    </div>

    <!-- Active generated suite summary col -->
    <div class="col-lg-6">
        <div class="card p-4 bg-white border shadow-sm rounded-4 h-100 d-flex flex-column justify-content-between text-dark">
            <div>
                <h5 class="fw-bold text-dark font-sans mb-3"><i class="feather-activity text-primary me-2"></i> Creation summary reports</h5>
                
                <?php if ($is_generated): ?>
                    <div class="alert alert-success border-0 shadow-sm p-4 text-start mb-4">
                        <h6 class="fw-bold mb-2"><i class="feather-check-circle text-success me-2 fs-5"></i> Mock Test integrated into MySQL successfully!</h5>
                        <ul class="list-unstyled mb-0 py-1 small">
                            <li class="mb-1"><strong>Mock Suite ID Number:</strong> #<?php echo $generation_summary['id']; ?></li>
                            <li class="mb-1"><strong>Unique Mock Test Title:</strong> <?php echo s($generation_summary['title']); ?></li>
                            <li class="mb-1"><strong>Compiled Questions Count:</strong> <?php echo $generation_summary['count']; ?> MCQs</li>
                        </ul>
                    </div>
                    
                    <p class="small text-muted mb-4">The mock test has been fully built and registered in the candidate catalog. You can switch to the student view at your convenience to solve or test the interactive CBT exam interface.</p>
                <?php else: ?>
                    <div class="text-center py-5 text-muted-small">
                        <i class="feather-help-circle display-4 text-muted d-block mb-3"></i>
                        <p class="m-0">Configure targets on left and click generate to run pipeline checks.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if ($is_generated): ?>
                <a href="<?php echo BASE_URL; ?>dashboard.php" class="btn btn-dark w-100 py-3 font-sans fw-bold rounded shadow border-0 d-block text-center text-white text-decoration-none">
                    <i class="feather-external-link me-1"></i> Switch to Student View to Take Test
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
render_footer();
?>
