<?php
/**
 * ExamDuniya - Developer control panel dashboard
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Enforce Developer role
check_role(['Developer']);

// Handle Settings updates (dynamic config caching simulation)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    $api_key = trim($_POST['gemini_api_key'] ?? '');
    $payu_key = trim($_POST['payu_merchant_key'] ?? '');
    
    // Simple update simulation inside setting tables
    $pdo->execute("UPDATE `site_settings` SET `setting_value` = '$api_key' WHERE `setting_key` = 'gemini_api_key'");
    $pdo->execute("UPDATE `site_settings` SET `setting_value` = '$payu_key' WHERE `setting_key` = 'payu_merchant_key'");
    
    set_flash_message('success', 'Developer system settings cached with high success!');
}

// Fetch settings from Database
$stmt_sett = $pdo->query("SELECT * FROM `site_settings` WHERE `setting_key` IN ('gemini_api_key', 'payu_merchant_key')");
$settings_map = [];
foreach ($stmt_sett->fetchAll() as $s) {
    $settings_map[$s['setting_key']] = $s['setting_value'];
}

// Fetch logs
$stmt_logs = $pdo->query("SELECT * FROM `logs` ORDER BY `id` DESC LIMIT 10");
$logs = $stmt_logs->fetchAll();

render_header("Developer Operations Console");
?>

<div class="row mb-4 text-dark">
    <div class="col-12">
        <h2 class="fw-bold font-sans text-dark tracking-tight mb-2"><i class="feather-code text-primary me-2"></i>Developer Operations Cabinet</h2>
        <p class="text-muted">Manage model keys, invoke autonomous mock question generation pipelines, and inspect full audit logs.</p>
    </div>
</div>

<div class="row g-4 text-dark mb-5">
    <!-- Left Col Options and keys -->
    <div class="col-lg-7">
        <!-- Settings Form -->
        <div class="card p-4 bg-white border shadow-sm rounded-3 mb-4">
            <h5 class="fw-bold text-dark font-sans mb-3"><i class="feather-key text-primary me-2"></i> Environment Secrets (Credentials Panel)</h5>
            
            <form action="" method="POST">
                <input type="hidden" name="save_settings" value="1">
                
                <div class="mb-3">
                    <label class="form-label small fw-bold">Gemini AI Model API Key</label>
                    <input type="password" name="gemini_api_key" class="form-control font-sans" value="<?php echo s($settings_map['gemini_api_key'] ?? 'MY_GEMINI_API_KEY'); ?>" placeholder="Enter Google AI Studio API Key">
                    <div class="form-text" style="font-size:11px;"><i class="feather-info me-1"></i> Required for the autonomous AI Mock Test question generation module.</div>
                </div>
                
                <div class="mb-4">
                    <label class="form-label small fw-bold">PayU Merchant Key</label>
                    <input type="text" name="payu_merchant_key" class="form-control" value="<?php echo s($settings_map['payu_merchant_key'] ?? 'DEMO_PAYU_MERCHANT_KEY'); ?>" placeholder="Enter PayU Biz merchant key">
                </div>
                
                <button type="submit" class="btn btn-dark btn-sm py-2 px-4 shadow border-0">Save Environment credentials</button>
            </form>
        </div>
        
        <!-- Audit logs console -->
        <div class="card p-4 bg-white border shadow-sm rounded-3">
            <h6 class="fw-bold font-sans text-dark mb-3"><i class="feather-activity text-primary me-2"></i> Platform System Audit Trails</h6>
            <div class="bg-black text-lime p-3 rounded font-mono text-xs overflow-y-auto mb-2" style="max-height:220px; font-family:'JetBrains Mono', monospace; line-height:1.6; color:#22C55E; background-color:#090D16;">
                <?php foreach ($logs as $l): ?>
                    <div class="mb-2">
                        <span class="text-secondary">[<?php echo date('H:i:s', strtotime($l['created_at'])); ?>]</span> 
                        <span class="text-warning fw-bold"><?php echo s($l['level']); ?>:</span> 
                        <span class="text-white"><?php echo s($l['message']); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
            <span class="text-muted small" style="font-size: 11px;"><i class="feather-info me-1"></i> Showing latest system exceptions compiled for developer review panels.</span>
        </div>
    </div>

    <!-- Right Col quick action and link triggers -->
    <div class="col-lg-5">
        <div class="card p-4 border border-warning border-opacity-30 rounded-3 text-center bg-warning bg-opacity-5 mb-4 d-flex flex-column align-items-center">
            <span class="p-3 bg-warning bg-opacity-10 text-warning rounded-circle mb-3">
                <i class="feather-cpu display-6"></i>
            </span>
            <h5 class="fw-bold font-sans text-dark mb-1">AI Mock Test Creator</h5>
            <p class="small text-muted mb-4">Input subject name and difficulty, and send an automated structured cURL process to Google Gemini API to generate 10 clean multiple-choice questions instantly logged into MySQL!</p>
            <a href="generator.php" class="btn btn-primary w-100 py-2.5 border-0 rounded fw-bold" style="background-color: var(--secondary-color);">
                Launch AI Generator Portal <i class="feather-arrow-right"></i>
            </a>
        </div>
        
        <!-- AI Blog & Article Team -->
        <div class="card p-4 border border-info border-opacity-30 rounded-3 text-center bg-info bg-opacity-5 mb-4 d-flex flex-column align-items-center text-dark">
            <span class="p-3 bg-info bg-opacity-10 text-info rounded-circle mb-3">
                <i class="feather-file-text display-6"></i>
            </span>
            <h5 class="fw-bold font-sans text-dark mb-1">AI Blog & SEO Creator</h5>
            <p class="small text-muted mb-4">Draft academic preparation tactics and news using Gemini, verify density analytics scores, select stock visuals, and publish directly.</p>
            <a href="blog-generator.php" class="btn btn-info text-white w-100 py-2.5 border-0 rounded fw-bold" style="background-color: #0284C7;">
                Launch Blog AI Creator <i class="feather-arrow-right"></i>
            </a>
        </div>
        
        <!-- System Backup Actions -->
        <div class="card p-4 bg-white border rounded shadow-sm">
            <h6 class="fw-bold text-dark font-sans mb-3"><i class="feather-database d-inline-block text-primary me-2"></i> Database Admin Tools</h6>
            <div class="d-grid gap-2">
                <a href="<?php echo BASE_URL; ?>database.sql" download class="btn btn-outline-dark btn-sm text-start py-2.5"><i class="feather-download me-2 text-muted"></i> Download Schema structure (.sql)</a>
                <button onclick="alert('Offline configuration simulated. Database backup exported safely!')" class="btn btn-outline-primary btn-sm text-start py-2.5"><i class="feather-file me-2 text-primary"></i> Export Users registry (.csv)</button>
            </div>
        </div>
    </div>
</div>

<?php
render_footer();
?>
