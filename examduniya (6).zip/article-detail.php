<?php
/**
 * ExamDuniya - Dynamic Blog Article Viewer & Metadata Schema Integrator
 */

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/app/Helpers/functions.php';

$slug = trim($_GET['slug'] ?? '');

$article = null;

if (!empty($_SESSION['blog_articles'])) {
    foreach ($_SESSION['blog_articles'] as $art) {
        if ($art['slug'] === $slug) {
            $article = $art;
            break;
        }
    }
}

// Fallback search if empty session
if (empty($article)) {
    $article = [
        'title' => 'How to Crack UP Police Written Exam 2026: Expert Mock Strategy',
        'slug' => 'crack-up-police-written-exam-strategy',
        'category' => 'Exam Prep Tips',
        'tags' => 'UP Police, Preparation, Mock Guide',
        'featured_image' => 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&q=80&w=600',
        'status' => 'Published',
        'published_at' => '2026-06-01 10:00:00',
        'seo_title' => 'Crack UP Police Exam 2026 Strategy Guide',
        'seo_desc' => 'Read expert tips, mock test guides, and exam formats to successfully crack the UP Police Written Examination on your very first trial.',
        'content' => 'Preparation for UP Police Constable requires consistency and a strict regimen of computer-based tests. First, review historical cutoffs, practice General Hindi, and solve daily mock trials to gain high velocity. Review previous year paper solutions diligently and align timing pacing filters.'
    ];
}

render_header($article['seo_title']);
?>

<!-- Dynamic JSON-LD Structured SEO Schema Injection -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "<?php echo s($article['title']); ?>",
  "image": [
    "<?php echo s($article['featured_image']); ?>"
  ],
  "datePublished": "<?php echo s($article['published_at']); ?>",
  "author": {
    "@type": "Organization",
    "name": "ExamDuniya",
    "url": "https://examduniya.in"
  },
  "publisher": {
    "@type": "Organization",
    "name": "ExamDuniya",
    "logo": {
      "@type": "ImageObject",
      "url": "https://examduniya.in/assets/img/logo.png"
    }
  },
  "description": "<?php echo s($article['seo_desc']); ?>"
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [{
    "@type": "ListItem",
    "position": 1,
    "name": "Home",
    "item": "https://examduniya.in/index.php"
  },{
    "@type": "ListItem",
    "position": 2,
    "name": "Articles",
    "item": "https://examduniya.in/articles.php"
  },{
    "@type": "ListItem",
    "position": 3,
    "name": "<?php echo s($article['title']); ?>",
    "item": "https://examduniya.in/article-detail.php?slug=<?php echo s($article['slug']); ?>"
  }]
}
</script>

<div class="row g-4 mt-2">
    <!-- Article main layout card -->
    <div class="col-lg-8 text-dark">
        <div class="card p-5 bg-white border-0 shadow-sm rounded-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="articles.php" class="text-decoration-none">Articles</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo s($article['category']); ?></li>
                </ol>
            </nav>

            <h1 class="fw-extrabold font-sans text-dark tracking-tight mb-3 mt-1" style="font-size: 32px; line-height: 1.3;">
                <?php echo s($article['title']); ?>
            </h1>

            <div class="d-flex align-items-center mb-4 py-2 border-bottom border-top">
                <span class="text-muted small me-4"><i class="feather-calendar me-1"></i> Published: <?php echo date('d-M-Y', strtotime($article['published_at'])); ?></span>
                <span class="text-muted small"><i class="feather-folder me-1"></i> Category: <?php echo s($article['category']); ?></span>
            </div>

            <img src="<?php echo s($article['featured_image']); ?>" class="img-fluid rounded mb-4 shadow" style="width:100%; max-height:400px; object-fit:cover;" alt="Featured Image">

            <!-- Middle Ad slot placeholder -->
            <div class="border p-3 rounded text-center bg-light mb-4 text-muted small">
                <strong>Google AdSense</strong> (Article Middle slot responsive)
            </div>

            <div class="content-body font-serif text-dark fs-5 mb-5" style="line-height:1.7;">
                <p><?php echo nl2br(s($article['content'])); ?></p>
            </div>

            <!-- Tags -->
            <div class="d-flex flex-wrap align-items-center gap-2 pt-3 border-top">
                <span class="small fw-bold text-muted me-2"><i class="feather-tag"></i> Tags:</span>
                <?php 
                    $tags = explode(',', $article['tags']);
                    foreach ($tags as $tag):
                ?>
                    <span class="badge bg-light text-dark border p-2"><?php echo s(trim($tag)); ?></span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Right Sidebar -->
    <div class="col-lg-4 text-dark">
        <!-- Related tests -->
        <div class="card p-4 border bg-white rounded-3 shadow-none mb-4">
            <h5 class="fw-bold font-sans text-dark mb-3">Trending Mock Tests</h5>
            <div class="list-group list-group-flush border-0">
                <a href="mock-tests.php" class="list-group-item list-group-item-action border-0 px-0 py-2.5">
                    <span class="fw-bold text-primary small d-block">Mock 1: UP Police Constable Full CBT</span>
                    <small class="text-muted">120 Minutes | 10 practice questions demo</small>
                </a>
                <a href="mock-tests.php" class="list-group-item list-group-item-action border-0 px-0 py-2.5">
                    <span class="fw-bold text-primary small d-block">Mock 2: SSC CGL Quantitative Practice Set</span>
                    <small class="text-muted">60 Minutes | Tier-1 pattern mapped</small>
                </a>
            </div>
        </div>

        <!-- Right sidebar Ad slot -->
        <div class="card border p-3 bg-light text-center rounded mb-4 shadow-sm">
            <div class="text-uppercase text-muted fs-11 fw-bold tracking-wider mb-2">Advertisement</div>
            <img src="https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=400" class="img-fluid rounded border mb-2" alt="Ad">
            <span class="small text-muted d-block mt-1">Get the complete paper mock guide pack to secure rank percentile credentials.</span>
        </div>
    </div>
</div>

<?php
render_footer();
?>
