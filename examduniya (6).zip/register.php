<?php
/**
 * ExamDuniya - Register Panel
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . 'dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($name) || empty($email) || empty($password)) {
        set_flash_message('danger', 'Please fulfill all compulsory inputs.');
    } else {
        $password_check = validate_password($password);
        if (!$password_check['valid']) {
            set_flash_message('danger', 'Password did not meet security rules limit: ' . implode(' ', $password_check['errors']));
        } else {
            // Prepare statement (PDO active)
            $stmt_check = $pdo->prepare("SELECT `id` FROM `users` WHERE `email` = :email LIMIT 1");
            $stmt_check->execute([':email' => $email]);
            if ($stmt_check->fetch()) {
                set_flash_message('danger', 'This email address is already registered on ExamDuniya.');
            } else {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                // Default role is User (3)
                $stmt_insert = $pdo->prepare("INSERT INTO `users` (`name`, `email`, `phone`, `password`, `role_id`, `is_verified`) VALUES (:name, :email, :phone, :password, 3, 1)");
                $success = $stmt_insert->execute([
                    ':name' => $name,
                    ':email' => $email,
                    ':phone' => $phone,
                    ':password' => $hashed
                ]);
                
                if ($success) {
                    set_flash_message('success', 'Aspirant desk registered successfully! Please login using your password.');
                    header('Location: ' . BASE_URL . 'login.php');
                    exit;
                } else {
                    set_flash_message('danger', 'System error registering account. Please check parameters.');
                }
            }
        }
    }
}

render_header("Register Desk");
?>

<div class="row align-items-center justify-content-center py-4 text-dark">
    <div class="col-md-6 col-lg-5">
        <div class="card border-0 bg-white shadow-lg p-4 p-md-5 rounded-4">
            <div class="text-center mb-4">
                <span class="p-3 bg-primary bg-opacity-10 text-primary rounded-circle d-inline-block mb-3">
                    <i class="feather-user-plus display-6"></i>
                </span>
                <h3 class="fw-bold font-sans">Aspirant Registration</h3>
                <p class="text-muted small">Begin tracking metrics, rank analytics, and unlock premium practice banks.</p>
            </div>
            
            <form action="" method="POST">
                <!-- Full name -->
                <div class="mb-3">
                    <label class="form-label small fw-bold text-secondary">Aspirant Full Name *</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0"><i class="feather-user text-muted"></i></span>
                        <input type="text" name="name" class="form-control border-0 bg-light py-2" placeholder="Amit Sharma" required>
                    </div>
                </div>

                <!-- Email address -->
                <div class="mb-3">
                    <label class="form-label small fw-bold text-secondary">Email Address *</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0"><i class="feather-mail text-muted"></i></span>
                        <input type="email" name="email" class="form-control border-0 bg-light py-2" placeholder="amit@examduniya.in" required>
                    </div>
                </div>

                <!-- Phone number -->
                <div class="mb-3">
                    <label class="form-label small fw-bold text-secondary">Mobile Number (Optional)</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0"><i class="feather-phone text-muted"></i></span>
                        <input type="tel" name="phone" class="form-control border-0 bg-light py-2" placeholder="9999999999">
                    </div>
                </div>

                <!-- Password key -->
                <div class="mb-4">
                    <label class="form-label small fw-bold text-secondary">Choose Password *</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0"><i class="feather-key text-muted"></i></span>
                        <input type="password" name="password" class="form-control border-0 bg-light py-2" placeholder="••••••••" required>
                    </div>
                    <div class="form-text text-muted mt-1" style="font-size: 11px; line-height: 1.4;">
                        <i class="feather-info me-1 text-primary"></i> Must be <strong>8+ characters</strong> long, contain at least <strong>1 number</strong>, and <strong>1 special character</strong> (e.g. @, #, $, !, %).
                    </div>
                </div>

                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-primary py-2.5 fw-bold border-0" style="background-color: var(--secondary-color);">Create Account <i class="feather-arrow-right ms-1"></i></button>
                </div>
                
                <div class="text-center mt-3 small text-muted">
                    Already registered? <a href="login.php" class="text-primary text-decoration-none fw-bold">Sign In</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
render_footer();
?>
