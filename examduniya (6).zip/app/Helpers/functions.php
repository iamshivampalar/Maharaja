<?php
/**
 * ExamDuniya - Reusable Helper Components & Layout Renderers
 * Professional styling following Government Exam Portal + Premium SaaS dashboard vibe.
 */

require_once dirname(dirname(__DIR__)) . '/config/config.php';

/**
 * Standard Header Layout
 */
function render_header($title = '') {
    $full_title = empty($title) ? SITE_NAME . ' | ' . SITE_TAGLINE : $title . ' - ' . SITE_NAME;
    $logged_in = !empty($_SESSION['user_id']);
    $role = $_SESSION['user_role'] ?? 'User';
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($full_title); ?></title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <!-- Bootstrap 5.3 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Feather Icons for Beautiful Vector Icons -->
    <link href="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.css" rel="stylesheet">
    <!-- Custom CSS Styles -->
    <style>
        :root {
            --primary-bg: #F8FAFC;
            --primary-card: #FFFFFF;
            --primary-color: #0F172A; /* Deep Slate Blue */
            --secondary-color: #2563EB; /* Bright Royal Blue */
            --accent-color: #F59E0B; /* Bright Warm Amber */
            --glow-color: rgba(37, 99, 235, 0.15);
            --gradient-accent: linear-gradient(135deg, #1E293B 0%, #0F172A 100%);
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--primary-bg);
            color: var(--primary-color);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        /* Glassmorphism Navigation */
        .navbar-custom {
            background-color: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }

        .navbar-brand {
            font-weight: 800;
            letter-spacing: -0.5px;
            color: #FFFFFF !important;
            display: flex;
            align-items: center;
        }

        .navbar-brand span {
            color: var(--secondary-color);
        }

        .nav-link {
            font-size: 14px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.8) !important;
            padding: 8px 16px !important;
            transition: all 0.2s ease;
        }

        .nav-link:hover, .nav-link.active {
            color: #FFFFFF !important;
            text-shadow: 0 0 10px rgba(255,255,255,0.3);
        }

        /* Hero banner style */
        .hero-banner {
            background: var(--gradient-accent);
            color: #FFFFFF;
            padding: 60px 0;
            position: relative;
            border-bottom: 2px solid var(--secondary-color);
        }

        /* Custom Glassmorphism Cards */
        .glass-card {
            background: var(--primary-card);
            border: 1px solid rgba(15, 23, 42, 0.08);
            border-radius: 12px;
            box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.04);
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .glass-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px -4px rgba(15, 23, 42, 0.08);
            border-color: rgba(37, 99, 235, 0.2);
        }

        /* Custom Badge styles */
        .badge-govt {
            background-color: rgba(37, 99, 235, 0.08);
            color: var(--secondary-color);
            border: 1px solid rgba(37, 99, 235, 0.15);
            font-weight: 600;
        }

        .badge-trending {
            background-color: rgba(245, 158, 11, 0.08);
            color: var(--accent-color);
            border: 1px solid rgba(245, 158, 11, 0.15);
            font-weight: 600;
        }

        /* Exam palette button states */
        .palette-btn {
            width: 38px;
            height: 38px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            border: 1px solid #E2E8F0;
            background-color: #F8FAFC;
            color: #64748B;
            transition: all 0.1s ease;
        }

        .palette-btn.unanswered {
            background-color: #EF4444; /* Red */
            color: #FFFFFF;
            border-color: #EF4444;
        }

        .palette-btn.answered {
            background-color: #22C55E; /* Green */
            color: #FFFFFF;
            border-color: #22C55E;
        }

        .palette-btn.marked {
            background-color: #8B5CF6; /* Purple */
            color: #FFFFFF;
            border-color: #8B5CF6;
        }

        .palette-btn.active-q {
            border: 2px solid #000000;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.3);
        }

        /* Footer */
        footer {
            background-color: #0F172A;
            color: rgba(255, 255, 255, 0.7);
            font-size: 14px;
            margin-top: auto;
            border-top: 4px solid var(--secondary-color);
        }

        footer a {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.2s ease;
        }

        footer a:hover {
            color: #FFFFFF;
            text-decoration: underline;
        }

        .footer-disclaimer {
            font-size: 11px;
            color: #94A3B8;
            line-height: 1.6;
        }
    </style>
</head>
<body>

    <!-- Dynamic Glassmorphism Header of ExamDuniya -->
    <?php
    $script_path = $_SERVER['SCRIPT_NAME'] ?? '';
    $is_admin_portal = (str_contains($script_path, '/admin/') || str_contains($script_path, 'admin/'));
    $is_developer_portal = (str_contains($script_path, '/developer/') || str_contains($script_path, 'developer/'));
    ?>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom py-3 sticky-top">
        <div class="container">
            <?php if ($is_admin_portal): ?>
                <a class="navbar-brand fs-4" href="<?php echo BASE_URL; ?>admin/dashboard.php">
                    <i class="feather-sliders me-2 text-primary"></i>Exam<span>Duniya Admin</span>
                </a>
            <?php elseif ($is_developer_portal): ?>
                <a class="navbar-brand fs-4" href="<?php echo BASE_URL; ?>developer/dashboard.php">
                    <i class="feather-code me-2 text-primary"></i>Exam<span>Duniya Dev</span>
                </a>
            <?php else: ?>
                <a class="navbar-brand fs-4" href="<?php echo BASE_URL; ?>index.php">
                    <i class="feather-book-open me-2 text-primary"></i>Exam<span>Duniya</span>
                </a>
            <?php endif; ?>
            
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#examDuniyaNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="examDuniyaNavbar">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                    <?php if ($is_admin_portal): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>admin/dashboard.php"><i class="feather-sliders me-1"></i> Admin HUD</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>admin/users.php"><i class="feather-users me-1"></i> Candidates</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>admin/reports.php"><i class="feather-pie-chart me-1"></i> Reports</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>admin/settings.php"><i class="feather-settings me-1"></i> Core Settings</a>
                        </li>
                        <?php if ($role === 'Developer'): ?>
                            <li class="nav-item">
                                <a class="nav-link text-info" href="<?php echo BASE_URL; ?>developer/dashboard.php"><i class="feather-code me-1"></i> Developer Console</a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item ms-lg-3">
                            <a class="nav-link text-warning fw-semibold" href="<?php echo BASE_URL; ?>dashboard.php"><i class="feather-external-link me-1"></i> Student View</a>
                        </li>
                    <?php elseif ($is_developer_portal): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>developer/dashboard.php"><i class="feather-terminal me-1"></i> Dev Cabinet</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>developer/generator.php"><i class="feather-cpu me-1"></i> AI Test Gen</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>developer/blog-generator.php"><i class="feather-file-text me-1"></i> AI Blog Gen</a>
                        </li>
                        <?php if ($role === 'Admin' || $role === 'Developer'): ?>
                            <li class="nav-item">
                                <a class="nav-link text-info" href="<?php echo BASE_URL; ?>admin/dashboard.php"><i class="feather-sliders me-1"></i> Admin Panel</a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item ms-lg-3">
                            <a class="nav-link text-warning fw-semibold" href="<?php echo BASE_URL; ?>dashboard.php"><i class="feather-external-link me-1"></i> Student View</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>index.php"><i class="feather-home me-1"></i> Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>jobs.php"><i class="feather-briefcase me-1"></i> Latest Jobs</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo BASE_URL; ?>mock-tests.php"><i class="feather-award me-1"></i> Mock Tests</a>
                        </li>
                        <?php if ($logged_in): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo BASE_URL; ?>dashboard.php"><i class="feather-tablet me-1"></i> My Dashboard</a>
                            </li>
                        <?php endif; ?>
                        <?php if ($role === 'Admin' || $role === 'Developer'): ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle text-info fw-semibold" href="#" id="adminDrop" role="button" data-bs-toggle="dropdown"><i class="feather-settings me-1"></i> Control Room</a>
                                <ul class="dropdown-menu border-0 shadow-lg mt-2">
                                    <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>admin/dashboard.php"><i class="feather-sliders me-2"></i> Admin Panel</a></li>
                                    <?php if ($role === 'Developer'): ?>
                                        <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>developer/dashboard.php"><i class="feather-code me-2"></i> Developer Desk</a></li>
                                    <?php endif; ?>
                                </ul>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
                
                <div class="d-flex align-items-center">
                    <?php if ($logged_in): ?>
                        <div class="dropdown">
                            <button class="btn btn-outline-light dropdown-toggle d-flex align-items-center bg-transparent border-0 py-1" type="button" id="userAccountMenu" data-bs-toggle="dropdown">
                                <img src="<?php echo BASE_URL; ?><?php echo htmlspecialchars($_SESSION['user_avatar'] ?? 'assets/img/default-avatar.png'); ?>" alt="Avatar" class="rounded-circle me-2" style="width: 32px; height: 32px; object-fit: cover;">
                                <span class="text-white small fw-bold me-1"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end border-0 shadow-lg mt-2 font-sans" style="min-width: 200px;">
                                <li class="px-3 py-2 border-bottom">
                                    <div class="fw-bold small text-dark"><?php echo htmlspecialchars($_SESSION['user_name']); ?></div>
                                    <div class="text-muted small" style="font-size: 11px;"><?php echo htmlspecialchars($_SESSION['user_email']); ?></div>
                                </li>
                                <?php if ($is_admin_portal || $is_developer_portal): ?>
                                    <li><a class="dropdown-item py-2 text-warning fw-semibold" href="<?php echo BASE_URL; ?>dashboard.php"><i class="feather-external-link me-2"></i> Exit Core Portals</a></li>
                                    <li><a class="dropdown-item py-2" href="<?php echo BASE_URL; ?>admin/settings.php"><i class="feather-settings me-2 text-muted"></i> System Settings</a></li>
                                <?php else: ?>
                                    <li><a class="dropdown-item py-2" href="<?php echo BASE_URL; ?>dashboard.php"><i class="feather-user me-2 text-muted"></i> Profile Overview</a></li>
                                    <li><a class="dropdown-item py-2" href="<?php echo BASE_URL; ?>dashboard.php#mock-history"><i class="feather-check-square me-2 text-muted"></i> Mock History</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger py-2" href="<?php echo BASE_URL; ?>logout.php"><i class="feather-log-out me-2"></i> Logout</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo BASE_URL; ?>login.php" class="btn btn-outline-light btn-sm me-2 px-3"><i class="feather-log-in me-1"></i> Login</a>
                        <a href="<?php echo BASE_URL; ?>register.php" class="btn btn-primary btn-sm px-3 shadow-sm border-0" style="background-color: var(--secondary-color);"><i class="feather-user-plus me-1"></i> Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content Area Wrapper -->
    <main class="flex-grow-1">
        <div class="container py-4">
            <?php 
            // Render any active sitewide scheduled announcements
            if (!empty($_SESSION['announcements'])) {
                $today = date('Y-m-d');
                foreach ($_SESSION['announcements'] as $ann) {
                    if ($ann['status'] === 'Active' && $today >= $ann['start_date'] && $today <= $ann['end_date']) {
                        $severity = s($ann['severity']);
                        $is_dismissible = $ann['can_close'] ? 'alert-dismissible' : '';
                        echo '<div class="alert alert-' . $severity . ' ' . $is_dismissible . ' fade show border-0 shadow-sm mb-4" role="alert">
                                <div class="d-flex align-items-center">
                                    <i class="feather-bell me-2 fs-5"></i>
                                    <div>' . s($ann['content']) . '</div>
                                </div>';
                        if ($ann['can_close']) {
                            echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
                        }
                        echo '</div>';
                    }
                }
            }
            display_flash_message(); 
            ?>
    <?php
}

/**
 * Standard Footer Layout
 */
function render_footer() {
    ?>
        </div>
    </main>

    <!-- Professional Information Board Footer of ExamDuniya -->
    <footer class="py-5 bg-dark">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4">
                    <h5 class="text-white fw-bold mb-3"><i class="feather-book-open text-primary me-2"></i>ExamDuniya</h5>
                    <p class="text-muted small">India's Smartest Government Exam Notification & Mock Test SaaS Platform. We assist aspirants in securing careers with structured notifications, insights, and highly responsive realistic CBT mock exams.</p>
                    <div class="d-flex gap-2">
                        <a href="https://t.me/examduniya_alerts" target="_blank" class="btn btn-primary btn-sm rounded-pill px-3 border-0" style="background-color: #229ED9;">
                            <i class="feather-send me-1"></i> Join Telegram Channel
                        </a>
                    </div>
                </div>
                <div class="col-6 col-lg-2 offset-lg-1">
                    <h6 class="text-white small fw-bold text-uppercase mb-3">Public Areas</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>jobs.php">Latest Vacancies</a></li>
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>mock-tests.php">Live Mock Tests</a></li>
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>index.php#exam-calendar">Exam Calendar</a></li>
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>index.php#current-affairs">Current Affairs</a></li>
                    </ul>
                </div>
                <div class="col-6 col-lg-2">
                    <h6 class="text-white small fw-bold text-uppercase mb-3">Legal Corner</h6>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>disclaimer.php">General Disclaimer</a></li>
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>privacy-policy.php">Privacy Regulations</a></li>
                        <li class="mb-2"><a href="<?php echo BASE_URL; ?>terms.php">Terms of Services</a></li>
                    </ul>
                </div>
                <div class="col-lg-3">
                    <h6 class="text-white small fw-bold text-uppercase mb-3">ExamDuniya Alerts</h6>
                    <p class="text-muted small mb-3">Subscribe to receive immediate email and browser push warnings when notifications are uploaded live.</p>
                    <form action="#" method="POST" class="row g-2" onsubmit="event.preventDefault(); alert('Thank you for subscribing to ExamDuniya alerts!');">
                        <div class="col">
                            <input type="email" class="form-control form-control-sm border-0" style="background-color: rgba(255,255,255,0.1); color: #FFF;" placeholder="name@email.com" required>
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary btn-sm border-0" style="background-color: var(--secondary-color);">Go</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <hr class="border-secondary my-4">

            <!-- Critical Govt Disclaimer Mandatory Notice -->
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="footer-disclaimer text-start">
                        <strong>Disclaimer Protection Clause:</strong> <?php echo htmlspecialchars(DISCLAIMER_TEXT); ?>
                    </div>
                </div>
                <div class="col-md-4 text-md-end text-muted mt-3 mt-md-0" style="font-size: 12px;">
                    &copy; 2026 ExamDuniya.in - All Rights Reserved. Crafted for cPanel.
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap Bundle JS with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Live Feather Icons replace trigger -->
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script>
        feather.replace();
    </script>
</body>
</html>
    <?php
}

/**
 * Standard Left Dashboard Navigation Sidebar
 */
function render_dashboard_sidebar($active_tab = 'profile') {
    $role = $_SESSION['user_role'] ?? 'User';
    ?>
    <div class="card glass-card p-3 border-0">
        <div class="text-center pb-4 mb-4 border-bottom">
            <img src="<?php echo BASE_URL; ?><?php echo htmlspecialchars($_SESSION['user_avatar'] ?? 'assets/img/default-avatar.png'); ?>" class="rounded-circle mb-3 border shadow-sm" style="width: 80px; height: 80px; object-fit: cover;" alt="Avatar">
            <div class="fw-bold text-dark fs-5 mb-1"><?php echo htmlspecialchars($_SESSION['user_name']); ?></div>
            <span class="badge bg-primary px-3 rounded-pill" style="font-size: 11px; background-color: var(--secondary-color) !important;"><?php echo htmlspecialchars($role); ?></span>
        </div>
        <div class="list-group list-group-flush border-0">
            <a href="<?php echo BASE_URL; ?>dashboard.php" class="list-group-item list-group-item-action border-0 px-3 py-2 rounded mb-1 d-flex align-items-center <?php echo $active_tab === 'profile' ? 'active bg-primary text-white' : ''; ?>">
                <i class="feather-user me-3 fs-5"></i> Profile Overview
            </a>
            <a href="<?php echo BASE_URL; ?>dashboard.php#mock-history" class="list-group-item list-group-item-action border-0 px-3 py-2 rounded mb-1 d-flex align-items-center <?php echo $active_tab === 'attempts' ? 'active bg-primary text-white' : ''; ?>">
                <i class="feather-check-square me-3 fs-5"></i> Mock Test History
            </a>
            <a href="<?php echo BASE_URL; ?>dashboard.php#performance-analytics" class="list-group-item list-group-item-action border-0 px-3 py-2 rounded mb-1 d-flex align-items-center <?php echo $active_tab === 'analytics' ? 'active bg-primary text-white' : ''; ?>">
                <i class="feather-trending-up me-3 fs-5"></i> Analytics Dashboard
            </a>
            <a href="<?php echo BASE_URL; ?>subscribe.php" class="list-group-item list-group-item-action border-0 px-3 py-2 rounded mb-1 d-flex align-items-center <?php echo $active_tab === 'subscriptions' ? 'active bg-primary text-white' : ''; ?>">
                <i class="feather-shopping-bag me-3 fs-5"></i> Buy Test Packs
            </a>
            <a href="<?php echo BASE_URL; ?>logout.php" class="list-group-item list-group-item-action border-0 px-3 py-2 text-danger rounded mb-1 d-flex align-items-center">
                <i class="feather-log-out me-3 fs-5"></i> Logout
            </a>
        </div>
    </div>
    <?php
}
