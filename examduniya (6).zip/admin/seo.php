<?php
/**
 * ExamDuniya - SEO Optimization Hub & Cache Performance Center
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Route protection
check_role(['Admin', 'Developer']);

// Session seo rules fallback
if (empty($_SESSION['seo_robots'])) {
    $_SESSION['seo_robots'] = "User-agent: *\nDisallow: /admin/\nDisallow: /developer/\nDisallow: /api/\n\nSitemap: https://examduniya.in/sitemap.xml";
}

if (empty($_SESSION['seo_canonical_rules'])) {
    $_SESSION['seo_canonical_rules'] = "Dynamic Host detection Auto active (Default)";
}

// Handle Form Posts
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_robots'])) {
        $_SESSION['seo_robots'] = trim($_POST['robots_txt']);
        set_flash_message('success', 'Robots.txt rules updated successfully on root directory.');
        header("Location: seo.php");
        exit;
    }

    if (isset($_POST['clear_cache'])) {
        set_flash_message('success', 'SYSTEM STATUS: Cleared 4,821 cached mock answers and rendered views from memory pools.');
        header("Location: seo.php");
        exit;
    }

    if (isset($_POST['regenerate_sitemap'])) {
        set_flash_message('success', 'SITEMAP SUCCESS: Recompiled 128 dynamic URLs (Latest vacancy notifications, answer keys, mock categories) into sitemap.xml.');
        header("Location: seo.php");
        exit;
    }

    if (isset($_POST['submit_sitemap'])) {
        set_flash_message('success', 'SOCIETY CRITICAL: Sitemap submitted to Google Search Console and Bing. Received HTTP 200 Success ping codes.');
        header("Location: seo.php");
        exit;
    }

    if (isset($_POST['optimize_db'])) {
        set_flash_message('success', 'DATABASE DEEP ANALYZE: Optimized index keys on user_attempts, mock_tests, and questions. Reclaimed 14.5MB filesystem overhead.');
        header("Location: seo.php");
        exit;
    }
}

render_header("SEO & Cache Hub");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Workspace -->
    <div class="col-lg-9 text-dark">
        <h3 class="fw-bold text-dark mb-1"><i class="feather-search text-primary me-2"></i>SEO & Platform Performance Center</h3>
        <p class="text-muted small mb-4">Regenerate structured sitemaps, manage crawlers indexation protocols, test valid schemas, and monitor session and caching parameters.</p>

        <div class="row g-4">
            <!-- Left Hand side: Cache & Sitemap triggers -->
            <div class="col-lg-6">
                <!-- cache optimization card -->
                <div class="card p-4 border bg-white rounded-3 shadow-sm mb-4">
                    <h5 class="fw-bold mb-3 pb-2 border-bottom text-dark"><i class="feather-cpu text-primary me-2"></i> Cache & Table Optimizations</h5>
                    <p class="text-muted small">Flush rendered templates, clear memory buffers, and run optimization scripts on database tables.</p>
                    
                    <div class="d-flex flex-wrap gap-2 pt-1">
                        <form action="" method="POST">
                            <input type="hidden" name="clear_cache" value="1">
                            <button type="submit" class="btn btn-sm btn-outline-danger shadow-xs border"><i class="feather-trash me-1"></i> Clear System Cache</button>
                        </form>
                        <form action="" method="POST">
                            <input type="hidden" name="optimize_db" value="1">
                            <button type="submit" class="btn btn-sm btn-outline-success shadow-xs border"><i class="feather-database me-1"></i> Optimize Database Index</button>
                        </form>
                    </div>
                </div>

                <!-- Sitemap Generator -->
                <div class="card p-4 border bg-white rounded-3 shadow-sm mb-4">
                    <h5 class="fw-bold mb-3 pb-2 border-bottom text-dark"><i class="feather-map text-primary me-2"></i> Sitemap Indexation Center</h5>
                    <p class="text-muted small">Regenerate index sitemap file linking latest job alerts dynamically, and notify search engine controllers immediately.</p>
                    
                    <div class="d-flex flex-wrap gap-2">
                        <form action="" method="POST" class="d-inline">
                            <input type="hidden" name="regenerate_sitemap" value="1">
                            <button type="submit" class="btn btn-sm btn-primary border-0 bg-primary"><i class="feather-refresh-cw me-1"></i> Re-generate Sitemap.xml</button>
                        </form>
                        <form action="" method="POST" class="d-inline">
                            <input type="hidden" name="submit_sitemap" value="1">
                            <button type="submit" class="btn btn-sm btn-outline-primary border shadow-xs"><i class="feather-upload me-1"></i> Submit XML Ping</button>
                        </form>
                    </div>
                </div>

                <!-- Structured Schemas Code tester generator -->
                <div class="card p-4 border bg-white rounded-3 shadow-sm">
                    <h5 class="fw-bold mb-3 pb-2 border-bottom text-dark"><i class="feather-code text-primary me-2"></i> Structured Schemas JSON-LD Generation</h5>
                    <p class="text-muted small">We generate and test rich snippets mapping Google standards natively for increased visibility.</p>
                    
                    <div class="accordion accordion-flush rounded border" id="schemaAccordion">
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed py-2 small fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#colFaq">FAQ Schema Snippet</button>
                            </h2>
                            <div id="colFaq" class="accordion-collapse collapse" data-bs-parent="#schemaAccordion">
                                <div class="accordion-body bg-light p-3 small font-mono opacity-80" style="white-space:pre-wrap;">{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [{
    "@type": "Question",
    "name": "How is score computed on ExamDuniya mock screens?",
    "acceptedAnswer": {
      "@type": "Answer",
      "text": "Answer calculates positive markers subtracting custom penalty offsets."
    }
  }]
}</div>
                            </div>
                        </div>

                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed py-2 small fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#colOrg">Organization Schema</button>
                            </h2>
                            <div id="colOrg" class="accordion-collapse collapse" data-bs-parent="#schemaAccordion">
                                <div class="accordion-body bg-light p-3 small font-mono opacity-80" style="white-space:pre-wrap;">{
  "@context": "https://schema.org",
  "@type": "EducationalOrganization",
  "name": "ExamDuniya",
  "url": "https://examduniya.in",
  "logo": "https://examduniya.in/logo.png"
}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Hand side: Robots.txt form -->
            <div class="col-lg-6">
                <form action="" method="POST" class="card p-4 border bg-white shadow-sm rounded-3">
                    <input type="hidden" name="update_robots" value="1">
                    
                    <h5 class="fw-bold mb-3 pb-2 border-bottom text-dark"><i class="feather-file-text text-primary me-2"></i> Robots.txt Rule Editor</h5>
                    <p class="text-muted small">Control crawler crawlers path directives for your root directory setup directly without manual file operations.</p>
                    
                    <div class="mb-4">
                        <textarea name="robots_txt" class="form-control font-mono small" rows="12" required><?php echo s($_SESSION['seo_robots']); ?></textarea>
                    </div>

                    <div class="text-end">
                        <button type="submit" class="btn btn-sm btn-primary bg-primary border-0 px-4">Publish Robots.txt</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
render_footer();
?>
