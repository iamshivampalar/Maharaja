<?php
/**
 * ExamDuniya - Custom URL Redirect Manager & Custom Shortener Dashboard
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Route Guard
check_role(['Admin', 'Developer']);

// Session fallback list for Redirects
if (empty($_SESSION['custom_redirects'])) {
    $_SESSION['custom_redirects'] = [
        [
            'id' => 1,
            'source' => '/go/ssc',
            'target' => 'https://ssc.gov.in',
            'type' => '301 Permanent',
            'clicks' => 5293,
            'visitors' => 4180,
            'referrers' => ['Telegram' => 3890, 'Direct' => 893, 'Google' => 510]
        ],
        [
            'id' => 2,
            'source' => '/go/up-police',
            'target' => 'https://uppbpb.gov.in',
            'type' => '302 Temporary',
            'clicks' => 8420,
            'visitors' => 7104,
            'referrers' => ['Telegram' => 6100, 'YouTube' => 1920, 'Direct' => 400]
        ],
        [
            'id' => 3,
            'source' => '/go/railway-ntpc',
            'target' => '/jobs.php?q=railway',
            'type' => '301 Permanent',
            'clicks' => 1243,
            'visitors' => 1020,
            'referrers' => ['YouTube' => 800, 'Telegram' => 343, 'Google' => 100]
        ]
    ];
}

// Form logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_redirect'])) {
        $source = trim($_POST['source']);
        $target = trim($_POST['target']);
        $type = $_POST['type'];

        // Normalize source
        if (!str_starts_with($source, '/go/')) {
            $source = '/go/' . ltrim($source, '/');
        }

        $new_redirect = [
            'id' => rand(100, 999),
            'source' => $source,
            'target' => $target,
            'type' => $type,
            'clicks' => 0,
            'visitors' => 0,
            'referrers' => ['Direct' => 0]
        ];

        $_SESSION['custom_redirects'][] = $new_redirect;
        set_flash_message('success', 'Custom Redirect ' . s($source) . ' registered successfully!');
        header("Location: redirects.php");
        exit;
    }

    if (isset($_POST['delete_redirect'])) {
        $id = (int)$_POST['redirect_id'];
        foreach ($_SESSION['custom_redirects'] as $key => $r) {
            if ($r['id'] === $id) {
                unset($_SESSION['custom_redirects'][$key]);
                break;
            }
        }
        $_SESSION['custom_redirects'] = array_values($_SESSION['custom_redirects']);
        set_flash_message('warning', 'Redirect element deleted successfully.');
        header("Location: redirects.php");
        exit;
    }
}

render_header("URL Redirects & Shortener");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Pane -->
    <div class="col-lg-9 text-dark">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="feather-link text-primary me-2"></i>URL Redirects & Link Shortener</h3>
                <p class="text-muted small mb-0">Create search-engine friendly redirects (301 Permanent / 302 Temporary) and custom links for Telegram posts.</p>
            </div>
            <button class="btn btn-primary bg-primary border-0 d-flex align-items-center" data-bs-toggle="modal" data-bs-target="#modalAddRedirect">
                <i class="feather-plus me-1"></i> Add Custom Link
            </button>
        </div>

        <!-- Links stats row -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm bg-white rounded-3">
                    <span class="text-uppercase text-muted fs-11 fw-bold">Active shortlinks</span>
                    <h3 class="fw-bold mb-0 text-dark"><?php echo count($_SESSION['custom_redirects']); ?> Links</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm bg-white rounded-3">
                    <span class="text-uppercase text-muted fs-11 fw-bold">Routed clicks</span>
                    <h3 class="fw-bold mb-0 text-primary">14,956</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm bg-white rounded-3">
                    <span class="text-uppercase text-muted fs-11 fw-bold">Unique users</span>
                    <h3 class="fw-bold mb-0 text-success">12,304</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 border-0 shadow-sm bg-white rounded-3">
                    <span class="text-uppercase text-muted fs-11 fw-bold">Telegram Share Core</span>
                    <h3 class="fw-bold mb-0 text-info">66.8%</h3>
                </div>
            </div>
        </div>

        <!-- Redirects List Panel -->
        <div class="card border-0 shadow-sm bg-white p-4 mb-4">
            <h5 class="fw-bold mb-3">Enterprise Redirection Routings</h5>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light text-uppercase font-sans" style="font-size: 11px;">
                        <tr>
                            <th class="py-3">Short URL Route</th>
                            <th class="py-3">Target Destination</th>
                            <th class="py-3">HTTP Type</th>
                            <th class="py-3 text-center">Clicks</th>
                            <th class="py-3 text-center">Visitors</th>
                            <th class="py-3">Top Referrers</th>
                            <th class="py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody style="font-size: 13px;">
                        <?php foreach ($_SESSION['custom_redirects'] as $r): ?>
                            <tr>
                                <td class="fw-bold font-mono text-primary">
                                    <?php echo s($r['source']); ?>
                                </td>
                                <td class="text-muted" style="max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                    <?php echo s($r['target']); ?>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border"><?php echo s($r['type']); ?></span>
                                </td>
                                <td class="text-center fw-medium"><?php echo number_format($r['clicks']); ?></td>
                                <td class="text-center fw-medium text-success"><?php echo number_format($r['visitors']); ?></td>
                                <td style="font-size: 11px;">
                                    <?php foreach ($r['referrers'] as $ref => $count): ?>
                                        <span class="badge bg-light text-muted me-1 border shadow-xs"><?php echo s($ref); ?>: <?php echo $count; ?></span>
                                    <?php endforeach; ?>
                                </td>
                                <td class="text-center">
                                    <form action="" method="POST" onsubmit="return confirm('Ensure this redirection rule is safe to delete?');" class="d-inline">
                                        <input type="hidden" name="redirect_id" value="<?php echo $r['id']; ?>">
                                        <input type="hidden" name="delete_redirect" value="1">
                                        <button type="submit" class="btn btn-sm btn-outline-danger p-1 border">
                                            <i class="feather-trash-2"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- SEO Redirect Info -->
        <div class="card p-4 border-0 text-white rounded shadow-sm mb-4" style="background: var(--gradient-accent);">
            <h5 class="fw-bold mb-2"><i class="feather-zap me-2"></i> How redirection redirects traffic</h5>
            <p class="small mb-0 opacity-80" style="line-height:1.6;">Our dynamic route shortener redirects clients immediately to custom URL coordinates. Shortlinks starting with <code>/go/</code> are parsed inside <code>go.php</code> dynamically while tracking visitor statistics and logging referer headers safely before sending users to their target board.</p>
        </div>
    </div>
</div>

<!-- Modal Redirect -->
<div class="modal fade" id="modalAddRedirect" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title fw-bold"><i class="feather-link me-2"></i> Add Short Link / Redirection</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST" class="modal-body p-4 text-dark">
                <input type="hidden" name="add_redirect" value="1">

                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label small fw-bold">Short URL Suffix (Source) *</label>
                        <div class="input-group">
                            <span class="input-group-text font-mono bg-light" style="font-size:12px;">examduniya.in/go/</span>
                            <input type="text" name="source" class="form-control font-mono" placeholder="ssc-gd-form" required>
                        </div>
                        <small class="text-muted d-block mt-1">Example: entering <code>up-police</code> maps <code>examduniya.in/go/up-police</code></small>
                    </div>

                    <div class="col-12">
                        <label class="form-label small fw-bold">Target Route URL (Destination) *</label>
                        <input type="text" name="target" class="form-control" placeholder="https://ssc.gov.in/portal" required>
                        <small class="text-muted">Supports absolute URLs or relative paths like <code>/jobs.php</code></small>
                    </div>

                    <div class="col-12">
                        <label class="form-label small fw-bold">HTTP Redirect Status *</label>
                        <select name="type" class="form-select" required>
                            <option value="301 Permanent">301 - Permanent Redirect (Recommended for SEO migration)</option>
                            <option value="302 Temporary">302 - Temporary Redirect (For campaigns / shortlinks)</option>
                        </select>
                    </div>
                </div>

                <div class="text-end pt-3 border-top mt-4">
                    <button type="button" class="btn btn-outline-secondary btn-sm px-3 me-2" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm px-4 bg-primary border-0">Publish Redirection</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
render_footer();
?>
