<?php
/**
 * ExamDuniya - Broadcast Publishing, Telegram Integration & Newsletter Engine
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Check role
check_role(['Admin', 'Developer']);

// Session settings handles for Telegram & Email template defaults
if (empty($_SESSION['broadcast_settings'])) {
    $_SESSION['broadcast_settings'] = [
        'telegram_bot_token' => '5928340182:AAFlk_82930489028AJfkoZ-92k3',
        'telegram_channel_id' => '@examduniya_alerts',
        'telegram_group_id' => '-100482930492',
        'telegram_template' => "📢 *NEW GOVT JOB DIRECT ALERT!* \n\n📌 *Board:* {organization}\n🎓 *Post Name:* {post_name}\n💼 *Vacancies:* {total_vacancies}\n⏳ *Apply Last Date:* {end_date}\n\n👉 *Download notification & apply online here:* \n{apply_url}\n\nJoin @examduniya_alerts for constant alerts!",
        'email_template_subject' => "ExamDuniya Alert: {title} is now active",
        'email_template_body' => "<p>Dear Aspirant,</p><p>We have uploaded a new government vacancy on ExamDuniya portal: <strong>{title}</strong> with total <strong>{total_vacancies} posts</strong> available under {organization}.</p><p><a href='{apply_url}'>Click here to view complete eligibility & apply immediately</a>.</p><p>Regards,<br>ExamDuniya Team</p>"
    ];
}

// Session log database fallback
if (empty($_SESSION['broadcast_logs'])) {
    $_SESSION['broadcast_logs'] = [
        [
            'id' => 1,
            'title' => 'UP Police Constable 2026',
            'channel' => 'Telegram & Email',
            'status' => 'Delivered',
            'recipients' => '4,920 Emails | Telegram Channel',
            'sent_at' => '2026-06-01 12:30:00'
        ],
        [
            'id' => 2,
            'title' => 'SSC GD Constable Notification',
            'channel' => 'Telegram Only',
            'status' => 'Delivered',
            'recipients' => 'Telegram Channel @examduniya_alerts',
            'sent_at' => '2026-05-15 09:12:00'
        ]
    ];
}

// Handle Forms
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_settings'])) {
        $_SESSION['broadcast_settings']['telegram_bot_token'] = trim($_POST['telegram_bot_token']);
        $_SESSION['broadcast_settings']['telegram_channel_id'] = trim($_POST['telegram_channel_id']);
        $_SESSION['broadcast_settings']['telegram_group_id'] = trim($_POST['telegram_group_id']);
        $_SESSION['broadcast_settings']['telegram_template'] = trim($_POST['telegram_template']);
        $_SESSION['broadcast_settings']['email_template_subject'] = trim($_POST['email_template_subject']);
        $_SESSION['broadcast_settings']['email_template_body'] = trim($_POST['email_template_body']);
        
        set_flash_message('success', 'Telegram broadcast credentials and Email newsletter triggers updated successfully!');
        header("Location: publishing.php");
        exit;
    }

    if (isset($_POST['test_telegram'])) {
        // Mock instant Telegram broadcast test
        $log = [
            'id' => rand(100, 999),
            'title' => 'Manual Test Broadcast (Ad-hoc)',
            'channel' => 'Telegram Channel & Group',
            'status' => 'Delivered',
            'recipients' => 'Telegram Alerts Node Test',
            'sent_at' => date('Y-m-d H:i:s')
        ];
        $_SESSION['broadcast_logs'] = array_merge([$log], $_SESSION['broadcast_logs']);
        set_flash_message('success', 'Test Telegram API payload dispatched successfully. Check target output channel!');
        header("Location: publishing.php");
        exit;
    }
}

render_header("Broadcast & Publishing Scheduler");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Pane -->
    <div class="col-lg-9 text-dark">
        <h3 class="fw-bold text-dark mb-1"><i class="feather-send text-primary me-2"></i>Scheduled Publishing & Broadcasting</h3>
        <p class="text-muted small mb-4">Set up automated notifications delivery pipelines. Instant broadcast or scheduling allows notifications to reach users on Telegram and Email seamlessly.</p>

        <div class="row g-4">
            <!-- Left inputs panel -->
            <div class="col-lg-6">
                <form action="" method="POST" class="card border-0 shadow-sm p-4 bg-white mb-4">
                    <input type="hidden" name="save_settings" value="1">
                    
                    <h5 class="fw-bold mb-3 pb-2 border-bottom"><i class="feather-send me-1"></i> Telegram API Configuration</h5>
                    
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Telegram Bot Token Key *</label>
                        <input type="text" name="telegram_bot_token" class="form-control font-mono form-control-sm" value="<?php echo s($_SESSION['broadcast_settings']['telegram_bot_token']); ?>" placeholder="5928..." required>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">Alert Channel Username *</label>
                            <input type="text" name="telegram_channel_id" class="form-control font-mono form-control-sm" value="<?php echo s($_SESSION['broadcast_settings']['telegram_channel_id']); ?>" placeholder="@channel" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Discussion Group ID</label>
                            <input type="text" name="telegram_group_id" class="form-control font-mono form-control-sm" value="<?php echo s($_SESSION['broadcast_settings']['telegram_group_id']); ?>" placeholder="-100...">
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-bold">Dynamic Markdown Telegram Template *</label>
                        <textarea name="telegram_template" class="form-control font-mono small" rows="5" required><?php echo s($_SESSION['broadcast_settings']['telegram_template']); ?></textarea>
                        <div class="text-muted fs-11 mt-1">Available wildcards: <code>{title}</code>, <code>{organization}</code>, <code>{post_name}</code>, <code>{total_vacancies}</code>, <code>{end_date}</code>, <code>{apply_url}</code></div>
                    </div>

                    <h5 class="fw-bold mb-3 pb-2 border-bottom mt-2"><i class="feather-mail me-1"></i> Email Newsletter Broadcasts</h5>
                    
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Default Email Alert Subject Template *</label>
                        <input type="text" name="email_template_subject" class="form-control form-control-sm" value="<?php echo s($_SESSION['broadcast_settings']['email_template_subject']); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-bold font-sans">Dynamic HTML Email Template Body *</label>
                        <textarea name="email_template_body" class="form-control font-mono small" rows="5" required><?php echo s($_SESSION['broadcast_settings']['email_template_body']); ?></textarea>
                    </div>

                    <div class="text-end">
                        <button type="submit" class="btn btn-primary bg-primary border-0 btn-sm px-4">Save Configuration parameters</button>
                    </div>
                </form>
            </div>

            <!-- Right outputs and history logs -->
            <div class="col-lg-6">
                <!-- Test broadcast buttons -->
                <div class="card p-4 border bg-white mb-4 shadow-sm rounded-3">
                    <h5 class="fw-bold mb-2">Instant Broadcast Trigger Desk</h5>
                    <p class="text-muted small">Dispatch an ad-hoc heartbeat or testing payload directly through active server integrations to verify your bot tokens.</p>
                    <form action="" method="POST" class="d-inline">
                        <input type="hidden" name="test_telegram" value="1">
                        <button type="submit" class="btn btn-outline-primary shadow-xs btn-sm d-inline-flex align-items-center"><i class="feather-terminal me-1"></i> Test Telegram Gateway</button>
                    </form>
                </div>

                <!-- Broadcast history logs -->
                <div class="card p-4 border bg-white mb-4 shadow-sm rounded-3">
                    <h5 class="fw-bold mb-3">Broadcast Distribution History Logs</h5>
                    <div class="list-group list-group-flush border-0">
                        <?php foreach ($_SESSION['broadcast_logs'] as $log): ?>
                            <div class="list-group-item border-bottom px-0 py-3">
                                <div class="d-flex justify-content-between align-items-start mb-1">
                                    <h6 class="fw-bold mb-0 text-dark small" style="max-width:200px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;"><?php echo s($log['title']); ?></h6>
                                    <span class="badge bg-success shadow-xs"><?php echo s($log['status']); ?></span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center text-muted" style="font-size: 11px;">
                                    <span>Channels: <strong><?php echo s($log['channel']); ?></strong></span>
                                    <span class="font-mono"><?php echo s($log['sent_at']); ?></span>
                                </div>
                                <div class="text-muted small mt-1 font-sans" style="font-size: 11px;">
                                    <i class="feather-info me-1"></i> Scope: <?php echo s($log['recipients']); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
render_footer();
?>
