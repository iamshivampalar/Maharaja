<?php
/**
 * ExamDuniya - Sitewide Announcement & Popup Alerts Dispatcher
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Check role
check_role(['Admin', 'Developer']);

// Session announcement items fallback storage
if (empty($_SESSION['announcements'])) {
    $_SESSION['announcements'] = [
        [
            'id' => 1,
            'title' => 'UP Police Constable Mock Series Open!',
            'type' => 'Sitewide Banner',
            'severity' => 'info',
            'content' => '🎁 UP Police Special Mock Practice Demo Test is now LIVE for all registered aspirants. Try the Free Trial today!',
            'start_date' => '2026-06-01',
            'end_date' => '2026-06-15',
            'status' => 'Active',
            'can_close' => 1
        ],
        [
            'id' => 2,
            'title' => 'Maintenance window warning',
            'type' => 'Urgent Alert Bar',
            'severity' => 'danger',
            'content' => '⚠️ SYSTEM SCHEDULED MAINTENANCE: Payment gate and database indexing is scheduled on June 5 between 02:00 AM - 04:00 AM.',
            'start_date' => '2026-06-04',
            'end_date' => '2026-06-05',
            'status' => 'Active',
            'can_close' => 0
        ]
    ];
}

// Handle Forms
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_announcement'])) {
        $new_ann = [
            'id' => rand(100, 999),
            'title' => trim($_POST['title']),
            'type' => $_POST['type'],
            'severity' => $_POST['severity'],
            'content' => trim($_POST['content']),
            'start_date' => $_POST['start_date'],
            'end_date' => $_POST['end_date'],
            'status' => isset($_POST['status']) ? 'Active' : 'Expired',
            'can_close' => isset($_POST['can_close']) ? 1 : 0
        ];
        $_SESSION['announcements'][] = $new_ann;
        set_flash_message('success', 'New Alert Campaign is successfully scheduled and queued!');
        header("Location: announcements.php");
        exit;
    }

    if (isset($_POST['delete_announcement'])) {
        $id = (int)$_POST['ann_id'];
        foreach ($_SESSION['announcements'] as $key => $ann) {
            if ($ann['id'] === $id) {
                unset($_SESSION['announcements'][$key]);
                break;
            }
        }
        $_SESSION['announcements'] = array_values($_SESSION['announcements']);
        set_flash_message('warning', 'Notice campaign removed securely.');
        header("Location: announcements.php");
        exit;
    }
}

render_header("Announcements & Notice Board");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Pane -->
    <div class="col-lg-9 text-dark">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="feather-bell text-primary me-2"></i>Announcement & Popup Dispatcher</h3>
                <p class="text-muted small mb-0">Push sitewide bulletins, announcement bars, or popup screens with specific start and end ranges.</p>
            </div>
            <button class="btn btn-primary bg-primary border-0 d-flex align-items-center" data-bs-toggle="modal" data-bs-target="#modalAddAlert">
                <i class="feather-plus me-1"></i> Register Announcement
            </button>
        </div>

        <div class="card border-0 bg-white shadow-sm p-4 mb-4">
            <h5 class="fw-bold mb-3">Notice Bulletins List</h5>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light text-uppercase font-sans" style="font-size: 11px;">
                        <tr>
                            <th class="py-3">Notice Title Header</th>
                            <th class="py-3">Display Type</th>
                            <th class="py-3">Theme Style</th>
                            <th class="py-3">Date Schedule Range</th>
                            <th class="py-3 text-center">Status</th>
                            <th class="py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody style="font-size: 13px;">
                        <?php foreach ($_SESSION['announcements'] as $ann): ?>
                            <tr>
                                <td class="fw-bold">
                                    <div class="text-dark mb-0.5"><?php echo s($ann['title']); ?></div>
                                    <span class="text-muted small font-mono" style="font-size:11px;"><?php echo s(substr($ann['content'], 0, 80)); ?>...</span>
                                </td>
                                <td><span class="badge bg-light text-dark shadow-xs border"><?php echo s($ann['type']); ?></span></td>
                                <td>
                                    <span class="badge bg-<?php echo s($ann['severity']); ?> text-capitalize"><?php echo s($ann['severity']); ?></span>
                                </td>
                                <td>
                                    <span class="small font-mono text-muted"><?php echo s($ann['start_date']); ?> to <?php echo s($ann['end_date']); ?></span>
                                </td>
                                <td class="text-center">
                                    <?php if ($ann['status'] === 'Active'): ?>
                                        <span class="badge bg-success">Active Campaign</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Expired</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <form action="" method="POST" onsubmit="return confirm('Do you wish to remove this banner notice?');" class="d-inline">
                                        <input type="hidden" name="ann_id" value="<?php echo $ann['id']; ?>">
                                        <input type="hidden" name="delete_announcement" value="1">
                                        <button type="submit" class="btn btn-sm btn-outline-danger p-1 border">
                                            <i class="feather-trash-2"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Add Notice -->
<div class="modal fade animate" id="modalAddAlert" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content border-0">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title fw-bold"><i class="feather-bell text-primary me-2"></i> Create Announcement Banner</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST" class="modal-body p-4 text-dark text-start">
                <input type="hidden" name="add_announcement" value="1">

                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label small fw-bold">Bulletin Campaign Name *</label>
                        <input type="text" name="title" class="form-control" placeholder="UP Police Trial Announcement" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Display Layout Type *</label>
                        <select name="type" class="form-select" required>
                            <option value="Sitewide Banner">Sitewide Header Banner</option>
                            <option value="Urgent Alert Bar">Sticky Top Alert Bar</option>
                            <option value="Login Notice Box">Login & Register Notice Box</option>
                            <option value="Popup Overlay Notice">Dismissible Popup Overlay</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Visual Palette Severity Theme *</label>
                        <select name="severity" class="form-select" required>
                            <option value="primary">Primary Blue</option>
                            <option value="success">Success Green</option>
                            <option value="warning">Warning Amber</option>
                            <option value="danger">Danger Crimson Red</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Start Activation Date *</label>
                        <input type="date" name="start_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Expiration End Date *</label>
                        <input type="date" name="end_date" class="form-control" value="<?php echo date('Y-m-d', strtotime('+15 days')); ?>" required>
                    </div>

                    <div class="col-12">
                        <label class="form-label small fw-bold">Notice Text Content (Supports Markdown or HTML Emoji) *</label>
                        <textarea name="content" class="form-control" rows="4" placeholder="Type notice banner details..." required></textarea>
                    </div>

                    <div class="col-12">
                        <div class="form-check form-switch mt-2">
                            <input class="form-check-input" type="checkbox" name="can_close" id="flexCanCloseChecked" checked>
                            <label class="form-check-label small fw-bold" for="flexCanCloseChecked">Allow aspirants to close / dismiss this bulletin notice</label>
                        </div>
                        <input type="hidden" name="status" value="1">
                    </div>
                </div>

                <div class="border-top pt-3 text-end mt-4">
                    <button type="button" class="btn btn-outline-secondary btn-sm px-3 me-2" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm px-4 bg-primary border-0">Save & Air Bulletin</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
render_footer();
?>
