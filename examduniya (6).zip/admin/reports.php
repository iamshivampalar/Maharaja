<?php
/**
 * ExamDuniya - Analytical Reports & Financial Metrics Engine
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Check role
check_role(['Admin', 'Developer']);

// Session reports statistics
$revenue_total = "₹ 4,20,950.00";
$total_subscriptions = 1420;
$average_order_value = "₹ 296.00";
$completions_count = 14920;

render_header("SaaS Metrics & Reports Dashboard");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Workspace -->
    <div class="col-lg-9 text-dark">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="feather-pie-chart text-primary me-2"></i>Performance Reporting HUD</h3>
                <p class="text-muted small mb-0">Generate financial breakdowns, examine conversion coefficients and export analytical datasets.</p>
            </div>
            
            <!-- Export Triggers -->
            <div class="d-flex gap-1.5">
                <button onclick="alert('Compiling analytical worksheet... Exporting Excel sheet: examduniya_reports_2026.xlsx');" class="btn btn-sm btn-outline-success border shadow-xs d-flex align-items-center"><i class="feather-file text-success me-1"></i> Excel</button>
                <button onclick="alert('Formatting PDF layouts... Exporting PDF statement: examduniya_reports_2026.pdf');" class="btn btn-sm btn-outline-danger border shadow-xs d-flex align-items-center ms-1"><i class="feather-file-text text-danger me-1"></i> PDF</button>
                <button onclick="alert('Downloading raw index records... Exporting CSV log: examduniya_reports_2026.csv');" class="btn btn-sm btn-outline-secondary border shadow-xs d-flex align-items-center ms-1"><i class="feather-download me-1"></i> CSV</button>
            </div>
        </div>

        <!-- Metric Ribbons Grid -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card p-3 border bg-white shadow-sm rounded-3">
                    <span class="text-uppercase text-muted fs-11 fw-bold mb-1">Total Revenue</span>
                    <h4 class="fw-bold mb-0 text-dark"><?php echo $revenue_total; ?></h4>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 border bg-white shadow-sm rounded-3">
                    <span class="text-uppercase text-muted fs-11 fw-bold mb-1">Active Packs sold</span>
                    <h4 class="fw-bold mb-0 text-primary"><?php echo $total_subscriptions; ?> sales</h4>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 border bg-white shadow-sm rounded-3">
                    <span class="text-uppercase text-muted fs-11 fw-bold mb-1">Avg Order Val</span>
                    <h4 class="fw-bold mb-0 text-success"><?php echo $average_order_value; ?></h4>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 border bg-white shadow-sm rounded-3">
                    <span class="text-uppercase text-muted fs-11 fw-bold mb-1">Completed CBT Mocks</span>
                    <h4 class="fw-bold mb-0 text-info"><?php echo number_format($completions_count); ?> trials</h4>
                </div>
            </div>
        </div>

        <!-- Styled Visual graphs -->
        <div class="row g-4 mb-4">
            <div class="col-lg-8">
                <div class="card p-4 border bg-white rounded-3 shadow-sm">
                    <h5 class="fw-bold mb-4">Monthly Revenue & Volume Progression (2026)</h5>
                    
                    <!-- Styled Bar Chart Bars purely via HTML/CSS -->
                    <div class="d-flex align-items-end justify-content-between pt-5 pb-3 border-bottom px-3" style="height: 250px;">
                        <div class="text-center w-full" style="max-width:40px;">
                            <div class="bg-primary bg-opacity-20 rounded-top" style="height: 60px;"></div>
                            <small class="text-muted font-mono" style="font-size:10px;">Jan</small>
                        </div>
                        <div class="text-center w-full" style="max-width:40px;">
                            <div class="bg-primary bg-opacity-40 rounded-top" style="height: 85px;"></div>
                            <small class="text-muted font-mono" style="font-size:10px;">Feb</small>
                        </div>
                        <div class="text-center w-full" style="max-width:40px;">
                            <div class="bg-primary bg-opacity-60 rounded-top" style="height: 120px;"></div>
                            <small class="text-muted font-mono" style="font-size:10px;">Mar</small>
                        </div>
                        <div class="text-center w-full" style="max-width:40px;">
                            <div class="bg-primary bg-opacity-80 rounded-top" style="height: 160px;"></div>
                            <small class="text-muted font-mono" style="font-size:10px;">Apr</small>
                        </div>
                        <div class="text-center w-full" style="max-width:40px;">
                            <div class="bg-primary rounded-top" style="height: 195px; background-color: var(--secondary-color) !important;"></div>
                            <small class="text-muted font-mono" style="font-size:10px;">May</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Category shares -->
            <div class="col-lg-4">
                <div class="card p-4 border bg-white rounded-3 shadow-sm h-100">
                    <h5 class="fw-bold mb-3">Share Breakdown</h5>
                    
                    <div class="mb-3">
                        <div class="d-flex justify-content-between small mb-1">
                            <span>UP Police Exam Pack</span>
                            <span class="fw-bold">48%</span>
                        </div>
                        <div class="progress" style="height: 6px;">
                            <div class="progress-bar bg-primary" role="progressbar" style="width: 48%;"></div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between small mb-1">
                            <span>SSC GD Constable Pack</span>
                            <span class="fw-bold">32%</span>
                        </div>
                        <div class="progress" style="height: 6px;">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 32%;"></div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between small mb-1">
                            <span>Railway Combo Packs</span>
                            <span class="fw-bold">14%</span>
                        </div>
                        <div class="progress" style="height: 6px;">
                            <div class="progress-bar bg-warning" role="progressbar" style="width: 14%;"></div>
                        </div>
                    </div>

                    <div class="mb-0">
                        <div class="d-flex justify-content-between small mb-1">
                            <span>All Exams Unlimited</span>
                            <span class="fw-bold">6%</span>
                        </div>
                        <div class="progress" style="height: 6px;">
                            <div class="progress-bar bg-info" role="progressbar" style="width: 6%;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
render_footer();
?>
