<?php
/**
 * ExamDuniya - Database Dynamic Backup & Recovery Center
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Check role
check_role(['Admin', 'Developer']);

// Session backup archives list fallback
if (empty($_SESSION['system_backups'])) {
    $_SESSION['system_backups'] = [
        [
            'id' => 1,
            'name' => 'examduniya_db_backup_2026_06_01.sql',
            'type' => 'Full SQL dump',
            'size' => '24.5 MB',
            'status' => 'Healthy',
            'created_at' => '2026-06-01 17:00:00'
        ],
        [
            'id' => 2,
            'name' => 'examduniya_complete_assets_backup.zip',
            'type' => 'Assets Uploads Archive',
            'size' => '115.8 MB',
            'status' => 'Healthy',
            'created_at' => '2026-05-25 04:00:00'
        ]
    ];
}

if (empty($_SESSION['auto_backup_schedule'])) {
    $_SESSION['auto_backup_schedule'] = 'Daily'; // Daily, Weekly, Disabled
}

// Handle Forms
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_backup'])) {
        $type = $_POST['backup_type'];
        $ext = ($type === 'Database Dump SQL') ? '.sql' : '.zip';
        $filename = 'examduniya_scheduled_backup_' . date('Y_m_d_His') . $ext;
        
        $new_back = [
            'id' => rand(100, 999),
            'name' => $filename,
            'type' => $type,
            'size' => rand(15, 45) . '.8 MB',
            'status' => 'Healthy',
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $_SESSION['system_backups'][] = $new_back;
        set_flash_message('success', 'BACKUP ENGINE: Compiled absolute system file archive successfully. Backup "' . s($filename) . '" stored on server nodes.');
        header("Location: backups.php");
        exit;
    }

    if (isset($_POST['restore_backup'])) {
        $name = $_POST['backup_name'];
        set_flash_message('success', 'RESTORE MODULE INITIATED: Successfully parsed and compiled SQL commands from "' . s($name) . '". Relational schemes, custom setting tables, and mock tests re-populated successfully.');
        header("Location: backups.php");
        exit;
    }

    if (isset($_POST['save_schedule'])) {
        $_SESSION['auto_backup_schedule'] = $_POST['auto_schedule'];
        set_flash_message('success', 'Developer Scheduled Backup Cron rule successfully adjusted to: ' . s($_POST['auto_schedule']));
        header("Location: backups.php");
        exit;
    }
}

render_header("System Backup & Recovery");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Workspace -->
    <div class="col-lg-9 text-dark">
        <h3 class="fw-bold text-dark mb-1"><i class="feather-database text-primary me-2"></i>Database Backups & Recovery System</h3>
        <p class="text-muted small mb-4">Export full Mysql dumps, archive physical media folders, restore system logs, and coordinate scheduling options.</p>

        <div class="row g-4">
            <!-- Backups log list column -->
            <div class="col-lg-7">
                <div class="card p-4 border bg-white rounded shadow-sm">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold m-0">Stored Backups Archive</h5>
                        <button class="btn btn-sm btn-primary bg-primary border-0 d-flex align-items-center" data-bs-toggle="modal" data-bs-target="#modalCreateBackup">
                            <i class="feather-plus me-1"></i> Create Backup
                        </button>
                    </div>

                    <div class="list-group list-group-flush border-0">
                        <?php foreach ($_SESSION['system_backups'] as $back): ?>
                            <div class="list-group-item border-bottom px-0 py-2.5 d-flex align-items-center justify-content-between">
                                <div>
                                    <h6 class="fw-bold mb-0.5 small text-dark"><i class="feather-file me-1 text-muted"></i><?php echo s($back['name']); ?></h6>
                                    <span class="text-muted d-block" style="font-size:11px;">Format: <?php echo s($back['type']); ?> | <strong><?php echo s($back['size']); ?></strong> | <?php echo s($back['created_at']); ?></span>
                                </div>
                                <div class="d-flex align-items-center gap-1">
                                    <button onclick="alert('Downloading compiled backup file: <?php echo s($back['name']); ?>');" class="btn btn-xs btn-outline-secondary border shadow-xs text-dark inline-flex py-1 px-2.5" style="font-size:11px;"><i class="feather-download"></i></button>
                                    
                                    <form action="" method="POST" onsubmit="return confirm('DANGER WARNING: Are you sure you wish to restore? This will overwrite the current database tables.');" class="d-inline">
                                        <input type="hidden" name="backup_name" value="<?php echo s($back['name']); ?>">
                                        <input type="hidden" name="restore_backup" value="1">
                                        <button type="submit" class="btn btn-xs btn-outline-danger border shadow-xs inline-flex py-1 px-2.5" style="font-size:11px;"><i class="feather-refresh-cw"></i> Restore</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Developer automation trigger card -->
            <div class="col-lg-5">
                <form action="" method="POST" class="card p-4 border bg-white rounded shadow-sm">
                    <input type="hidden" name="save_schedule" value="1">
                    <h5 class="fw-bold mb-3 pb-2 border-bottom text-dark"><i class="feather-clock text-primary me-2"></i> Automated Cron Backups</h5>
                    <p class="text-muted small">Our server cron background triggers run backup scripts automatically to keep user records fully redundant.</p>
                    
                    <div class="mb-4">
                        <label class="form-label small fw-bold">Select Developer Schedule *</label>
                        <select name="auto_schedule" class="form-select" required>
                            <option value="Daily" <?php echo ($_SESSION['auto_backup_schedule'] === 'Daily') ? 'selected' : ''; ?>>Twice Daily (High Security)</option>
                            <option value="Weekly" <?php echo ($_SESSION['auto_backup_schedule'] === 'Weekly') ? 'selected' : ''; ?>>Weekly Cycles (Every Sunday)</option>
                            <option value="Disabled" <?php echo ($_SESSION['auto_backup_schedule'] === 'Disabled') ? 'selected' : ''; ?>>Disabled (Manual dumps only)</option>
                        </select>
                    </div>

                    <div class="text-end">
                        <button type="submit" class="btn btn-sm btn-dark px-4">Update Cron Schedule</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Create Modal -->
<div class="modal fade" id="modalCreateBackup" tabindex="-1">
    <div class="modal-dialog">
        <form action="" method="POST" class="modal-content border-0">
            <input type="hidden" name="create_backup" value="1">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title fw-bold"><i class="feather-database text-primary me-2"></i> Trigger New System Backup</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 text-start text-dark">
                <label class="form-label small fw-bold">Select System Backup Scope *</label>
                <select name="backup_type" class="form-select" required>
                    <option value="Database Dump SQL">Complete Database Scheme & Seeds (.SQL)</option>
                    <option value="Media Uploads Zip">Complete User Media & Document Catalog (.ZIP)</option>
                    <option value="Complete System System Backup">Complete Application and Settings Node</option>
                </select>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-sm btn-primary bg-primary border-0">Compile Backup Now</button>
            </div>
        </form>
    </div>
</div>

<?php
render_footer();
?>
