<?php
/**
 * ExamDuniya - Advertisement Management System
 * Full Enterprise Control with click/impression analytics and templates
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Protect Route
check_role(['Admin', 'Developer']);

// Session-based ad manager fallback storage for robust container preview
if (empty($_SESSION['banner_ads'])) {
    $_SESSION['banner_ads'] = [
        [
            'id' => 1,
            'name' => 'AdSense Top Leaderboard',
            'type' => 'Google AdSense',
            'location' => 'Homepage Header',
            'code' => '<div class="ad-placeholder bg-light text-muted p-4 text-center border rounded"><strong>Google AdSense</strong><br>Responsive Header slot [CA-PUB-9281048]</div>',
            'image_url' => '',
            'dest_url' => '',
            'status' => 'Enabled',
            'start_date' => '2026-06-01',
            'end_date' => '2026-12-31',
            'clicks' => 4820,
            'impressions' => 124090
        ],
        [
            'id' => 2,
            'name' => 'SSC Book Affiliate Promotion',
            'type' => 'Affiliate Ads',
            'location' => 'Homepage Sidebar',
            'code' => '',
            'image_url' => 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=400',
            'dest_url' => 'https://amazon.in/test-affiliate-code',
            'status' => 'Enabled',
            'start_date' => '2026-06-01',
            'end_date' => '2026-08-15',
            'clicks' => 389,
            'impressions' => 28940
        ],
        [
            'id' => 3,
            'name' => 'ExamDuniya Premium Prime Upgrade Banner',
            'type' => 'Banner Ads',
            'location' => 'Mock Test Pages',
            'code' => '',
            'image_url' => 'https://images.unsplash.com/photo-1606326608606-aa0b62935f2b?auto=format&fit=crop&q=80&w=600',
            'dest_url' => '/subscribe.php',
            'status' => 'Disabled',
            'start_date' => '2026-05-01',
            'end_date' => '2026-06-01',
            'clicks' => 143,
            'impressions' => 12800
        ]
    ];
}

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_ad'])) {
        $new_ad = [
            'id' => rand(100, 999),
            'name' => trim($_POST['name']),
            'type' => $_POST['type'],
            'location' => $_POST['location'],
            'code' => $_POST['code'],
            'image_url' => trim($_POST['image_url']),
            'dest_url' => trim($_POST['dest_url']),
            'status' => isset($_POST['status']) ? 'Enabled' : 'Disabled',
            'start_date' => $_POST['start_date'],
            'end_date' => $_POST['end_date'],
            'clicks' => 0,
            'impressions' => 0
        ];
        $_SESSION['banner_ads'][] = $new_ad;
        set_flash_message('success', 'Advertisement Slot has been successfully created and scheduled!');
        header("Location: ads.php");
        exit;
    }

    if (isset($_POST['delete_ad'])) {
        $id = (int)$_POST['ad_id'];
        foreach ($_SESSION['banner_ads'] as $key => $ad) {
            if ($ad['id'] === $id) {
                unset($_SESSION['banner_ads'][$key]);
                break;
            }
        }
        $_SESSION['banner_ads'] = array_values($_SESSION['banner_ads']);
        set_flash_message('warning', 'Ad slot was successfully removed from rotations.');
        header("Location: ads.php");
        exit;
    }

    if (isset($_POST['toggle_ad'])) {
        $id = (int)$_POST['ad_id'];
        foreach ($_SESSION['banner_ads'] as &$ad) {
            if ($ad['id'] === $id) {
                $ad['status'] = ($ad['status'] === 'Enabled') ? 'Disabled' : 'Enabled';
                break;
            }
        }
        set_flash_message('success', 'Ad status updated successfully.');
        header("Location: ads.php");
        exit;
    }
}

render_header("Ad Slot Manager");
?>

<div class="row">
    <!-- Sidebar navigation -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 "><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Content Area -->
    <div class="col-lg-9 text-dark">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold tracking-tight text-dark mb-1"><i class="feather-image text-primary me-2"></i>Advertisement Management</h3>
                <p class="text-muted mb-0 small">Create, schedule, track, and optimize dynamic banner displays, Google AdSense codes, or affiliate URLs.</p>
            </div>
            <button class="btn btn-primary d-flex align-items-center bg-primary border-0" data-bs-toggle="modal" data-bs-target="#modalAddAdSlot">
                <i class="feather-plus me-1"></i> Create Ad Slot
            </button>
        </div>

        <!-- Quick Stats Banner -->
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card border p-3 bg-white shadow-sm rounded-3">
                    <div class="d-flex align-items-center">
                        <span class="p-2.5 bg-primary bg-opacity-10 text-primary rounded me-3"><i class="feather-eye fs-4"></i></span>
                        <div>
                            <h4 class="mb-0 fw-bold">165,830</h4>
                            <small class="text-muted fs-11">Total Ad Impressions</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border p-3 bg-white shadow-sm rounded-3">
                    <div class="d-flex align-items-center">
                        <span class="p-2.5 bg-success bg-opacity-10 text-success rounded me-3"><i class="feather-mouse-pointer fs-4"></i></span>
                        <div>
                            <h4 class="mb-0 fw-bold">5,352</h4>
                            <small class="text-muted fs-11">Total Clicks Tracked</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border p-3 bg-white shadow-sm rounded-3">
                    <div class="d-flex align-items-center">
                        <span class="p-2.5 bg-warning bg-opacity-10 text-warning rounded me-3"><i class="feather-percent fs-4"></i></span>
                        <div>
                            <h4 class="mb-0 fw-bold">3.23%</h4>
                            <small class="text-muted fs-11">Average CTR Rate</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Advertisement Slots Rotator -->
        <div class="card border-0 shadow-sm bg-white p-4 mb-4">
            <h5 class="fw-bold mb-3">Rotational Slots & Configured Integrations</h5>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light text-uppercase font-sans" style="font-size: 11px;">
                        <tr>
                            <th class="py-3">Campaign / Ad Name</th>
                            <th class="py-3">Placement Location</th>
                            <th class="py-3">Ad Type</th>
                            <th class="py-3 text-center">Status</th>
                            <th class="py-3 text-center">Impressions</th>
                            <th class="py-3 text-center">Clicks</th>
                            <th class="py-3 text-center">CTR</th>
                            <th class="py-3 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody style="font-size: 13px;">
                        <?php foreach ($_SESSION['banner_ads'] as $ad): 
                            $ctr = ($ad['impressions'] > 0) ? round(($ad['clicks'] / $ad['impressions']) * 100, 2) : 0;
                        ?>
                            <tr>
                                <td>
                                    <div class="fw-bold text-dark"><?php echo s($ad['name']); ?></div>
                                    <span class="text-muted small" style="font-size: 11px;">Exp: <?php echo s($ad['end_date']); ?></span>
                                </td>
                                <td><span class="badge bg-light text-dark shadow-xs border"><?php echo s($ad['location']); ?></span></td>
                                <td><span class="badge badge-govt"><?php echo s($ad['type']); ?></span></td>
                                <td class="text-center">
                                    <form action="" method="POST" class="d-inline">
                                        <input type="hidden" name="ad_id" value="<?php echo $ad['id']; ?>">
                                        <input type="hidden" name="toggle_ad" value="1">
                                        <button type="submit" class="btn btn-sm py-0 border-0">
                                            <?php if ($ad['status'] === 'Enabled'): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                </td>
                                <td class="text-center fw-medium"><?php echo number_format($ad['impressions']); ?></td>
                                <td class="text-center fw-medium text-primary"><?php echo number_format($ad['clicks']); ?></td>
                                <td class="text-center fw-bold text-success"><?php echo $ctr; ?>%</td>
                                <td class="text-center">
                                    <form action="" method="POST" onsubmit="return confirm('Are you sure you want to delete this slot?');" class="d-inline">
                                        <input type="hidden" name="ad_id" value="<?php echo $ad['id']; ?>">
                                        <input type="hidden" name="delete_ad" value="1">
                                        <button type="submit" class="btn btn-sm btn-outline-danger inline-flex p-1 shadow-none border" style="line-height:1;">
                                            <i class="feather-trash-2"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Layout Ad Guidelines Banner -->
        <div class="card p-4 border-0 text-white rounded shadow-sm" style="background: var(--gradient-accent);">
            <h5 class="fw-bold mb-2"><i class="feather-info me-2"></i> Ad Placement Guidelines & Monetization Advice</h5>
            <p class="small mb-0 opacity-80" style="line-height:1.6;">By default, Ad slots configured as <strong>Google AdSense</strong> or <strong>JavaScript Ads</strong> will dynamically inject standard script assets within layout hooks. Ensure you specify verified slot tags inside the settings pane. Double click impressions can be audited under our reporting engine metrics page.</p>
        </div>
    </div>
</div>

<!-- Add Ad Slot Modal -->
<div class="modal fade" id="modalAddAdSlot" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title font-sans fw-bold"><i class="feather-image text-primary me-2"></i> Create Native Ad Slot Campaign</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST" class="modal-body p-4 text-dark">
                <input type="hidden" name="add_ad" value="1">
                
                <div class="row g-3">
                    <div class="col-md-12">
                        <label class="form-label small fw-bold">Campaign Campaign Name *</label>
                        <input type="text" name="name" class="form-control" placeholder="AdSense Homepage Top Banner" required>
                    </div>
                    
                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Ad Placement Location *</label>
                        <select name="location" class="form-select" required>
                            <option value="Homepage Header">Homepage Header</option>
                            <option value="Homepage Sidebar">Homepage Sidebar</option>
                            <option value="Homepage Footer">Homepage Footer</option>
                            <option value="Article Top">Article Top</option>
                            <option value="Article Middle">Article Middle</option>
                            <option value="Article Bottom">Article Bottom</option>
                            <option value="Category Pages">Category Pages</option>
                            <option value="Search Pages">Search Pages</option>
                            <option value="Mock Test Pages">Mock Test Pages</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Supported Ad Type *</label>
                        <select name="type" class="form-select" required>
                            <option value="Google AdSense">Google AdSense</option>
                            <option value="Banner Ads">Banner Ads</option>
                            <option value="Image Ads">Image Ads</option>
                            <option value="HTML Ads">HTML Ads</option>
                            <option value="JavaScript Ads">JavaScript Ads</option>
                            <option value="Affiliate Ads">Affiliate Ads</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-bold">Start Date *</label>
                        <input type="date" name="start_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-bold">End Date (Schedule Auto Disable) *</label>
                        <input type="date" name="end_date" class="form-control" value="<?php echo date('Y-m-d', strtotime('+90 days')); ?>" required>
                    </div>

                    <div class="col-md-12">
                        <label class="form-label small fw-bold">Static Banner Image URL (Optional - For Banner/Image/Affiliate Ads)</label>
                        <input type="url" name="image_url" class="form-control" placeholder="https://example.com/assets/banner.jpg">
                    </div>

                    <div class="col-md-12">
                        <label class="form-label small fw-bold">Destination Redirection URL (Optional - For Banner/Image/Affiliate Ads)</label>
                        <input type="url" name="dest_url" class="form-control" placeholder="https://amazon.in/affiliate-link">
                    </div>

                    <div class="col-md-12">
                        <label class="form-label small fw-bold">HTML / JavaScript Code Snippet (Optional - For AdSense/HTML/JS slots)</label>
                        <textarea name="code" class="form-control font-mono" rows="4" placeholder="<script> ... ad code ... </script>"></textarea>
                    </div>

                    <div class="col-md-12 mt-3">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="status" id="flexSwitchStatus" checked>
                            <label class="form-check-label small fw-bold" for="flexSwitchStatus">Publish Instantly into rotators</label>
                        </div>
                    </div>
                </div>

                <div class="border-top mt-4 pt-3 text-end">
                    <button type="button" class="btn btn-outline-secondary btn-sm px-3 me-2" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm px-4 bg-primary border-0">Save & Rotator Broadcast</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
render_footer();
?>
