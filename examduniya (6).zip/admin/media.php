<?php
/**
 * ExamDuniya - Media Library Explorer Node
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Check role
check_role(['Admin', 'Developer']);

// Session media element storage fallback
if (empty($_SESSION['media_files'])) {
    $_SESSION['media_files'] = [
        [
            'id' => 1,
            'name' => 'uppbpb-official-notice-241.pdf',
            'type' => 'PDF',
            'size' => '2.4 MB',
            'url' => '/assets/pdf/uppbpb-official-notice-241.pdf',
            'uploaded_at' => '2026-06-01'
        ],
        [
            'id' => 2,
            'name' => 'ssc-gd-constable-syllabus.pdf',
            'type' => 'PDF',
            'size' => '1.8 MB',
            'url' => '/assets/pdf/ssc-gd-constable-syllabus.pdf',
            'uploaded_at' => '2026-05-28'
        ],
        [
            'id' => 3,
            'name' => 'homepage_banner_accent.png',
            'type' => 'Image',
            'size' => '512 KB',
            'url' => 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=600',
            'uploaded_at' => '2026-05-25'
        ]
    ];
}

// Handle Forms
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['upload_media'])) {
        $filename = trim($_FILES['media_file']['name'] ?? 'uploaded-workbook-' . rand(10, 99) . '.pdf');
        $ext = strtoupper(pathinfo($filename, PATHINFO_EXTENSION));
        if (empty($ext)) $ext = 'PDF';

        $new_file = [
            'id' => rand(100, 999),
            'name' => $filename,
            'type' => $ext,
            'size' => '1.2 MB',
            'url' => '/assets/uploads/' . $filename,
            'uploaded_at' => date('Y-m-d')
        ];

        $_SESSION['media_files'][] = $new_file;
        set_flash_message('success', 'File "' . s($filename) . '" parsed and recorded in the library.');
        header("Location: media.php");
        exit;
    }

    if (isset($_POST['delete_media'])) {
        $id = (int)$_POST['media_id'];
        foreach ($_SESSION['media_files'] as $key => $file) {
            if ($file['id'] === $id) {
                unset($_SESSION['media_files'][$key]);
                break;
            }
        }
        $_SESSION['media_files'] = array_values($_SESSION['media_files']);
        set_flash_message('warning', 'Document detached from database reference indexes.');
        header("Location: media.php");
        exit;
    }
    
    if (isset($_POST['rename_media'])) {
        $id = (int)$_POST['media_id'];
        $new_name = trim($_POST['new_name']);
        foreach ($_SESSION['media_files'] as &$file) {
            if ($file['id'] === $id) {
                $file['name'] = $new_name;
                break;
            }
        }
        set_flash_message('success', 'File name remapped successfully.');
        header("Location: media.php");
        exit;
    }
}

render_header("Media Library Manager");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 "><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Pane -->
    <div class="col-lg-9 text-dark">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="feather-folder text-primary me-2"></i>Media & Document Library</h3>
                <p class="text-muted small mb-0">Organize and upload PDFs, official notifications, syllabus images or sample papers directly on the server.</p>
            </div>
            <button class="btn btn-primary bg-primary border-0 d-flex align-items-center" data-bs-toggle="modal" data-bs-target="#modalUpload">
                <i class="feather-upload-cloud me-1"></i> Upload Document
            </button>
        </div>

        <!-- Files grid -->
        <div class="row g-3">
            <?php foreach ($_SESSION['media_files'] as $file): ?>
                <div class="col-md-4">
                    <div class="card p-3 bg-white border rounded shadow-xs d-flex flex-column justify-content-between h-100">
                        <div class="text-center pb-3">
                            <?php if ($file['type'] === 'PDF'): ?>
                                <span class="p-3 d-inline-block bg-danger bg-opacity-10 text-danger rounded-circle mb-3"><i class="feather-file-text fs-3"></i></span>
                            <?php else: ?>
                                <img src="<?php echo s($file['url']); ?>" class="img-fluid rounded border mb-3 w-full" style="height: 120px; object-fit: cover;">
                            <?php endif; ?>
                            <h6 class="fw-bold text-dark text-truncate mb-1" style="font-size:14px;"><?php echo s($file['name']); ?></h6>
                            <span class="badge bg-light text-muted border shadow-xs" style="font-size:10px;"><?php echo s($file['type']); ?> (<?php echo s($file['size']); ?>)</span>
                        </div>

                        <div class="border-top pt-3 d-flex justify-content-between gap-1">
                            <!-- Rename trigger -->
                            <button class="btn btn-xs btn-outline-secondary flex-grow-1 font-sans text-dark py-1" style="font-size:11px;" data-bs-toggle="modal" data-bs-target="#modalRename<?php echo $file['id']; ?>">Rename</button>
                            
                            <!-- Delete form -->
                            <form action="" method="POST" onsubmit="return confirm('Do you wish to delete this document permanently?');" class="flex-grow-1">
                                <input type="hidden" name="media_id" value="<?php echo $file['id']; ?>">
                                <input type="hidden" name="delete_media" value="1">
                                <button type="submit" class="btn btn-xs btn-outline-danger w-full py-1" style="font-size:11px;">Delete file</button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Rename Modal -->
                <div class="modal fade" id="modalRename<?php echo $file['id']; ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form action="" method="POST" class="modal-content border-0">
                            <input type="hidden" name="media_id" value="<?php echo $file['id']; ?>">
                            <input type="hidden" name="rename_media" value="1">
                            <div class="modal-header">
                                <h5 class="modal-title fw-bold">Rename Asset Reference</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body p-4 text-start">
                                <label class="form-label small fw-bold">Provide New Filename *</label>
                                <input type="text" name="new_name" class="form-control" value="<?php echo s($file['name']); ?>" required>
                            </div>
                            <div class="modal-footer border-0">
                                <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-sm btn-primary bg-primary border-0">Apply Remap</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Upload Modal -->
<div class="modal fade" id="modalUpload" tabindex="-1">
    <div class="modal-dialog">
        <form action="" method="POST" enctype="multipart/form-data" class="modal-content border-0">
            <input type="hidden" name="upload_media" value="1">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title fw-bold"><i class="feather-upload-cloud text-primary me-2"></i> Upload to Media Matrix</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4 text-dark text-start">
                <div class="mb-3">
                    <label class="form-label small fw-bold">Select File (PDF, PNG, JPG) *</label>
                    <input type="file" name="media_file" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-sm btn-primary bg-primary border-0">Upload into Cloud Container</button>
            </div>
        </form>
    </div>
</div>

<?php
render_footer();
?>
