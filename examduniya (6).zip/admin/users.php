<?php
/**
 * ExamDuniya - Advanced User Management Panel
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Route Guard
check_role(['Admin', 'Developer']);

// Session users mapping fallback
if (empty($_SESSION['custom_users'])) {
    $_SESSION['custom_users'] = [
        [
            'id' => 3,
            'name' => 'Amit Sharma',
            'email' => 'amit@examduniya.in',
            'phone' => '9999999993',
            'role_id' => 3,
            'status' => 'Active',
            'subscription' => 'UP Police Exam Pack',
            'expires_at' => '2027-06-01'
        ],
        [
            'id' => 4,
            'name' => 'Vikas Kumar',
            'email' => 'vikas@gmail.com',
            'phone' => '8888283948',
            'role_id' => 3,
            'status' => 'Suspended',
            'subscription' => 'None',
            'expires_at' => 'N/A'
        ],
        [
            'id' => 5,
            'name' => 'Priya Patel',
            'email' => 'priya.patel@gmail.com',
            'phone' => '7738290482',
            'role_id' => 3,
            'status' => 'Active',
            'subscription' => 'All Exams Unlimited Combo',
            'expires_at' => '2026-12-31'
        ]
    ];
}

// Handle Forms
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['change_status'])) {
        $user_id = (int)$_POST['user_id'];
        $new_status = $_POST['status_val'];
        
        foreach ($_SESSION['custom_users'] as &$u) {
            if ($u['id'] === $user_id) {
                $u['status'] = $new_status;
                break;
            }
        }
        set_flash_message('success', 'User action status updated successfully to: ' . s($new_status));
        header("Location: users.php");
        exit;
    }

    if (isset($_POST['reset_pwd'])) {
        $user_id = (int)$_POST['user_id'];
        $new_pass = trim($_POST['new_password']);
        
        $password_check = validate_password($new_pass);
        if (!$password_check['valid']) {
            set_flash_message('danger', 'Password did not meet security rules limit: ' . implode(' ', $password_check['errors']));
            header("Location: users.php");
            exit;
        }
        
        $hashed = password_hash($new_pass, PASSWORD_BCRYPT);
        $stmt_update = $pdo->prepare("UPDATE `users` SET `password` = :password WHERE `id` = :id");
        $stmt_update->execute([
            ':password' => $hashed,
            ':id' => $user_id
        ]);
        
        set_flash_message('success', 'ADMIN OVERRIDE SUCCESS: Password reset for student ID: ' . $user_id . '. New login credentials verified and saved.');
        header("Location: users.php");
        exit;
    }

    if (isset($_POST['update_subscription'])) {
        $user_id = (int)$_POST['user_id'];
        $pack = $_POST['pack_val'];
        $expiry = $_POST['expires_at'];
        
        foreach ($_SESSION['custom_users'] as &$u) {
            if ($u['id'] === $user_id) {
                $u['subscription'] = $pack;
                $u['expires_at'] = $expiry;
                break;
            }
        }
        set_flash_message('success', 'Candidate subscription mapping has been manually adjusted!');
        header("Location: users.php");
        exit;
    }
}

render_header("User Account Administration");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Workspace -->
    <div class="col-lg-9 text-dark">
        <h3 class="fw-bold text-dark mb-1"><i class="feather-users text-primary me-2"></i>Advanced User & Subscription Management</h3>
        <p class="text-muted small mb-4">View register candidate parameters, override active credentials, change subscription values, reset passwords, or suspend users instantly.</p>

        <!-- Users Control Grid -->
        <div class="card p-4 border bg-white rounded shadow-sm">
            <h5 class="fw-bold mb-3 text-dark">System Candidates Base</h5>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light text-uppercase font-sans font-xs" style="font-size:11px;">
                        <tr>
                            <th class="py-3">Aspirant Profile</th>
                            <th class="py-3">Contact</th>
                            <th class="py-3 text-center">Account Status</th>
                            <th class="py-3">Active Subscription</th>
                            <th class="py-3 text-center">Manage Account State</th>
                        </tr>
                    </thead>
                    <tbody style="font-size:13px;">
                        <?php foreach ($_SESSION['custom_users'] as $u): ?>
                            <tr>
                                <td class="fw-bold">
                                    <div class="text-dark mb-0.5"><?php echo s($u['name']); ?></div>
                                    <span class="text-muted small">ID: CANDIDATE-<?php echo $u['id']; ?></span>
                                </td>
                                <td>
                                    <div class="small fw-medium text-muted mb-0.5 font-mono"><?php echo s($u['email']); ?></div>
                                    <span class="small font-mono text-muted">Phone: <?php echo s($u['phone']); ?></span>
                                </td>
                                <td class="text-center">
                                    <?php if ($u['status'] === 'Active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php elseif ($u['status'] === 'Suspended'): ?>
                                        <span class="badge bg-warning text-dark">Suspended</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Banned</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="fw-bold small text-primary m-0"><?php echo s($u['subscription']); ?></div>
                                    <span class="text-muted small font-mono" style="font-size:11px;">Expires: <?php echo s($u['expires_at']); ?></span>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex align-items-center justify-content-center gap-1">
                                        <!-- Actions dropdown trigger -->
                                        <button class="btn btn-xs btn-outline-secondary border shadow-xs text-dark font-sans py-1 px-2.5" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#modalStatus<?php echo $u['id']; ?>"><i class="feather-shield"></i> State</button>
                                        <button class="btn btn-xs btn-outline-primary border shadow-xs font-sans py-1 px-2.5" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#modalPass<?php echo $u['id']; ?>"><i class="feather-key"></i> Key</button>
                                        <button class="btn btn-xs btn-outline-success border shadow-xs font-sans py-1 px-2.5" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#modalPack<?php echo $u['id']; ?>"><i class="feather-shopping-bag"></i> Pack</button>
                                    </div>
                                </td>
                            </tr>

                            <!-- Status change Modal -->
                            <div class="modal fade" id="modalStatus<?php echo $u['id']; ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <form action="" method="POST" class="modal-content border-0">
                                        <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                        <input type="hidden" name="change_status" value="1">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold">Modify Status: <?php echo s($u['name']); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body p-4 text-start">
                                            <label class="form-label small fw-bold">Select Active Profile State Trigger *</label>
                                            <select name="status_val" class="form-select" required>
                                                <option value="Active" <?php echo ($u['status'] === 'Active') ? 'selected' : ''; ?>>Active (Allow access)</option>
                                                <option value="Suspended" <?php echo ($u['status'] === 'Suspended') ? 'selected' : ''; ?>>Suspended (Lock login temporary)</option>
                                                <option value="Banned" <?php echo ($u['status'] === 'Banned') ? 'selected' : ''; ?>>Banned (Block email/phone address forever)</option>
                                            </select>
                                        </div>
                                        <div class="modal-footer border-0">
                                            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-sm btn-dark">Update state</button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <!-- Reset password Modal -->
                            <div class="modal fade" id="modalPass<?php echo $u['id']; ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <form action="" method="POST" class="modal-content border-0">
                                        <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                        <input type="hidden" name="reset_pwd" value="1">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold">Reset Passkey: <?php echo s($u['name']); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body p-4 text-start">
                                            <label class="form-label small fw-bold text-secondary">Provide Override secure target password (8+ chars, 1 digit, 1 special character) *</label>
                                            <input type="text" name="new_password" class="form-control font-mono" value="EXAM_RESET_<?php echo rand(1000, 9999); ?>_PWD" required>
                                        </div>
                                        <div class="modal-footer border-0">
                                            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-sm btn-primary bg-primary border-0">Override Key</button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <!-- Subscription Edit Modal -->
                            <div class="modal fade" id="modalPack<?php echo $u['id']; ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <form action="" method="POST" class="modal-content border-0">
                                        <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                        <input type="hidden" name="update_subscription" value="1">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold">Map Manual Pack: <?php echo s($u['name']); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body p-4 text-start">
                                            <div class="mb-3">
                                                <label class="form-label small fw-bold">Subscription Test Pack *</label>
                                                <select name="pack_val" class="form-select" required>
                                                    <option value="None" <?php echo ($u['subscription'] === 'None') ? 'selected' : ''; ?>>-- No Subscription --</option>
                                                    <option value="UP Police Exam Pack" <?php echo ($u['subscription'] === 'UP Police Exam Pack') ? 'selected' : ''; ?>>UP Police Exam Pack</option>
                                                    <option value="SSC GD Constable Pack" <?php echo ($u['subscription'] === 'SSC GD Constable Pack') ? 'selected' : ''; ?>>SSC GD Constable Pack</option>
                                                    <option value="All Exams Unlimited Combo" <?php echo ($u['subscription'] === 'All Exams Unlimited Combo') ? 'selected' : ''; ?>>All Exams Unlimited Combo</option>
                                                </select>
                                            </div>

                                            <div class="mb-1">
                                                <label class="form-label small fw-bold">Redemption Expiry Range Date *</label>
                                                <input type="date" name="expires_at" class="form-control" value="2027-06-01" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer border-0">
                                            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-sm btn-success border-0">Update mapping</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
render_footer();
?>
