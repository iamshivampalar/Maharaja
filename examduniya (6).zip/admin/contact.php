<?php
/**
 * ExamDuniya - Contact Form Messages CRM & SMTP Config Desk
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Protect Route
check_role(['Admin', 'Developer']);

// Session contacts store fallback
if (empty($_SESSION['contact_messages'])) {
    $_SESSION['contact_messages'] = [
        [
            'id' => 1,
            'name' => 'Rajesh Yadav',
            'email' => 'rajesh@gmail.com',
            'subject' => 'Payment issue in UP Police test pack buy',
            'message' => 'Hello team, my money was debited from PayU but my account still lists the pack as locked. Please check my transaction ID: TXN_PAYU_4938210492.',
            'status' => 'Pending',
            'created_at' => '2026-06-01 14:10:00'
        ],
        [
            'id' => 2,
            'name' => 'Meera Singh',
            'email' => 'meera.s@outlook.com',
            'subject' => 'Inquiry about Railways calendar',
            'message' => 'Is there any upcoming vacancy expected for Railway NTPC in June 2026? Please email me the notification syllabus guidelines as soon as it is published.',
            'status' => 'Replied',
            'created_at' => '2026-05-28 11:45:00'
        ]
    ];
}

if (empty($_SESSION['smtp_settings'])) {
    $_SESSION['smtp_settings'] = [
        'smtp_host' => 'mail.examduniya.in',
        'smtp_port' => '587',
        'smtp_encryption' => 'TLS',
        'smtp_user' => 'contact@examduniya.in',
        'smtp_pass' => '********'
    ];
}

// Handle Form Posts
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send_reply'])) {
        $msg_id = (int)$_POST['msg_id'];
        $reply_body = trim($_POST['reply_content']);
        
        foreach ($_SESSION['contact_messages'] as &$msg) {
            if ($msg['id'] === $msg_id) {
                $msg['status'] = 'Replied';
                break;
            }
        }
        
        set_flash_message('success', 'SMTP SERVICE SUCCESS: Outbound message disptached via ' . s($_SESSION['smtp_settings']['smtp_host']) . ' to destination user successfully!');
        header("Location: contact.php");
        exit;
    }

    if (isset($_POST['save_smtp'])) {
        $_SESSION['smtp_settings']['smtp_host'] = trim($_POST['smtp_host']);
        $_SESSION['smtp_settings']['smtp_port'] = trim($_POST['smtp_port']);
        $_SESSION['smtp_settings']['smtp_encryption'] = $_POST['smtp_encryption'];
        $_SESSION['smtp_settings']['smtp_user'] = trim($_POST['smtp_user']);
        if (!empty($_POST['smtp_pass'])) {
            $_SESSION['smtp_settings']['smtp_pass'] = trim($_POST['smtp_pass']);
        }
        
        set_flash_message('success', 'SMTP gateway parameters established successfully.');
        header("Location: contact.php");
        exit;
    }
}

render_header("Contact Message CRM");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Pane -->
    <div class="col-lg-9 text-dark">
        <h3 class="fw-bold text-dark mb-1"><i class="feather-mail text-primary me-2"></i>Contact Messages & SMTP Control Desk</h3>
        <p class="text-muted small mb-4">View and respond to customer queries directly from the portal, configure relays, and export communication logs.</p>

        <div class="row g-4">
            <!-- Received messages list -->
            <div class="col-lg-7">
                <div class="card p-4 border bg-white rounded shadow-sm">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold m-0">Inquiries Inbox</h5>
                        <button onclick="alert('Exporting messages index log into CSV formatting...');" class="btn btn-xs btn-outline-secondary border shadow-xs"><i class="feather-download"></i> Export Messages</button>
                    </div>

                    <div class="list-group list-group-flush border-0">
                        <?php foreach ($_SESSION['contact_messages'] as $msg): ?>
                            <div class="list-group-item border-bottom px-0 py-3">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="fw-bold text-dark small"><?php echo s($msg['name']); ?> <span class="text-muted fw-normal">&lt;<?php echo s($msg['email']); ?>&gt;</span></span>
                                    <span class="badge bg-<?php echo ($msg['status'] === 'Pending') ? 'warning' : 'success'; ?>"><?php echo s($msg['status']); ?></span>
                                </div>
                                <div class="fw-semibold small text-primary mb-1"><?php echo s($msg['subject']); ?></div>
                                <p class="text-muted mb-3" style="font-size:12.5px; line-height:1.6;"><?php echo s($msg['message']); ?></p>

                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="text-muted font-mono" style="font-size:10px;"><i class="feather-clock me-1"></i><?php echo s($msg['created_at']); ?></span>
                                    <?php if ($msg['status'] === 'Pending'): ?>
                                        <button class="btn btn-xs btn-primary bg-primary border-0 font-sans" style="font-size: 11px;" data-bs-toggle="modal" data-bs-target="#modalReply<?php echo $msg['id']; ?>"><i class="feather-corner-up-left me-1"></i> Reply</button>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Reply Modal -->
                            <div class="modal fade" id="modalReply<?php echo $msg['id']; ?>" tabindex="-1">
                                <div class="modal-dialog">
                                    <form action="" method="POST" class="modal-content border-0">
                                        <input type="hidden" name="msg_id" value="<?php echo $msg['id']; ?>">
                                        <input type="hidden" name="send_reply" value="1">
                                        <div class="modal-header bg-dark text-white">
                                            <h5 class="modal-title fw-bold"><i class="feather-corner-up-left text-primary me-2"></i> SMTP Direct Reply</h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body p-4 text-start">
                                            <div class="mb-3">
                                                <label class="form-label small fw-bold">Recipient</label>
                                                <input type="text" class="form-control font-mono form-control-sm" value="<?php echo s($msg['name']); ?> <&lt;<?php echo s($msg['email']); ?>&gt;>" disabled>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label small fw-bold">Compose message body *</label>
                                                <textarea name="reply_content" class="form-control" rows="6" placeholder="Dear <?php echo s($msg['name']); ?>, we have updated..." required></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer border-0">
                                            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                            <button type="submit" class="btn btn-sm btn-primary bg-primary border-0">Send Relay Message</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Right side SMTP parameter configs -->
            <div class="col-lg-5">
                <form action="" method="POST" class="card p-4 border bg-white rounded shadow-sm">
                    <input type="hidden" name="save_smtp" value="1">
                    <h5 class="fw-bold mb-3 pb-2 border-bottom text-dark"><i class="feather-settings text-primary me-2"></i> Mail Server SMTP Configuration</h5>
                    
                    <div class="mb-3">
                        <label class="form-label small fw-bold">SMTP Relay Server Host *</label>
                        <input type="text" name="smtp_host" class="form-control font-mono form-control-sm" value="<?php echo s($_SESSION['smtp_settings']['smtp_host']); ?>" required>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label small fw-bold">SMTP Server Port *</label>
                            <input type="text" name="smtp_port" class="form-control font-mono form-control-sm" value="<?php echo s($_SESSION['smtp_settings']['smtp_port']); ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label small fw-bold">Relay Encryption *</label>
                            <select name="smtp_encryption" class="form-select form-select-sm" required>
                                <option value="TLS" <?php echo ($_SESSION['smtp_settings']['smtp_encryption'] === 'TLS') ? 'selected' : ''; ?>>TLS / STARTTLS</option>
                                <option value="SSL" <?php echo ($_SESSION['smtp_settings']['smtp_encryption'] === 'SSL') ? 'selected' : ''; ?>>SSL Implicit (465)</option>
                                <option value="None" <?php echo ($_SESSION['smtp_settings']['smtp_encryption'] === 'None') ? 'selected' : ''; ?>>No Encryption</option>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-bold">SMTP Mailbox User *</label>
                        <input type="text" name="smtp_user" class="form-control font-mono form-control-sm" value="<?php echo s($_SESSION['smtp_settings']['smtp_user']); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-bold">SMTP Mailbox Authorization Password</label>
                        <input type="password" name="smtp_pass" class="form-control form-control-sm" placeholder="Omit to leave unchanged">
                    </div>

                    <div class="text-end">
                        <button type="submit" class="btn btn-sm btn-primary bg-primary border-0 px-4">Save SMTP Settings</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
render_footer();
?>
