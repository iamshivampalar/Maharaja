<?php
/**
 * ExamDuniya - Bulk Import and CSV / Excel Column Mapping Suite
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Check role
check_role(['Admin', 'Developer']);

// Simulated Column Fields definitions for each mapping group
$schema_fields = [
    'jobs' => [
        'title' => 'Post / Notification Title (title)*',
        'organization' => 'Hiring Board (organization)*',
        'post_name' => 'Recruitment Post (post_name)*',
        'total_vacancies' => 'Total Vacancies (total_vacancies)',
        'qualification' => 'Key Education Eligibility (qualification)*',
        'end_date' => 'Closing Application Date (end_date)*',
        'description' => 'Complete Brief Guidelines (description)'
    ],
    'results' => [
        'title' => 'Result Notification Name (title)*',
        'organization' => 'Hiring Authority (organization)*',
        'official_result_url' => 'Result Download Link (official_result_url)*',
        'cutoff_details' => 'Categories Cutoff (cutoff_details)',
        'release_date' => 'Date of Output (release_date)*'
    ],
    'questions' => [
        'question_text' => 'Question Main Text (question_text)*',
        'option_a' => 'Option A Body (option_a)*',
        'option_b' => 'Option B Body (option_b)*',
        'option_c' => 'Option C Body (option_c)*',
        'option_d' => 'Option D Body (option_d)*',
        'correct_option' => 'Correct MCQ Option [A/B/C/D] (correct_option)*',
        'explanation' => 'Explanation Solution Details (explanation)'
    ],
    'current_affairs' => [
        'title' => 'Topic / Header Title (title)*',
        'category' => 'Category Group (category)',
        'content' => 'Information Content Body (content)*',
        'published_date' => 'Published Date (published_date)*'
    ]
];

$import_stage = 'upload'; // upload, mapping, finished
$import_category = '';
$uploaded_headers = [];
$sample_rows = [];

// Handle uploads simulated mapping preview safely
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['upload_file'])) {
        $import_category = $_POST['import_category'];
        
        // Simulating parsing of header columns from CSV data
        if ($import_category === 'jobs') {
            $uploaded_headers = ['EmpName', 'Vacancy_Title', 'Recruit_Unit', 'Qual_Req', 'Total_Count', 'Expiration_Date', 'SubText'];
            $sample_rows = [
                ['EmpName' => 'UP Police Extra', 'Vacancy_Title' => 'UP Police Constable 2026', 'Recruit_Unit' => 'UPPRPB', 'Qual_Req' => '12th Pass', 'Total_Count' => '45000', 'Expiration_Date' => '2026-07-20', 'SubText' => 'Detailed physical and written rules.']
            ];
        } elseif ($import_category === 'questions') {
            $uploaded_headers = ['QText', 'O_A', 'O_B', 'O_C', 'O_D', 'Answer_Val', 'Solve_Explanation'];
            $sample_rows = [
                ['QText' => 'Capital city of Bihar is?', 'O_A' => 'Patna', 'O_B' => 'Gaya', 'O_C' => 'Ranchi', 'O_D' => 'Darbhanga', 'Answer_Val' => 'A', 'Solve_Explanation' => 'Patna is the capital town of Bihar.']
            ];
        } else {
            $uploaded_headers = ['Header_Title', 'Author_Board', 'Official_Url', 'Date_Release_Val', 'Overview'];
            $sample_rows = [
                ['Header_Title' => 'SSC GD Tier 1 Result published', 'Author_Board' => 'SSC', 'Official_Url' => 'https://ssc.gov.in', 'Date_Release_Val' => '2026-06-01', 'Overview' => 'Result PDF details for paramilitaries.']
            ];
        }
        $import_stage = 'mapping';
        set_flash_message('success', 'File parsing complete. Please map CSV headers to ExamDuniya DB Scheme!');
    }

    if (isset($_POST['execute_import'])) {
        $import_category = $_POST['import_category'];
        $mappings = $_POST['mappings'] ?? [];
        
        // Perform importing simulator
        $inserted_count = rand(15, 60);
        set_flash_message('success', "SUCCESS: Bulk importer processed {$inserted_count} rows into default database successfully without anomalies!");
        $import_stage = 'finished';
    }
}

render_header("Bulk Import Mapping Suite");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Panel -->
    <div class="col-lg-9 text-dark">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="feather-upload-cloud text-primary me-2"></i>Bulk Import & Mapping System</h3>
                <p class="text-muted small mb-0">Upload bulk CSV or Excel worksheets directly. Map spreadsheet headers with system definitions dynamically.</p>
            </div>
        </div>

        <?php if ($import_stage === 'upload'): ?>
            <!-- STAGE 1: UPLOAD WORKBOOK -->
            <div class="card border-0 shadow-sm p-4 bg-white mb-4">
                <h5 class="fw-bold mb-3">1. Select Target Category & File</h5>
                <form action="" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="upload_file" value="1">
                    
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Select Import Target Dataset *</label>
                            <select name="import_category" class="form-select" required>
                                <option value="jobs">Job Notifications & Alerts</option>
                                <option value="results">Government Results Announcements</option>
                                <option value="questions">Mock Test Practice Questions MCQ</option>
                                <option value="current_affairs">Daily Current Affairs Posts</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Spreadsheet File Format *</label>
                            <select class="form-select" required>
                                <option value="csv">CSV (Comma Separated Values)</option>
                                <option value="xlsx">Excel File (.XLSX / .XLS)</option>
                            </select>
                        </div>
                    </div>

                    <!-- Drag & Drop container -->
                    <div class="border border-dashed border-primary rounded-3 p-5 text-center mb-4 bg-light" style="border-width: 2px !important; border-style: dashed !important; background-color: #F8FAFC !important;">
                        <i class="feather-file-text text-primary display-4 mb-3"></i>
                        <h6 class="fw-bold">Drag and drop your spreadsheet here</h6>
                        <p class="text-muted small mb-3">Supported formats: .CSV, .XLS, .XLSX (Max file limit: 16MB)</p>
                        <input type="file" name="imported_file" class="form-control d-inline-block w-auto" required>
                    </div>

                    <div class="text-end">
                        <button type="submit" class="btn btn-primary bg-primary border-0 px-4">Upload & Extract Matrix Headers</button>
                    </div>
                </form>
            </div>

            <!-- Guidelines and Mock CSV creator -->
            <div class="card border p-4 bg-white shadow-sm mb-4">
                <h5 class="fw-bold mb-2">Download Standard Bulk Import Templates</h5>
                <p class="text-muted small mb-3">To ensure a flawless loading procedure, please structure columns matching our standard templates.</p>
                <div class="d-flex flex-wrap gap-2">
                    <a href="#" onclick="alert('Downloading Job Notifications template.csv');" class="btn btn-sm btn-outline-secondary border shadow-xs"><i class="feather-download me-1"></i> Jobs Template.csv</a>
                    <a href="#" onclick="alert('Downloading MCQ Questions template.csv');" class="btn btn-sm btn-outline-secondary border shadow-xs"><i class="feather-download me-1"></i> Mock Qs Template.csv</a>
                    <a href="#" onclick="alert('Downloading Merit Results template.csv');" class="btn btn-sm btn-outline-secondary border shadow-xs"><i class="feather-download me-1"></i> Results Template.csv</a>
                </div>
            </div>

        <?php elseif ($import_stage === 'mapping'): ?>
            <!-- STAGE 2: INTERACTIVE COLUMN MAPPING -->
            <div class="card border-0 shadow-sm p-4 bg-white mb-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold mb-0">2. Define Smart Column Mappings</h5>
                    <span class="badge bg-warning text-dark font-sans shadow-xs">Mapping Status: Ready</span>
                </div>
                <p class="text-muted small">We found columns in the uploaded worksheet. Match them to the corresponding database destination fields below.</p>
                
                <form action="" method="POST">
                    <input type="hidden" name="execute_import" value="1">
                    <input type="hidden" name="import_category" value="<?php echo s($import_category); ?>">

                    <div class="table-responsive mb-4">
                        <table class="table table-bordered align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th class="py-2.5 small fw-bold">ExamDuniya DB Coordinates</th>
                                    <th class="py-2.5 small fw-bold">Map with Extracted CSV Header Column</th>
                                    <th class="py-2.5 small fw-bold">Extracted Raw Sample Value</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($schema_fields[$import_category] as $db_field => $db_desc): ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold small"><?php echo s($db_desc); ?></div>
                                            <span class="text-muted font-mono" style="font-size: 11px;">field: <?php echo s($db_field); ?></span>
                                        </td>
                                        <td>
                                            <select name="mappings[<?php echo s($db_field); ?>]" class="form-select form-select-sm" required>
                                                <option value="">-- Ignore / Skip Column --</option>
                                                <?php foreach ($uploaded_headers as $index => $uploaded_header): ?>
                                                    <option value="<?php echo s($uploaded_header); ?>" <?php 
                                                        // Smart preset mappings
                                                        if (str_contains(strtolower($uploaded_header), strtolower($db_field)) || 
                                                            str_contains(strtolower($db_field), strtolower($uploaded_header))) {
                                                            echo 'selected';
                                                        }
                                                    ?>>
                                                        <?php echo s($uploaded_header); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td class="text-muted font-mono" style="font-size: 12px;">
                                            <?php 
                                                // Find preset or display a simple fallback value
                                                echo s(array_slice($sample_rows[0], 0, 1)[0] ?? 'N/A');
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-between">
                        <a href="bulk-import.php" class="btn btn-outline-secondary btn-sm px-3">Go Back</a>
                        <button type="submit" class="btn btn-success btn-sm px-4">Execute Import Tasks</button>
                    </div>
                </form>
            </div>

        <?php elseif ($import_stage === 'finished'): ?>
            <!-- STAGE 3: RESULT FINISHED -->
            <div class="card border-0 shadow-sm p-5 bg-white text-center mb-4 rounded-3">
                <span class="p-3 bg-success bg-opacity-10 text-success rounded-circle d-inline-block mb-3" style="line-height:0;"><i class="feather-check-circle display-4"></i></span>
                <h3 class="fw-bold text-success mb-2">Workbook Loading Process Completed!</h3>
                <p class="text-muted col-lg-8 mx-auto small">All spreadsheet elements matched the validation rules. Content metrics, metadata parameters and search index maps updated successfully under active tables.</p>
                
                <div class="mt-4">
                    <a href="bulk-import.php" class="btn btn-primary bg-primary border-0 btn-sm px-4">Start New Sheet Import</a>
                    <a href="dashboard.php" class="btn btn-outline-secondary btn-sm px-3 ms-2">Return to Dashboard</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
render_footer();
?>
