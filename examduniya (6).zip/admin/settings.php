<?php
/**
 * ExamDuniya - Multi-Level Enterprise Settings Panel Console
 */

require_once dirname(__DIR__) . '/config/db.php';
require_once dirname(__DIR__) . '/app/Helpers/functions.php';

// Route Guard
check_role(['Admin', 'Developer']);

// Session settings storage defaults
if (empty($_SESSION['site_settings_extended'])) {
    $_SESSION['site_settings_extended'] = [
        // General
        'site_title' => 'ExamDuniya',
        'site_tagline' => "India's Smartest Government Exam Notification & Mock Test Platform",
        'site_contact_email' => 'contact@examduniya.in',
        'site_contact_phone' => '+91 99999 99991',
        // SEO
        'meta_description' => 'Latest sarkari exam notices, CBT Mock drills, quantitative guidelines and cutoffs pdf files.',
        'google_analytics_id' => 'G-ED2026XYZ',
        // Email
        'smtp_sender_name' => 'ExamDuniya Alerts Hub',
        // Payments
        'payu_merchant_key' => 'PAYU_MERCHANT_KEY_DEMO_EXAMDUNIYA',
        'payu_salt_hash' => 'PAYU_SALT_KEY_DEMO_EXAMDUNIYA',
        'currency_code' => 'INR (₹)',
        'gst_percentage' => '18%',
        // Notifications
        'enable_push' => 1,
        // Telegram
        'telegram_chan' => '@examduniya_alerts',
        // Branding
        'accent_color' => '#2563EB',
        'logo_asset' => '/assets/img/logo.png',
        // Security
        'session_lock_out_minutes' => '15',
        'enable_otp_login' => 1
    ];
}

// Handle Form Posts
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $key => $val) {
        if (isset($_SESSION['site_settings_extended'][$key])) {
            $_SESSION['site_settings_extended'][$key] = trim($val);
        }
    }
    set_flash_message('success', 'SYSTEM SETTINGS SUCCESS: Enterprise system configuration settings saved live.');
    header("Location: settings.php");
    exit;
}

render_header("ExamDuniya Core Settings");
?>

<div class="row">
    <!-- Sidebar -->
    <div class="col-lg-3 mb-4">
        <div class="card glass-card p-3 border-0">
            <h6 class="text-uppercase text-muted fw-bold small px-3 mb-3">Admin Navigation</h6>
            <div class="list-group list-group-flush border-0">
                <a href="dashboard.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-sliders me-3"></i>Dashboard</a>
                <a href="ads.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-image me-3"></i>Ad slots</a>
                <a href="articles.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-file-text me-3"></i>Blog articles</a>
                <a href="redirects.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-link me-3"></i>Redirects & Shortener</a>
                <a href="bulk-import.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-upload-cloud me-3"></i>Bulk importer</a>
                <a href="publishing.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-send me-3"></i>Scheduled broadcast</a>
                <a href="announcements.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-bell me-3"></i>Alert notifications</a>
                <a href="seo.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-search me-3"></i>SEO & Cache</a>
                <a href="media.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-folder me-3"></i>Media library</a>
                <a href="contact.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-mail me-3"></i>Inquiries & SMTP</a>
                <a href="users.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-users me-3"></i>User manager</a>
                <a href="reports.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-pie-chart me-3"></i>Reports & Analytics</a>
                <a href="backups.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1"><i class="feather-database me-3"></i>System backup</a>
                <a href="settings.php" class="list-group-item list-group-item-action border-0 py-2.5 rounded mb-1 active bg-primary text-white"><i class="feather-settings me-3"></i>General settings</a>
            </div>
        </div>
    </div>

    <!-- Main Workspace -->
    <div class="col-lg-9 text-dark">
        <h3 class="fw-bold text-dark mb-1"><i class="feather-settings text-primary me-2"></i>Multi-Level Settings Panel Console</h3>
        <p class="text-muted small mb-4">Establish global parameters, update Payu merchant keys, map social links handles, toggle analytics tracking and adapt layouts branding.</p>

        <!-- Tab Navigations -->
        <div class="card p-4 border bg-white shadow-sm rounded-3">
            <ul class="nav nav-tabs card-header-tabs mb-4 border-bottom" id="settingsTab" role="tablist">
                <li class="nav-item">
                    <button class="nav-link active small py-2 fw-semibold" id="gen-tab" data-bs-toggle="tab" data-bs-target="#tabGen">General Setup</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link small py-2 fw-semibold" id="seo-tab" data-bs-toggle="tab" data-bs-target="#tabSeo">SEO Metadata</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link small py-2 fw-semibold" id="pay-tab" data-bs-toggle="tab" data-bs-target="#tabPay">Payments Relay</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link small py-2 fw-semibold" id="brand-tab" data-bs-toggle="tab" data-bs-target="#tabBrand">Branding Setup</button>
                </li>
                <li class="nav-item">
                    <button class="nav-link small py-2 fw-semibold" id="sec-tab" data-bs-toggle="tab" data-bs-target="#tabSec">Security Core</button>
                </li>
            </ul>

            <form action="" method="POST" class="tab-content pt-2" id="settingsTabContent">
                <!-- Tab GENERAL -->
                <div class="tab-pane fade show active text-start" id="tabGen" role="tabpanel">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Platform Public Title Name *</label>
                            <input type="text" name="site_title" class="form-control" value="<?php echo s($_SESSION['site_settings_extended']['site_title']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Platform Tagline *</label>
                            <input type="text" name="site_tagline" class="form-control" value="<?php echo s($_SESSION['site_settings_extended']['site_tagline']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Contact Inbox Email *</label>
                            <input type="email" name="site_contact_email" class="form-control font-mono" value="<?php echo s($_SESSION['site_settings_extended']['site_contact_email']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Contact Hotline Phone *</label>
                            <input type="text" name="site_contact_phone" class="form-control font-mono" value="<?php echo s($_SESSION['site_settings_extended']['site_contact_phone']); ?>" required>
                        </div>
                    </div>
                </div>

                <!-- Tab SEO -->
                <div class="tab-pane fade text-start" id="tabSeo" role="tabpanel">
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label small fw-bold">Global Google Meta Description *</label>
                            <textarea name="meta_description" class="form-control small" rows="3" required><?php echo s($_SESSION['site_settings_extended']['meta_description']); ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Google Universal Analytics ID (gtag) *</label>
                            <input type="text" name="google_analytics_id" class="form-control font-mono" value="<?php echo s($_SESSION['site_settings_extended']['google_analytics_id']); ?>" placeholder="G-..." required>
                        </div>
                    </div>
                </div>

                <!-- Tab PAYMENTS -->
                <div class="tab-pane fade text-start" id="tabPay" role="tabpanel">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">PayU Business Merchant Key ID *</label>
                            <input type="text" name="payu_merchant_key" class="form-control font-mono" value="<?php echo s($_SESSION['site_settings_extended']['payu_merchant_key']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">PayU Secure Salt String hash *</label>
                            <input type="text" name="payu_salt_hash" class="form-control font-mono" value="<?php echo s($_SESSION['site_settings_extended']['payu_salt_hash']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Global Portal Currency *</label>
                            <input type="text" name="currency_code" class="form-control" value="<?php echo s($_SESSION['site_settings_extended']['currency_code']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">SaaS GST Taxation Percentage *</label>
                            <input type="text" name="gst_percentage" class="form-control font-mono" value="<?php echo s($_SESSION['site_settings_extended']['gst_percentage']); ?>" required>
                        </div>
                    </div>
                </div>

                <!-- Tab BRANDING -->
                <div class="tab-pane fade text-start" id="tabBrand" role="tabpanel">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Portal Accent Brand Color Hex *</label>
                            <input type="color" name="accent_color" class="form-control form-control-color w-full" value="<?php echo s($_SESSION['site_settings_extended']['accent_color']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Logo Image Asset Source *</label>
                            <input type="text" name="logo_asset" class="form-control font-mono text-dark" value="<?php echo s($_SESSION['site_settings_extended']['logo_asset']); ?>" required>
                        </div>
                    </div>
                </div>

                <!-- Tab SECURITY -->
                <div class="tab-pane fade text-start" id="tabSec" role="tabpanel">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold">Lockout Idle Sessions (Minutes) *</label>
                            <input type="number" name="session_lock_out_minutes" class="form-control font-mono" value="<?php echo s($_SESSION['site_settings_extended']['session_lock_out_minutes']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small">Toggle Multi-level OTP Verification on Logins *</label>
                            <select name="enable_otp_login" class="form-select">
                                <option value="1" <?php echo ($_SESSION['site_settings_extended']['enable_otp_login'] == 1) ? 'selected' : ''; ?>>OTP verification force-activated (Max Security)</option>
                                <option value="0" <?php echo ($_SESSION['site_settings_extended']['enable_otp_login'] == 0) ? 'selected' : ''; ?>>Password authentication only</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="text-end pt-4 border-top mt-4">
                    <button type="submit" class="btn btn-primary bg-primary border-0 btn-sm px-4">Apply Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
render_footer();
?>
