<?php
/**
 * ExamDuniya - Forgot Password / OTP Verification Demo
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email'])) {
        $email = trim($_POST['email']);
        set_flash_message('success', 'A 6-digit OTP code has been dispatched to ' . htmlspecialchars($email) . '. [Simulated Code: 832910]');
        $_SESSION['forgot_email'] = $email;
    } else if (isset($_POST['otp'])) {
        $otp = trim($_POST['otp']);
        if ($otp === '832910') {
            set_flash_message('success', 'OTP Verified! Please configure a new password.');
            $_SESSION['otp_verified'] = true;
        } else {
            set_flash_message('danger', 'Invalid OTP code. Please enter 832910.');
        }
    } else if (isset($_POST['new_pass'])) {
        $new_pass = trim($_POST['new_pass']);
        $password_check = validate_password($new_pass);
        if (!$password_check['valid']) {
            set_flash_message('danger', 'Password did not meet security rules limit: ' . implode(' ', $password_check['errors']));
        } else {
            $email = $_SESSION['forgot_email'] ?? '';
            if (!empty($email)) {
                $hashed = password_hash($new_pass, PASSWORD_BCRYPT);
                $stmt_update = $pdo->prepare("UPDATE `users` SET `password` = :password WHERE `email` = :email");
                $stmt_update->execute([
                    ':password' => $hashed,
                    ':email' => $email
                ]);
            }
            set_flash_message('success', 'Your password hash has been updated successfully on the candidate registry! Please log in to proceed.');
            unset($_SESSION['forgot_email'], $_SESSION['otp_verified']);
            header('Location: ' . BASE_URL . 'login.php');
            exit;
        }
    }
}

render_header("Reset Password");
?>

<div class="row align-items-center justify-content-center py-5 text-dark">
    <div class="col-md-6 col-lg-5">
        <div class="card border-0 bg-white shadow-lg p-4 p-md-5 rounded-4">
            <h3 class="fw-bold font-sans text-center mb-1">Aspirant Recovery</h3>
            <p class="text-muted text-center small mb-4">Regain access to your ExamDuniya mock suite.</p>
            
            <?php if (empty($_SESSION['forgot_email'])): ?>
                <!-- Step 1: Input Email -->
                <form action="" method="POST">
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-secondary">Verify Email Address</label>
                        <input type="email" name="email" class="form-control py-2.5 bg-light border-0" placeholder="amit@examduniya.in" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2.5 border-0" style="background-color: var(--secondary-color);">Generate OTP Code</button>
                </form>
            <?php elseif (empty($_SESSION['otp_verified'])): ?>
                <!-- Step 2: Verification Code -->
                <form action="" method="POST" class="text-center">
                    <p class="small text-muted mb-3">Please key in the simulated code: <strong>832910</strong></p>
                    <div class="mb-4">
                        <input type="text" name="otp" class="form-control text-center py-3 fs-4 fw-bold bg-light border-0" placeholder="000000" maxlength="6" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2.5 border-0" style="background-color: var(--secondary-color);">Verify OTP</button>
                </form>
            <?php else: ?>
                <!-- Step 3: Configure New Password -->
                <form action="" method="POST">
                    <div class="mb-4">
                        <label class="form-label small fw-bold">Set New Password</label>
                        <input type="password" name="new_pass" class="form-control py-2.5 bg-light border-0" placeholder="••••••••" required>
                        <div class="form-text text-muted mt-1" style="font-size: 11px; line-height: 1.4;">
                            <i class="feather-info me-1 text-primary"></i> Must be <strong>8+ characters</strong> long, contain at least <strong>1 number</strong>, and <strong>1 special character</strong> (e.g. @, #, $, !, %).
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2.5 border-0" style="background-color: var(--secondary-color);">Update Password</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
render_footer();
?>
