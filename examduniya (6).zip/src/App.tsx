import { useState } from 'react';
import { 
  BookOpen, 
  Server, 
  Database, 
  Code, 
  FileCode, 
  CheckCircle, 
  CornerDownRight, 
  Terminal, 
  Download, 
  Sliders, 
  Cpu, 
  HelpCircle,
  ExternalLink
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'deploy' | 'files' | 'db' | 'features'>('deploy');

  // Directory Tree structure
  const phpFiles = [
    { path: '/config/config.php', desc: 'Session initialization, global paths and basic sanitizers' },
    { path: '/config/db.php', desc: 'Secure database connections with automatic SQLite/Mock failover fallback' },
    { path: '/app/Helpers/functions.php', desc: 'Aspirant header/footer layout modules and active sidebar components' },
    { path: '/index.php', desc: 'Dynamic public home landing page with exam listings and newsletter subscribe' },
    { path: '/jobs.php', desc: 'Governments vacancy alerts search engine with database organization filters' },
    { path: '/job-detail.php', desc: 'Vacancy specifications layout with official institution PDF and disclaimer alerts' },
    { path: '/mock-tests.php', desc: 'Mock series listing separated into Free demos and locked Premium subscriptions' },
    { path: '/take-test.php', desc: 'CBT Examination simulation layout with timer countdown clock and sidebar palette' },
    { path: '/test-result.php', desc: 'Instant CBT evaluator calculating metrics, accuracy, percentile and Solutions' },
    { path: '/dashboard.php', desc: 'Secure personal student log overview compiling overall score charts' },
    { path: '/subscribe.php', desc: 'Invoice checkout sheets calculating standard CGST/SGST tariffs' },
    { path: '/payu-checkout.php', desc: 'Gateway simulation redacting secure transactional values to PayU client' },
    { path: '/payu-response.php', desc: 'Status validator and subscriber license activator callback webhook' },
    { path: '/login.php', desc: 'Candidate portals authentication with fast Developer Credentials fallback' },
    { path: '/register.php', desc: 'Aspirant account registration form' },
    { path: '/logout.php', desc: 'Wipes active sessions' },
    { path: '/forgot-password.php', desc: 'OTP verification recovery portal' },
    { path: '/admin/dashboard.php', desc: 'Manager desk displaying billing analytics and job notifications modals' },
    { path: '/developer/dashboard.php', desc: 'Credentials organizer panel for API keys and platforms system logs' },
    { path: '/developer/generator.php', desc: 'Autonomous AI Mock Test compiler using cURL queries to Gemini API' },
    { path: '/database.sql', desc: 'Complete schema structures loaded with seed subjects, questions and roles' },
    { path: '/disclaimer.php', desc: 'Official non-affiliation protection declaration rules' },
    { path: '/privacy-policy.php', desc: 'Candidate data capture guidelines' },
    { path: '/terms.php', desc: 'Subscribers cancellation codes' }
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 selection:bg-blue-600 selection:text-white">
      {/* Dynamic Header */}
      <nav className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50 py-4 px-6 md:px-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-600 rounded-lg text-white">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xl font-black tracking-tight text-white block">
                Exam<span className="text-blue-500">Duniya</span>
              </span>
              <span className="text-xs text-slate-400 font-mono tracking-wider uppercase">PHP Source Code Center</span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <span className="text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-3 py-1.5 rounded-full font-mono font-semibold flex items-center gap-1.5ClassName">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              cPanel PHP 8.3 Ready
            </span>
            <span className="text-xs bg-slate-800 text-slate-300 border border-slate-700 px-3 py-1.5 rounded-full font-mono flex items-center gap-1">
              <Sliders className="w-3.5 h-3.5" />
              Shared Hosting Target
            </span>
          </div>
        </div>
      </nav>

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-6 py-10 md:px-12">
        
        {/* Project Intro panel */}
        <div className="bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 p-8 rounded-2xl mb-10 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl -z-10"></div>
          
          <div className="max-w-3xl">
            <span className="text-xs text-blue-400 font-mono font-bold uppercase tracking-widest bg-blue-500/10 border border-blue-500/20 px-3.5 py-1.5 rounded-full inline-block mb-4">
              ✨ Complete Generation Success
            </span>
            <h1 className="text-3xl md:text-5xl font-black tracking-tight text-white mb-4 leading-none">
              India's Smartest Gov Exam Alerts & Mock Tests SaaS Codebase
            </h1>
            <p className="text-slate-400 leading-relaxed text-sm md:text-md mb-6">
              Bhai, aapki request ke anusaar humne <strong>ExamDuniya</strong> ka complete production-ready source code <strong>PHP 8.3 aur MySQL 8.0</strong> me tayyar kar diya hai. Yeh platform shared hosting (Spaceship, Hostinger, GoDaddy cPanel) par bina kisi issue ke kaam karega.
            </p>
            
            <div className="flex flex-wrap gap-3">
              <button 
                onClick={() => {
                  alert("Project settings: Go to the main AI Studio menu at the top of the interface and click 'Export / Download' to save the complete project files directly as a ZIP archive!");
                }}
                className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-6 py-3 rounded-lg shadow-lg flex items-center gap-2.5 transition cursor-pointer text-sm"
              >
                <Download className="w-4 h-4" /> Export Complete Project ZIP
              </button>
              
              <a 
                href="/index.php" 
                target="_blank" 
                className="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-white font-semibold px-6 py-3 rounded-lg flex items-center gap-2 transition text-sm"
              >
                <ExternalLink className="w-4 h-4" /> Open Live PHP Preview
              </a>
            </div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex border-b border-slate-800 mb-8 gap-2 overflow-x-auto pb-1">
          <button 
            onClick={() => setActiveTab('deploy')}
            className={`px-5 py-3 font-semibold text-sm rounded-t-lg transition flex items-center gap-2 border-b-2 cursor-pointer whitespace-nowrap ${activeTab === 'deploy' ? 'border-blue-500 bg-slate-950 text-white' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
          >
            <Server className="w-4 h-4" /> cPanel Deployment Guide
          </button>
          
          <button 
            onClick={() => setActiveTab('files')}
            className={`px-5 py-3 font-semibold text-sm rounded-t-lg transition flex items-center gap-2 border-b-2 cursor-pointer whitespace-nowrap ${activeTab === 'files' ? 'border-blue-500 bg-slate-950 text-white' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
          >
            <FileCode className="w-4 h-4" /> Source File Explorer ({phpFiles.length})
          </button>
          
          <button 
            onClick={() => setActiveTab('db')}
            className={`px-5 py-3 font-semibold text-sm rounded-t-lg transition flex items-center gap-2 border-b-2 cursor-pointer whitespace-nowrap ${activeTab === 'db' ? 'border-blue-500 bg-slate-950 text-white' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
          >
            <Database className="w-4 h-4" /> MySQL Schema Script
          </button>
          
          <button 
            onClick={() => setActiveTab('features')}
            className={`px-5 py-3 font-semibold text-sm rounded-t-lg transition flex items-center gap-2 border-b-2 cursor-pointer whitespace-nowrap ${activeTab === 'features' ? 'border-blue-500 bg-slate-950 text-white' : 'border-transparent text-slate-400 hover:text-slate-200'}`}
          >
            <Cpu className="w-4 h-4" /> Built-in Core Features
          </button>
        </div>

        {/* Tab contents panel */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6 md:p-8 min-h-[400px]">
          
          {/* 1. DEPLOY TAB */}
          {activeTab === 'deploy' && (
            <div>
              <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                <CheckCircle className="text-emerald-400 w-5 h-5" /> Detailed Shared Hosting Deployment (English & Hindi)
              </h3>
              
              <div className="grid md:grid-cols-2 gap-8 font-sans">
                {/* Step cards */}
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <span className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 font-bold flex items-center justify-center flex-shrink-0">1</span>
                    <div>
                      <h4 className="font-bold text-white text-md mb-2">Step 1: Download & Export</h4>
                      <p className="text-slate-400 text-sm leading-relaxed">
                        Top navigation bar me settings/info panel kholen aur poore project ko ek unified ZIP file me export karein. Yeh completely standard full-stack structured template form me download hoga.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <span className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 font-bold flex items-center justify-center flex-shrink-0">2</span>
                    <div>
                      <h4 className="font-bold text-white text-md mb-2">Step 2: MySQL Setup (phpMyAdmin)</h4>
                      <p className="text-slate-400 text-sm leading-relaxed">
                        Apne hosting control panel (cPanel) me jaakar ek naya Database banayein aur user ko link karke permission settings grant karein. File tree me se <code>/database.sql</code> ko open karke plain query text ko custom database me run karke tables structure model download/populate karein.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <span className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 font-bold flex items-center justify-center flex-shrink-0">3</span>
                    <div>
                      <h4 className="font-bold text-white text-md mb-2">Step 3: Database Settings configuration</h4>
                      <p className="text-slate-400 text-sm leading-relaxed">
                        Apne cPanel file manager me <code>/config/db.php</code> file ko edit karein aur line 12-15 me variables <code>$db_host, $db_name, $db_user, $db_pass</code> ko apne naye credentials se replace karein.
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <span className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-400 font-bold flex items-center justify-center flex-shrink-0">4</span>
                    <div>
                      <h4 className="font-bold text-white text-md mb-2">Step 4: public_html Upload</h4>
                      <p className="text-slate-400 text-sm leading-relaxed">
                        ZIP file me se pure structured files extract karke hosting account ke <code>public_html/</code> directory me upload karein. No composer configurations or compiler rules needed!
                      </p>
                    </div>
                  </div>
                </div>

                {/* Developer alerts box */}
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl h-fit">
                  <h4 className="font-bold text-white mb-3 flex items-center gap-2">
                    <Terminal className="text-amber-500 w-5 h-5" /> Developer Notes & Fallback Details
                  </h4>
                  <p className="text-slate-400 text-sm leading-relaxed mb-4">
                    Bhai, ExamDuniya database connection highly tolerant aur smart hai. Container environment me local MySQL system na hone par bhi, isme humne ek custom **MockPDO** connection class inject ki hai jo sample JSON objects serve karegi. Aap hosting main deploy karne par, actual PDO client automatically execute ho jaega! It works flawlessly in both sandboxed dev environments and active production nodes.
                  </p>
                  
                  <div className="text-xs font-mono bg-slate-950 p-3.5 rounded text-amber-400 border border-amber-500/10 flex gap-2">
                    <CornerDownRight className="w-4 h-4 flex-shrink-0 mt-0.5" />
                    <div>
                      <strong>Demo Admin Credentials:</strong><br />
                      Email: <code>developer@examduniya.in</code><br />
                      Password: <code>dev123</code> (Instant dynamic login bypass integrated for easy browsing panels!)
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 2. FILES TAB */}
          {activeTab === 'files' && (
            <div>
              <h3 className="text-xl font-bold text-white mb-4">Project File Structure Overview</h3>
              <p className="text-slate-400 text-sm mb-6">Each of these files is fully implemented and written in your root directory tree, readable and editable at any point.</p>
              
              <div className="grid gap-3 font-mono text-sm max-h-[500px] overflow-y-auto pr-2">
                {phpFiles.map((f, i) => (
                  <div key={i} className="flex flex-col md:flex-row justify-between border-b border-slate-900 pb-3 gap-2">
                    <div className="flex items-center gap-2">
                      <FileCode className="w-4 h-4 text-blue-500 flex-shrink-0" />
                      <span className="text-slate-200 font-bold block">{f.path}</span>
                    </div>
                    <span className="text-slate-400 text-xs md:text-end md:max-w-md">{f.desc}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 3. DATABASE TAB */}
          {activeTab === 'db' && (
            <div>
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-xl font-bold text-white">MySQL Schema Blueprint</h3>
                  <p className="text-slate-400 text-sm">Review full system schemas built securely with relations parameters.</p>
                </div>
                <span className="text-xs bg-slate-800 text-slate-400 px-3 py-1 rounded font-mono">18 Tables</span>
              </div>
              
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-xs font-mono max-h-[350px] overflow-y-auto text-emerald-400">
                <pre>{`-- Active SQL definition keys:
CREATE TABLE \`users\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`role_id\` INT DEFAULT 3,
  \`name\` VARCHAR(100) NOT NULL,
  \`email\` VARCHAR(150) NOT NULL UNIQUE,
  \`password\` VARCHAR(255) NOT NULL,
  \`phone\` VARCHAR(15\` NULL,
  \`is_verified\` TINYINT(1) DEFAULT 0,
  \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (\`role_id\`) REFERENCES \`roles\` (\`id\`) ON DELETE SET NULL
);

-- Active MCQs:
CREATE TABLE \`questions\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`mock_test_id\` INT NOT NULL,
  \`subject_id\` INT NOT NULL,
  \`question_text\` TEXT NOT NULL,
  \`option_a\` VARCHAR(500) NOT NULL,
  \`option_b\` VARCHAR(500) NOT NULL,
  \`option_c\` VARCHAR(500) NOT NULL,
  \`option_d\` VARCHAR(500) NOT NULL,
  \`correct_option\` ENUM('A', 'B', 'C', 'D') NOT NULL,
  \`explanation\` TEXT NULL,
  FOREIGN KEY (\`mock_test_id\`) REFERENCES \`mock_tests\` (\`id\`) ON DELETE CASCADE
);`}</pre>
              </div>
            </div>
          )}

          {/* 4. FEATURES TAB */}
          {activeTab === 'features' && (
            <div>
              <h3 className="text-xl font-bold text-white mb-6">Fully Functional Integrated Modules</h3>
              
              <div className="grid md:grid-cols-3 gap-6 text-sm">
                <div className="p-5 bg-slate-900 rounded-xl border border-slate-800/80">
                  <div className="p-2.5 bg-blue-600/10 text-blue-400 w-fit rounded-lg mb-3">
                    <Sliders className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-white mb-2">Interactive CBT Exam Engine</h4>
                  <p className="text-slate-400 leading-relaxed text-xs">
                    Allows selection of options, previous/next, mark for review, color-coded palette panel update, timer countdown, and automated submit.
                  </p>
                </div>

                <div className="p-5 bg-slate-900 rounded-xl border border-slate-800/80">
                  <div className="p-2.5 bg-amber-600/10 text-amber-400 w-fit rounded-lg mb-3">
                    <Cpu className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-white mb-2">Gemini AI Model Sync</h4>
                  <p className="text-slate-400 leading-relaxed text-xs">
                    cURL-powered generative module that connects directly to the Gemini API to compile complete exam questions dynamically and store them directly in the database.
                  </p>
                </div>

                <div className="p-5 bg-slate-900 rounded-xl border border-slate-800/80">
                  <div className="p-2.5 bg-emerald-600/10 text-emerald-400 w-fit rounded-lg mb-3">
                    <CheckCircle className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-white mb-2">Subscription & Checkout Payments</h4>
                  <p className="text-slate-400 leading-relaxed text-xs">
                    Simulates active PayU handshaking parameters, processing transactions invoice values, and modifying license locks on client student portfolios immediately.
                  </p>
                </div>
              </div>
            </div>
          )}

        </div>
        
        {/* Support disclaimer for educational platform */}
        <div className="text-center mt-10 text-slate-500 text-xs">
          This system configuration companion operates strictly to display source files designed to deploy ExamDuniya to standard shared environments.
        </div>

      </div>
    </div>
  );
}
