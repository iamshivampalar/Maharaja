<?php
/**
 * ExamDuniya - Custom Shortlink Redirect Router Engine
 */

require_once __DIR__ . '/config/db.php';

$slug = trim($_GET['q'] ?? '');

if (empty($slug)) {
    // Fallback to home
    header("Location: " . BASE_URL . "index.php");
    exit;
}

// Map the full source string to match session configurations
$match_source = '/go/' . ltrim($slug, '/');

// Initialize redirects configuration if not set
if (empty($_SESSION['custom_redirects'])) {
    session_start();
}

$target = '';
$type = 302; // Default temporary

if (!empty($_SESSION['custom_redirects'])) {
    foreach ($_SESSION['custom_redirects'] as &$r) {
        if (strtolower($r['source']) === strtolower($match_source)) {
            // Found redirect
            $r['clicks']++;
            
            // Record referrer
            $referer = $_SERVER['HTTP_REFERER'] ?? 'Direct';
            $ref_domain = 'Direct';
            if ($referer !== 'Direct' && filter_var($referer, FILTER_VALIDATE_URL)) {
                $parsed = parse_url($referer);
                $ref_domain = $parsed['host'] ?? 'Direct';
                if (str_contains($ref_domain, 't.me') || str_contains($ref_domain, 'telegram')) {
                    $ref_domain = 'Telegram';
                } elseif (str_contains($ref_domain, 'google')) {
                    $ref_domain = 'Google';
                } elseif (str_contains($ref_domain, 'youtube')) {
                    $ref_domain = 'YouTube';
                }
            }
            
            if (isset($r['referrers'][$ref_domain])) {
                $r['referrers'][$ref_domain]++;
            } else {
                $r['referrers'][$ref_domain] = 1;
            }
            
            $target = $r['target'];
            $type = str_contains($r['type'], '301') ? 301 : 302;
            break;
        }
    }
}

// Fallbacks for standard routes if session hasn't finished boot loading
if (empty($target)) {
    if ($slug === 'ssc') {
        $target = 'https://ssc.gov.in';
    } elseif ($slug === 'up-police') {
        $target = 'https://uppbpb.gov.in';
    } else {
        $target = BASE_URL . "index.php";
    }
}

// Send appropriate status code redirect
if ($type === 301) {
    header("HTTP/1.1 301 Moved Permanently");
} else {
    header("HTTP/1.1 302 Found");
}

header("Location: " . $target);
exit;
