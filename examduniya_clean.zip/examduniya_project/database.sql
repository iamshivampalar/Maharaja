-- ==========================================
-- EXAMDUNIYA - COMPLETE DATABASE SCHEMA
-- Compatible with MySQL 8.0+ / MariaDB
-- Perfect for cPanel Shared Hosting
-- ==========================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `user_attempts`;
DROP TABLE IF EXISTS `payments`;
DROP TABLE IF EXISTS `subscriptions`;
DROP TABLE IF EXISTS `questions`;
DROP TABLE IF EXISTS `mock_tests`;
DROP TABLE IF EXISTS `subjects`;
DROP TABLE IF EXISTS `current_affairs`;
DROP TABLE IF EXISTS `exam_calendar`;
DROP TABLE IF EXISTS `answer_keys`;
DROP TABLE IF EXISTS `results`;
DROP TABLE IF EXISTS `admit_cards`;
DROP TABLE IF EXISTS `jobs`;
DROP TABLE IF EXISTS `roles_users`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `roles`;
DROP TABLE IF EXISTS `site_settings`;
DROP TABLE IF EXISTS `logs`;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. Roles table
CREATE TABLE `roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL UNIQUE,
  `description` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1, 'Developer', 'Full database, system settings and AI control access'),
(2, 'Admin', 'Manager of jobs, notifications, mock tests, and billing'),
(3, 'User', 'Standard student or platform subscriber');

-- 2. Users table
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `role_id` INT DEFAULT 3,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(15) NULL,
  `is_verified` TINYINT(1) DEFAULT 0,
  `verification_token` VARCHAR(100) NULL,
  `otp_code` VARCHAR(6) NULL,
  `otp_expiry` DATETIME NULL,
  `google_id` VARCHAR(100) NULL,
  `avatar` VARCHAR(255) DEFAULT 'assets/img/default-avatar.png',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default accounts (Passwords are hashed 'admin123' / 'dev123' and standard '123456')
-- Developer Password: dev123 (hash: $2y$10$iNOnL9tS03S3vV8MvUWhr.a9tEofkE00M1lZIDi.S00AghFvA8ZgS)
-- Admin Password: admin123 (hash: $2y$10$9wG/bOnE7m1I.K9K3H70XOxuV5RSTgN.oD80jO01P9Y.d0YfeT0iK)
-- User Password: user123 (hash: $2y$10$DqV.v9XoRk96FvOQoxk0e.rTfK.QOn3O7VfUOgfP9Ryeu7aH2wY6C)
INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `password`, `phone`, `is_verified`) VALUES
(1, 1, 'ExamDuniya Dev', 'developer@examduniya.in', '$2y$10$iNOnL9tS03S3vV8MvUWhr.a9tEofkE00M1lZIDi.S00AghFvA8ZgS', '9999999991', 1),
(2, 2, 'ExamDuniya Admin', 'admin@examduniya.in', '$2y$10$9wG/bOnE7m1I.K9K3H70XOxuV5RSTgN.oD80jO01P9Y.d0YfeT0iK', '9999999992', 1),
(3, 3, 'Amit Sharma', 'amit@examduniya.in', '$2y$10$DqV.v9XoRk96FvOQoxk0e.rTfK.QOn3O7VfUOgfP9Ryeu7aH2wY6C', '9999999993', 1);

-- 3. Jobs/Vacancy Notifications
CREATE TABLE `jobs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `organization` VARCHAR(255) NOT NULL, -- e.g. "SSC", "UPPRPB", "NTPC"
  `post_name` VARCHAR(255) NOT NULL,
  `total_vacancies` INT NOT NULL DEFAULT 0,
  `qualification` VARCHAR(255) NOT NULL,
  `age_limit` VARCHAR(100) NULL,
  `salary_scale` VARCHAR(100) NULL,
  `start_date` DATE NULL,
  `end_date` DATE NULL,
  `application_fee` VARCHAR(255) NULL,
  `official_notification_url` VARCHAR(500) NULL,
  `apply_online_url` VARCHAR(500) NULL,
  `official_website_url` VARCHAR(500) NULL,
  `description` TEXT NULL,
  `exam_date` VARCHAR(150) NULL,
  `status` ENUM('Active', 'Expired', 'Draft') DEFAULT 'Active',
  `views_count` INT DEFAULT 0,
  `is_trending` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `jobs` (`title`, `slug`, `organization`, `post_name`, `total_vacancies`, `qualification`, `age_limit`, `salary_scale`, `start_date`, `end_date`, `application_fee`, `official_notification_url`, `apply_online_url`, `official_website_url`, `description`, `exam_date`, `is_trending`) VALUES
('UP Police Constable Recruitment 2026', 'up-police-constable-recruitment-2026', 'UPPRPB', 'Constable (Civil Police)', 45000, '12th Class Pass or equivalent', '18-25 Years', 'Rs. 21,700 - 69,100/-', '2026-06-05', '2026-07-05', 'General/OBC: Rs 400 | SC/ST: Rs 400', 'https://uppbpb.gov.in/pdf/notice-2026-constable.pdf', 'https://uppbpb.gov.in/apply', 'https://uppbpb.gov.in', 'Uttar Pradesh Police Recruitment and Promotion Board (UPPRPB) has announced a massive notification for the post of Constable Civil Police. Eligible male and female candidates can apply online from June 5, 2026. Make sure to download the notification and review physical fitness guidelines.', 'September 2026', 1),
('SSC GD Constable Notification 2026', 'ssc-gd-constable-notification-2026', 'SSC', 'GD Constable in BSF, CISF, CRFP, SSB, ITBP', 39000, '10th Class Matriculation', '18-23 Years', 'Rs. 21,700 - 69,100/-', '2026-05-15', '2026-06-20', 'Gen/OBC/EWS: Rs 100 | SC/ST/Ex-Servicemen/Female: Rs 0', 'https://ssc.gov.in/files/notice-2026-gd.pdf', 'https://ssc.gov.in/apply', 'https://ssc.gov.in', 'Staff Selection Commission invites online applications for General Duty Constables in various Paramilitary forces. Excellent opportunity for matric pass students.', 'October 2026', 1),
('Railway RRC Group D Vacancy 2026', 'railway-rrc-group-d-vacancy-2026', 'RRB', 'Track Maintainer Grade IV, Assistant Pointman', 103000, '10th Pass or ITI from NCVT/SCVT', '18-33 Years', 'Level 1 of 7th CPC Pay Matrix', '2026-06-12', '2026-07-15', 'General/OBC: Rs 500 (Refundable Rs 400) | SC/ST: Rs 250 (Refundable Rs 250)', 'https://indianrailways.gov.in/rrc/group_d_notice.pdf', 'https://rrcb.gov.in', 'https://indianrailways.gov.in', 'Ministry of Railways (Railway Recruitment Boards) is planning a bumper enrollment for level-1 posts in various divisions. Get complete eligibility and medical standards.', 'December 2026', 1),
('SSC CGL 2026 Exam Notification Out', 'ssc-cgl-2026-exam-notification-out', 'SSC', 'Assistant Audit Officer, Inspector of Income Tax, Assistant Section Officer', 12000, 'Bachelor Degree/Graduation in any stream', '18-32 Years (Post-wise)', 'Pay Level-4 (Rs. 25,500) to Pay Level-8 (Rs. 1,51,100)', '2026-06-01', '2026-07-02', 'Gen/OBC: Rs 100 | SC/ST/Female: Rs 0', 'https://ssc.gov.in/files/cgl-2026.pdf', 'https://ssc.gov.in/apply-cgl', 'https://ssc.gov.in', 'Staff Selection Commission has rolled out official guidelines for CGL 2026. This is the premier exam for central government white-collar jobs. Scheme includes Tier-I computer based test and Tier-II exam pattern.', 'September 2026', 0);

-- 4. Admit Cards table
CREATE TABLE `admit_cards` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `job_id` INT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `title` VARCHAR(255) NOT NULL,
  `organization` VARCHAR(255) NOT NULL,
  `admit_card_url` VARCHAR(500) NOT NULL,
  `release_date` DATE NOT NULL,
  `instruction_notes` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admit_cards` (`job_id`, `slug`, `title`, `organization`, `admit_card_url`, `release_date`, `instruction_notes`) VALUES
(2, 'ssc-gd-constable-2026-admit-card', 'SSC GD Constable Exam 2026 Region-Wise Admit Card Status', 'SSC', 'https://ssc.gov.in/admit-card-download', '2026-06-01', 'Admit cards for Tier 1 have been released. Please download using Registration Number and Date of Birth. Bring standard photo-identities and double check dynamic reporting timings strictly.');

-- 5. Results table
CREATE TABLE `results` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `job_id` INT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `title` VARCHAR(255) NOT NULL,
  `organization` VARCHAR(255) NOT NULL,
  `result_pdf_url` VARCHAR(500) NULL,
  `official_result_url` VARCHAR(500) NOT NULL,
  `cutoff_details` TEXT NULL,
  `release_date` DATE NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `results` (`job_id`, `slug`, `title`, `organization`, `result_pdf_url`, `official_result_url`, `cutoff_details`, `release_date`) VALUES
(1, 'up-police-constable-written-result', 'UP Police Constable Written Exam Merit List & Result PDF', 'UPPRPB', 'https://uppbpb.gov.in/results/constable-written-list.pdf', 'https://uppbpb.gov.in/constable-result-portal', 'UR: 187.5 | OBC: 172.3 | SC: 154.5 | ST: 131.2. Shortlisted candidates are eligible for Document Verification & Physical Standard Test.', '2026-05-28');

-- 6. Answer Keys table
CREATE TABLE `answer_keys` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `job_id` INT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `title` VARCHAR(255) NOT NULL,
  `organization` VARCHAR(255) NOT NULL,
  `answer_key_url` VARCHAR(500) NOT NULL,
  `objection_end_date` DATE NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `answer_keys` (`job_id`, `slug`, `title`, `organization`, `answer_key_url`, `objection_end_date`) VALUES
(4, 'ssc-cgl-tier-1-key-challenge', 'SSC CGL Tier 1 Answer Key Challenge Window Open', 'SSC', 'https://ssc.gov.in/answerkey-cgl-tier1', '2026-06-10');

-- 7. Exam Calendar table
CREATE TABLE `exam_calendar` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `exam_name` VARCHAR(255) NOT NULL,
  `organization` VARCHAR(255) NOT NULL,
  `notification_release_date` VARCHAR(100) NULL,
  `exam_date` VARCHAR(150) NOT NULL,
  `remarks` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `exam_calendar` (`exam_name`, `organization`, `notification_release_date`, `exam_date`, `remarks`) VALUES
('SSC Multi Tasking Staff (MTS)', 'SSC', 'July 2026', 'November 2026', 'CBT Computer Based Test in multiple shifts'),
('Railway RPF SI & Constable', 'RRB', 'Released', 'August 2026', 'Physical exam details available in final notifications');

-- 8. Current Affairs table
CREATE TABLE `current_affairs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) NOT NULL UNIQUE,
  `category` VARCHAR(100) DEFAULT 'National', -- e.g. National, International, Sports, Economy, Awards
  `content` TEXT NOT NULL,
  `published_date` DATE NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `current_affairs` (`title`, `slug`, `category`, `content`, `published_date`) VALUES
('ISRO Launches Aditya-L2 Solar Mission', 'isro-launches-aditya-l2-solar-mission', 'Science & Tech', 'The Indian Space Research Organisation (ISRO) successfully launched the Aditya-L2 solar spacecraft from Sriharikota. The mission aims to study the Lagrange point 2 orbits and solar space weather effects.', '2026-06-01'),
('India Wins World Championship in Athletics', 'india-wins-gold-championship', 'Sports', 'Indian athletics team displayed an outstanding performance securing three gold medals and setting new records in multiple track and field events in Tokyo.', '2026-05-30');

-- 9. Subjects / Exam Packs
CREATE TABLE `subjects` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `description` VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `subjects` (`id`, `name`, `code`, `description`) VALUES
(1, 'General Knowledge & Science', 'GK_GS', 'History, Geography, Polity, Science, and Static General Awareness'),
(2, 'Quantitative Aptitude', 'MATH', 'Mathematics, Arithmetic, Advance Algebra, Mensuration, and Data Interpretation'),
(3, 'Reasoning Ability', 'REAS', 'Analytical, Verbal, Non-verbal Logical Reasoning and Puzzle Solving'),
(4, 'English Language', 'ENG', 'Grammar, Vocabulary, Reading Comprehension, Sentence correction'),
(5, 'Hindi Language', 'HIN', 'Hindi Grammar, Vocabulary and Comprehension for state exams');

-- 10. Subscriptions Packs Details
CREATE TABLE `subscriptions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `category` ENUM('Individual', 'Combo') DEFAULT 'Individual',
  `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `duration_days` INT NOT NULL DEFAULT 365,
  `description` TEXT NULL,
  `badge` VARCHAR(50) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `subscriptions` (`id`, `name`, `code`, `category`, `price`, `duration_days`, `description`, `badge`) VALUES
(1, 'UP Police Exam Pack', 'UP_POLICE', 'Individual', 199.00, 365, 'Complete online mock test series for UP Police Constable, SI and Radio Operator. Includes 50+ Full Tests and 200+ Sectional Tests.', 'Hot Option'),
(2, 'SSC GD Constable Pack', 'SSC_GD', 'Individual', 149.00, 180, 'Full test suite customized with the new general duty matric syllabus. Score, ranks, analytical reports.', NULL),
(3, 'Railway NTPC & Group D Pack', 'RAIL_COMBO', 'Individual', 249.00, 365, 'Combo mock package for railroad NTPC graduate & under-grad level, plus upcoming Group D exams.', 'Bestseller'),
(4, 'SSC CGL Premium Pack', 'SSC_CGL', 'Individual', 299.00, 365, 'Elite prep material mapping CGL Tier I & II Computer-Based Tests with negative marking simulated correctly.', 'Top Rated'),
(5, 'All Exams Unlimited Combo', 'ALL_EXAMS', 'Combo', 499.00, 365, 'Unlocks everything! Access UP Police, SSC, Banks, Defence, Railways and State PSC tests without limit.', 'Ultimate Value');

-- 11. Mock Tests Table
CREATE TABLE `mock_tests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `subscription_id` INT NULL, -- links mock test to a specific pack
  `title` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL, -- e.g. "SSC CGL", "UP Police", "Railway NTPC"
  `duration_minutes` INT NOT NULL DEFAULT 60,
  `total_questions` INT NOT NULL DEFAULT 50,
  `total_marks` DECIMAL(6,2) NOT NULL DEFAULT 100.00,
  `positive_marks` DECIMAL(4,2) NOT NULL DEFAULT 2.00,
  `negative_marks` DECIMAL(4,2) NOT NULL DEFAULT 0.50,
  `difficulty` ENUM('Easy', 'Medium', 'Hard') DEFAULT 'Medium',
  `is_free` TINYINT(1) DEFAULT 0,
  `created_by` INT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `mock_tests` (`id`, `subscription_id`, `title`, `category`, `duration_minutes`, `total_questions`, `total_marks`, `positive_marks`, `negative_marks`, `difficulty`, `is_free`) VALUES
(1, 1, 'UP Police Constable Full Mock Test 01', 'UP Police', 120, 10, 20.00, 2.00, 0.50, 'Medium', 1),
(2, 4, 'SSC CGL Tier-1 General Intelligence & Quantitative Practice', 'SSC CGL', 60, 10, 20.00, 2.00, 0.50, 'Medium', 0);

-- 12. Questions Table
CREATE TABLE `questions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `mock_test_id` INT NOT NULL,
  `subject_id` INT NOT NULL,
  `question_text` TEXT NOT NULL,
  `option_a` VARCHAR(500) NOT NULL,
  `option_b` VARCHAR(500) NOT NULL,
  `option_c` VARCHAR(500) NOT NULL,
  `option_d` VARCHAR(500) NOT NULL,
  `correct_option` ENUM('A', 'B', 'C', 'D') NOT NULL,
  `explanation` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`mock_test_id`) REFERENCES `mock_tests` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insertion of complete questions for Test 1 (UP Police Free Demo Test)
INSERT INTO `questions` (`mock_test_id`, `subject_id`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `explanation`) VALUES
(1, 1, 'Who was the founder of the Maurya Empire in ancient India?', 'Ashoka', 'Chandragupta Maurya', 'Samudragupta', 'Harsha', 'B', 'Chandragupta Maurya founded the Maurya Empire around 322 BCE with the mentorship and aid of Chanakya (Kautilya).'),
(1, 1, 'Which is the largest state in India by geographical land area?', 'Madhya Pradesh', 'Maharashtra', 'Uttar Pradesh', 'Rajasthan', 'D', 'Rajasthan is the largest state of India by area, spreading over 342,239 square kilometers.'),
(1, 2, 'A train covers a distance of 360 km in 4 hours. What is its speed in meters per second?', '25 m/s', '30 m/s', '15 m/s', '20 m/s', 'A', 'Speed = 360 / 4 = 90 km/hr. To convert to m/s: 90 * (5/18) = 25 m/s.'),
(1, 2, 'The sum of two consecutive numbers is 73. What is the value of the larger number?', '35', '36', '37', '38', 'C', 'Let numbers be x and x+1. x + x + 1 = 73 => 2x = 72 => x = 36. Larger number is 36 + 1 = 37.'),
(1, 3, 'If A is B is mother, C is B is son, D is C is sister, then how is D related to A?', 'Daughter', 'Granddaughter', 'Niece', 'Sister', 'B', 'C is B is son, and D is sister of C. Thus D is B is daughter. Since A is maternal/paternal grandparent of D, D is the granddaughter of A.'),
(1, 3, 'Look at this series: 7, 10, 8, 11, 9, 12, ... What number should come next?', '10', '7', '13', '11', 'A', 'This contains two alternating additive series: (7, 8, 9, [10]) and (10, 11, 12, ...). Value next is 10.'),
(1, 5, 'निम्नलिखित में से कौन सा शब्द "तत्सम" है?', 'सूरज', 'अग्नि', 'पत्ता', 'हाथ', 'B', 'संस्कृत के समान मूल शब्द को तत्सम कहते हैं। "अग्नि" तत्सम रूप है जबकि इसका तद्भव "आग" होता है।'),
(1, 5, ' "कमल" का सही पर्यायवाची शब्द कौन सा है?', 'राजीव', 'जलद', 'गगन', 'अम्बर', 'A', 'राजीव, सरोज, पंकज, जलज कमल के मुख्य पर्यायवाची शब्द हैं। जलद बादल का सूचक है।'),
(1, 1, 'Which river is known as the "Sorrow of Bihar"?', 'Kosi', 'Ganga', 'Yamuna', 'Gandak', 'A', 'The Kosi river is well known for causing severe floods in Bihar, thereby earning the title "Sorrow of Bihar".'),
(1, 1, 'In which year did the Battle of Plassey take place?', '1757', '1764', '1857', '1526', 'A', 'The Battle of Plassey was fought on June 23, 1757, between the Nawab of Bengal (Siraj-ud-daulah) and the British East India Company forces led by Robert Clive.');

-- 13. Payments Purchases log table
CREATE TABLE `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `subscription_id` INT NOT NULL,
  `txn_id` VARCHAR(150) NOT NULL UNIQUE,
  `amount` DECIMAL(10,2) NOT NULL,
  `tax_amount` DECIMAL(10,2) DEFAULT 0.00,
  `gateway` VARCHAR(50) DEFAULT 'PayU',
  `status` ENUM('Success', 'Failed', 'Pending') DEFAULT 'Pending',
  `invoice_num` VARCHAR(50) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Inserting active subscription purchase for User 3 (Amit Sharma) to "UP Police Exam Pack"
INSERT INTO `payments` (`id`, `user_id`, `subscription_id`, `txn_id`, `amount`, `tax_amount`, `gateway`, `status`, `invoice_num`) VALUES
(1, 3, 1, 'TXN_PAYU_4938210492', 199.00, 35.82, 'PayU', 'Success', 'ED-2026-10492');

-- 14. User Active Subscription Map (Stores validity)
CREATE TABLE `user_subscriptions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `subscription_id` INT NOT NULL,
  `purchase_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `expiry_date` DATE NOT NULL,
  `status` INT DEFAULT 1, -- 1 = Active, 0 = Expired
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_subscriptions` (`user_id`, `subscription_id`, `expiry_date`, `status`) VALUES
(3, 1, '2027-06-01', 1);

-- 15. User Mock Attempts Track
CREATE TABLE `user_attempts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `mock_test_id` INT NOT NULL,
  `answers_payload` JSON NOT NULL, -- saves question_id -> answered_option mappings
  `total_questions` INT NOT NULL DEFAULT 10,
  `attempted_questions` INT NOT NULL DEFAULT 0,
  `correct_answers` INT NOT NULL DEFAULT 0,
  `wrong_answers` INT NOT NULL DEFAULT 0,
  `obtained_score` DECIMAL(6,2) NOT NULL DEFAULT 0.00,
  `time_taken_seconds` INT NOT NULL,
  `completed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`mock_test_id`) REFERENCES `mock_tests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_attempts` (`id`, `user_id`, `mock_test_id`, `answers_payload`, `total_questions`, `attempted_questions`, `correct_answers`, `wrong_answers`, `obtained_score`, `time_taken_seconds`) VALUES
(1, 3, 1, '{"1":"B", "2":"D", "3":"A", "4":"B", "5":"B", "6":"A", "7":"B", "8":"A", "9":"A", "10":"B"}', 10, 10, 8, 2, 15.00, 480);

-- 16. Rankings/Leaderboard Cache (computed rank scores)
CREATE TABLE `rankings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `exams_count` INT DEFAULT 0,
  `aggregate_score` DECIMAL(10,2) DEFAULT 0.00,
  `rank_percentile` DECIMAL(5,2) DEFAULT 0.00,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `rankings` (`user_id`, `exams_count`, `aggregate_score`, `rank_percentile`) VALUES
(3, 1, 15.00, 92.50);

-- 17. Audit and System Configs
CREATE TABLE `site_settings` (
  `setting_key` VARCHAR(100) PRIMARY KEY,
  `setting_value` TEXT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `site_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'ExamDuniya'),
('primary_contact_email', 'contact@examduniya.in'),
('telegram_channel_username', 'examduniya_alerts'),
('telegram_bot_token', 'SAMPLE_TELEGRAM_BOT_TOKEN_XYZ'),
('gemini_api_key', 'SAMPLE_GEMINI_KEY_EXAMDUNIYA'),
('payu_merchant_key', 'PAYU_MERCHANT_KEY_DEMO_EXAMDUNIYA'),
('payu_salt', 'PAYU_SALT_KEY_DEMO_EXAMDUNIYA'),
('recaptcha_site_key', 'RECAPTCHA_HTML_SITE_KEY_DEMO'),
('recaptcha_secret_key', 'RECAPTCHA_SECRET_KEY_DEMO');

-- 18. Developer Logs table
CREATE TABLE `logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `level` ENUM('INFO', 'WARNING', 'ERROR', 'PAYMENT', 'AI') NOT NULL DEFAULT 'INFO',
  `message` TEXT NOT NULL,
  `payload` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `logs` (`level`, `message`, `ip_address`) VALUES
('INFO', 'Database successfully populated with basic schema, default admin roles, seed subjects, exam calendar dates, and mock tests.', '127.0.0.1');
