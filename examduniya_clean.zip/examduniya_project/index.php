<?php
/**
 * ExamDuniya - Homepage
 * Built cleanly in vanilla PHP + MySQL, Bootstrap 5.3 + Feather icons.
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

// Fetch lists from database (using safe raw queries on PDO object, mock active)
$stmt_jobs = $pdo->query("SELECT * FROM `jobs` WHERE `status` = 'Active' ORDER BY `created_at` DESC LIMIT 6");
$latest_jobs = $stmt_jobs->fetchAll();

$stmt_cards = $pdo->query("SELECT * FROM `admit_cards` ORDER BY `release_date` DESC LIMIT 3");
$admit_cards = $stmt_cards->fetchAll();

$stmt_results = $pdo->query("SELECT * FROM `results` ORDER BY `release_date` DESC LIMIT 3");
$results = $stmt_results->fetchAll();

$stmt_keys = $pdo->query("SELECT * FROM `answer_keys` ORDER BY `id` DESC LIMIT 3");
$answer_keys = $stmt_keys->fetchAll();

$stmt_calendar = $pdo->query("SELECT * FROM `exam_calendar` ORDER BY `id` ASC LIMIT 4");
$calendar_items = $stmt_calendar->fetchAll();

$stmt_affairs = $pdo->query("SELECT * FROM `current_affairs` ORDER BY `published_date` DESC LIMIT 3");
$current_affairs = $stmt_affairs->fetchAll();

render_header("India's Smartest Exam Alert & Mock Test Portal");
?>

<!-- Hero Area -->
<div class="row align-items-center bg-dark py-5 text-white px-md-5 rounded-4 mb-5 shadow-lg position-relative overflow-hidden" style="background: url('https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop') center/cover; min-height: 380px;">
    <!-- Absolute Dark Glass Overlay -->
    <div class="position-absolute top-0 start-0 w-100 h-100" style="background: linear-gradient(135deg, rgba(15, 23, 42, 0.95) 0%, rgba(15, 23, 42, 0.8) 100%); z-index: 1;"></div>
    
    <div class="col-lg-8 py-4 position-relative" style="z-index: 2;">
        <span class="badge text-uppercase tracking-wider px-3 py-2 text-white mb-3" style="background: var(--secondary-color); font-size: 11px; letter-spacing: 1px;">
            🚀 Welcome to ExamDuniya.in
        </span>
        <h1 class="display-4 fw-extrabold mb-3 font-sans" style="line-height: 1.15; letter-spacing: -1.5px;">
            India's Smartest Government <br><span class="text-primary" style="color: #60A5FA !important;">Exam Alerts & Mock Series</span>
        </h1>
        <p class="lead text-muted-small mb-4 fs-5" style="color: #94A3B8; max-width: 600px;">
            Get immediate notification releases, official vacancy PDFs, and perform unlimited real-test CBT practice matches to score premium ranks.
        </p>
        
        <!-- Live Search Bar -->
        <form action="<?php echo BASE_URL; ?>jobs.php" method="GET" class="row g-2 max-w-lg mb-2">
            <div class="col-xs-12 col-md-8">
                <div class="input-group">
                    <span class="input-group-text bg-white border-0"><i class="feather-search text-muted"></i></span>
                    <input type="text" name="search" class="form-control border-0 py-3 font-sans" style="font-size: 15px;" placeholder="Search UP Police, SSC, NTPC posts..." required>
                </div>
            </div>
            <div class="col-xs-12 col-md-4">
                <button type="submit" class="btn btn-primary w-100 py-3 border-0 fw-bold" style="background-color: var(--secondary-color); font-size: 15px;">Search Alert</button>
            </div>
        </form>
        <div class="small text-muted" style="color: #94A3B8 !important;"><i class="feather-info me-1"></i> Popular taglines: <strong>UP Constable 2026</strong>, <strong>SSC GD</strong>, <strong>CGL Tier 1</strong></div>
    </div>

    <!-- Quick Stat board -->
    <div class="col-lg-4 d-none d-lg-block position-relative" style="z-index: 2;">
        <div class="card bg-white bg-opacity-10 backdrop-blur border border-white border-opacity-10 p-4 rounded-3 text-white">
            <h6 class="fw-bold mb-3 border-bottom border-secondary pb-2 text-primary text-uppercase" style="color: #60A5FA !important; font-size:11px;">Live Activity Counters</h6>
            <div class="d-flex align-items-center mb-3">
                <div class="p-2 rounded bg-primary bg-opacity-25 me-3 text-primary" style="color: #60A5FA !important;"><i class="feather-users fs-4"></i></div>
                <div>
                    <h5 class="fw-bold mb-0">158,402+</h5>
                    <small class="text-muted text-uppercase" style="font-size:10px; color:#94A3B8 !important;">Enrolled Students</small>
                </div>
            </div>
            <div class="d-flex align-items-center mb-3">
                <div class="p-2 rounded bg-success bg-opacity-25 me-3 text-success"><i class="feather-file-text fs-4"></i></div>
                <div>
                    <h5 class="fw-bold mb-0">450+</h5>
                    <small class="text-muted text-uppercase" style="font-size:10px; color:#94A3B8 !important;">Mock Exams Available</small>
                </div>
            </div>
            <div class="d-flex align-items-center">
                <div class="p-2 rounded bg-warning bg-opacity-25 me-3 text-warning"><i class="feather-check-circle fs-4"></i></div>
                <div>
                    <h5 class="fw-bold mb-0">99.8%</h5>
                    <small class="text-muted text-uppercase" style="font-size:10px; color:#94A3B8 !important;">CBT Server Uptime</small>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Category Tabs Board -->
<div class="row mb-5">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold font-sans tracking-tight mb-1"><i class="feather-briefcase text-primary me-2"></i>Trending Recruitment Bulletins</h3>
                <p class="text-muted small">Updated live from official Central and State recruitment notifications.</p>
            </div>
            <a href="<?php echo BASE_URL; ?>jobs.php" class="btn btn-outline-primary btn-sm px-3 rounded-pill">View All Jobs <i class="feather-arrow-right"></i></a>
        </div>
        
        <div class="row g-4">
            <?php if (empty($latest_jobs)): ?>
                <div class="col-12 py-5 text-center">
                    <i class="feather-alert-triangle fs-1 text-muted-small d-block mb-3"></i>
                    <p class="text-muted">No vacancies declared today. Please check back shortly!</p>
                </div>
            <?php else: ?>
                <?php foreach ($latest_jobs as $job): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card glass-card h-100 p-4 border-0 position-relative d-flex flex-column justify-content-between">
                            <div>
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <span class="badge rounded shadow-sm px-3 py-1 badge-govt text-uppercase" style="font-size: 11px;">
                                        <?php echo s($job['organization']); ?>
                                    </span>
                                    <?php if (!empty($job['is_trending']) && $job['is_trending'] == 1): ?>
                                        <span class="badge rounded shadow-sm px-3 py-1 badge-trending" style="font-size: 11px;">
                                            🔥 Trending
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <h5 class="fw-bold mb-2 text-dark font-sans fs-5" style="min-height: 52px; line-height: 1.3;">
                                    <a href="<?php echo BASE_URL; ?>job-detail.php?slug=<?php echo s($job['slug']); ?>" class="text-dark text-decoration-none hover:text-primary">
                                        <?php echo s($job['title']); ?>
                                    </a>
                                </h5>
                                
                                <ul class="list-unstyled mb-4 small text-muted">
                                    <li class="mb-1"><i class="feather-folder me-2 text-muted"></i><strong>Vacancies:</strong> <?php echo number_format($job['total_vacancies']); ?> Posts</li>
                                    <li class="mb-1"><i class="feather-user me-2 text-muted"></i><strong>Eligibility:</strong> <?php echo s($job['qualification']); ?></li>
                                    <li class="mb-1"><i class="feather-calendar me-2 text-muted"></i><strong>End Date:</strong> <span class="text-danger"><?php echo date('d M, Y', strtotime($job['end_date'])); ?></span></li>
                                </ul>
                            </div>
                            
                            <a href="<?php echo BASE_URL; ?>job-detail.php?slug=<?php echo s($job['slug']); ?>" class="btn btn-outline-dark btn-sm w-100 rounded shadow-sm hover-primary">
                                View Details & Apply <i class="feather-chevron-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Dual Columns: Exam Alerts (Admit Cards, Results, Answer Keys) -->
<div class="row g-4 mb-5">
    <!-- Left Column: Admit Cards & Key Releases -->
    <div class="col-lg-6">
        <div class="card border-0 bg-white shadow-sm p-4 h-100 rounded-3">
            <div class="d-flex align-items-center mb-3">
                <div class="p-2 rounded bg-danger bg-opacity-10 me-2 text-danger"><i class="feather-download-cloud fs-5"></i></div>
                <h5 class="fw-bold mb-0 text-dark">Latest Admit Cards alerts</h5>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <tbody>
                        <?php if (empty($admit_cards)): ?>
                            <tr><td class="text-muted py-3 text-center">No active download portals live right now.</td></tr>
                        <?php else: ?>
                            <?php foreach ($admit_cards as $ac): ?>
                                <tr>
                                    <td class="py-3">
                                        <div class="fw-bold small text-dark"><?php echo s($ac['title']); ?></div>
                                        <div class="text-muted-small text-uppercase mt-1 text-muted" style="font-size: 10px;"><?php echo s($ac['organization']); ?> • Released <?php echo date('d M, Y', strtotime($ac['release_date'])); ?></div>
                                    </td>
                                    <td class="text-end">
                                        <a href="<?php echo s($ac['admit_card_url']); ?>" target="_blank" class="btn btn-link py-1 px-2 border border-danger text-danger rounded btn-sm text-decoration-none">
                                            Download <i class="feather-external-link small ms-1"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="d-flex align-items-center mb-3 mt-4">
                <div class="p-2 rounded bg-success bg-opacity-10 me-2 text-success"><i class="feather-key fs-5"></i></div>
                <h5 class="fw-bold mb-0 text-dark">Answer Keys Objection Portal</h5>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <tbody>
                        <?php if (empty($answer_keys)): ?>
                            <tr><td class="text-muted py-3 text-center">No current objection deadlines.</td></tr>
                        <?php else: ?>
                            <?php foreach ($answer_keys as $ak): ?>
                                <tr>
                                    <td class="py-3">
                                        <div class="fw-bold small text-dark"><?php echo s($ak['title']); ?></div>
                                        <div class="text-muted-small text-uppercase mt-1 text-muted" style="font-size: 10px;"><?php echo s($ak['organization']); ?> • Challenge ends <?php echo date('d M, Y', strtotime($ak['objection_end_date'])); ?></div>
                                    </td>
                                    <td class="text-end">
                                        <a href="<?php echo s($ak['answer_key_url']); ?>" target="_blank" class="btn btn-link py-1 px-2 border border-success text-success rounded btn-sm text-decoration-none">
                                            Challenge <i class="feather-external-link small ms-1"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Right Column: Results Announcements & Exam Schedule -->
    <div class="col-lg-6">
        <div class="card border-0 bg-white shadow-sm p-4 h-100 rounded-3">
            <div class="d-flex align-items-center mb-3">
                <div class="p-2 rounded bg-success bg-opacity-10 me-2 text-success"><i class="feather-award fs-5"></i></div>
                <h5 class="fw-bold mb-0 text-dark">Results and Selection Lists</h5>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <tbody>
                        <?php if (empty($results)): ?>
                            <tr><td class="text-muted py-3 text-center">No results uploaded today. Stay tuned!</td></tr>
                        <?php else: ?>
                            <?php foreach ($results as $res): ?>
                                <tr>
                                    <td class="py-3">
                                        <div class="fw-bold small text-dark"><?php echo s($res['title']); ?></div>
                                        <div class="text-muted-small text-muted mt-1" style="font-size: 10px;"><strong class="text-success">Rank List Available</strong> • Announced <?php echo date('d M, Y', strtotime($res['release_date'])); ?></div>
                                    </td>
                                    <td class="text-end">
                                        <a href="<?php echo s($res['official_result_url']); ?>" target="_blank" class="btn btn-link py-1 px-2 border border-success text-success rounded btn-sm text-decoration-none">
                                            Check Cutoff <i class="feather-external-link small ms-1"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Exam Calendar section -->
            <div id="exam-calendar" class="d-flex align-items-center mb-3 mt-4">
                <div class="p-2 rounded bg-info bg-opacity-10 me-2 text-info"><i class="feather-calendar fs-5"></i></div>
                <h5 class="fw-bold mb-0 text-dark">Upcoming Exam Calendar</h5>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <tbody>
                        <?php if (empty($calendar_items)): ?>
                            <tr><td class="text-muted py-3 text-center">No schedule defined.</td></tr>
                        <?php else: ?>
                            <?php foreach ($calendar_items as $cal): ?>
                                <tr>
                                    <td class="py-3">
                                        <div class="fw-bold small text-dark"><?php echo s($cal['exam_name']); ?></div>
                                        <div class="text-muted mt-1" style="font-size: 11px;"><i class="feather-file me-1"></i> Notification release: <?php echo s($cal['notification_release_date']); ?></div>
                                    </td>
                                    <td class="text-end">
                                        <span class="badge text-dark py-2 px-3 border" style="background-color: #F1F5F9; font-size:11px;">
                                            <i class="feather-clock me-1 text-primary"></i> <?php echo s($cal['exam_date']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Interactive Mock Tests Spotlight -->
<div class="row mb-5 bg-white py-5 px-md-4 rounded-4 shadow-sm border border-slate-100">
    <div class="col-12 text-center mb-4">
        <span class="badge bg-primary bg-opacity-10 text-primary py-2 px-3 mb-2 rounded-pill fw-bold" style="font-size:12px;">📊 EXAM SIMULATIONS</span>
        <h3 class="fw-bold font-sans tracking-tight mb-2">Practice Realistic Computer Based Tests (CBT)</h3>
        <p class="text-muted" style="max-width: 600px; margin: 0 auto;">Review standard UP Police, SSC SI and Railway NTPC papers with real-time test timer, negative marking logic, and custom subject solutions analysis.</p>
    </div>
    
    <div class="col-lg-6 mx-auto">
        <div class="card p-4 border border-warning border-opacity-50 text-center rounded-3 bg-warning bg-opacity-10 h-100 d-flex flex-column justify-content-between align-items-center">
            <div>
                <span class="badge bg-warning text-dark py-1 px-3 mb-2 rounded-pill fw-bold">💥 FREE DEMO TEST</span>
                <h5 class="fw-bold text-dark mb-2">UP Police Constable Mini Mock Test</h5>
                <p class="small text-muted mb-4">Duration: 120 Mins | 10 Questions | +2 Marks for Correct | -0.5 Negative marking. No subscription or credits required!</p>
            </div>
            <a href="<?php echo BASE_URL; ?>take-test.php?id=1" class="btn btn-dark w-100 py-3 font-sans fw-bold">
                <i class="feather-play-circle me-2"></i> Launch Mock Exam (Free)
            </a>
        </div>
    </div>
</div>

<!-- Current Affairs cards -->
<div id="current-affairs" class="row mb-5">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold font-sans tracking-tight mb-1"><i class="feather-globe text-primary me-2"></i>Daily Current Affairs</h3>
                <p class="text-muted small">Stay updated on national & international daily breakthroughs necessary for general knowledge sections.</p>
            </div>
        </div>
        
        <div class="row g-4">
            <?php foreach ($current_affairs as $ca): ?>
                <div class="col-md-6 mb-3">
                    <div class="card h-100 shadow-sm border-0 p-4 rounded-3 d-flex flex-column justify-content-between">
                        <div>
                            <span class="badge rounded bg-secondary bg-opacity-10 text-secondary px-3 py-1 mb-2 font-sans" style="font-size: 11px;">
                                <?php echo s($ca['category']); ?>
                            </span>
                            <h6 class="fw-bold text-dark fs-5 mb-2"><?php echo s($ca['title']); ?></h6>
                            <p class="text-muted small mb-3"><?php echo substr(s($ca['content']), 0, 160) . '...'; ?></p>
                        </div>
                        <div class="text-muted small border-top pt-2 d-flex justify-content-between align-items-center" style="font-size: 11px;">
                            <span><i class="feather-calendar me-1"></i> <?php echo date('d M, Y', strtotime($ca['published_date'])); ?></span>
                            <span class="text-primary fw-medium">Daily Alert</span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Join Telegram Box -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card p-5 border-0 text-white shadow-lg text-center d-flex flex-column align-items-center rounded-4" style="background: linear-gradient(135deg, #1D9BF0 0%, #0088CC 100%);">
            <i class="feather-send display-3 mb-3 text-white"></i>
            <h2 class="fw-extrabold mb-2 font-sans text-white">Never Miss An Alert! Join Our Telegram Channel</h2>
            <p class="text-white-50 max-w-xl mb-4 fs-5" style="max-width: 650px;">
                We broadcast immediate updates regarding Government notifications, results cutoff lists, admit card download pathways, daily current affairs summaries and free demo PDFs.
            </p>
            <a href="https://t.me/examduniya_alerts" target="_blank" class="btn btn-white text-primary btn-lg px-5 py-3 fw-bold rounded-pill bg-white shadow-sm hover:translate-y--2 border-0">
                <i class="feather-users me-2"></i> Join 50,000+ Aspirants Now
            </a>
        </div>
    </div>
</div>

<?php
render_footer();
?>
