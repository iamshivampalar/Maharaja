<?php
/**
 * ExamDuniya - Mock Tests Page
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

// Fetch Subscriptions Package catalog
$stmt_packs = $pdo->query("SELECT * FROM `subscriptions` ORDER BY `category` ASC, `price` ASC");
$packs = $stmt_packs->fetchAll();

// Fetch Free Mock Tests (Demo standard)
$stmt_free = $pdo->query("SELECT * FROM `mock_tests` WHERE `is_free` = 1 ORDER BY `id` ASC");
$free_tests = $stmt_free->fetchAll();

// Fetch Premium Mock Tests
$stmt_prem = $pdo->query("SELECT * FROM `mock_tests` WHERE `is_free` = 0 ORDER BY `id` ASC");
$prem_tests = $stmt_prem->fetchAll();

render_header("Interactive Online CBT Practice Mocks");
?>

<div class="row mb-4 text-dark">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>index.php" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Online Mock Tests</li>
            </ol>
        </nav>
        <span class="badge text-white px-3 py-1 bg-primary mb-2" style="background-color: var(--secondary-color) !important;">🖥️ Computer Based Test Simulation</span>
        <h2 class="fw-bold font-sans tracking-tight mb-2">Simulate Real Online Examinations</h2>
        <p class="text-muted">Engage in highly realistic CBT mocks with sectional palette grids, timer clock auto-submissions, and precise results analytics metrics.</p>
    </div>
</div>

<!-- Free Mock Section -->
<div class="row mb-5 text-dark">
    <div class="col-12 mb-3">
        <h4 class="fw-bold font-sans mb-1"><i class="feather-gift text-warning me-2"></i> Free Live Trial Demos</h4>
        <p class="small text-muted">Test device compatibility and exam system flow. Absolutely no credentials or payment required to begin.</p>
    </div>
    
    <div class="col-lg-6">
        <?php if (empty($free_tests)): ?>
            <div class="alert alert-secondary text-center py-4">No free trials published today. Please check back shortly!</div>
        <?php else: ?>
            <?php foreach ($free_tests as $ft): ?>
                <div class="card p-4 border border-warning border-opacity-30 rounded-3 shadow-sm bg-white mb-3 h-100 d-flex flex-column justify-content-between">
                    <div>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="badge bg-warning text-dark text-uppercase font-sans font-bold py-1 px-3">Free Practice Mock</span>
                            <span class="text-muted small"><i class="feather-award"></i> Level: <?php echo s($ft['difficulty']); ?></span>
                        </div>
                        <h5 class="fw-bold mb-2 font-sans fs-5 text-dark"><?php echo s($ft['title']); ?></h5>
                        <p class="small text-muted mb-4">
                            <strong>Duration:</strong> <?php echo s($ft['duration_minutes']); ?> Min 
                            | <strong>Total questions:</strong> <?php echo s($ft['total_questions']); ?> MCQ 
                            | <strong>Section:</strong> GK, Quant, Reasoning
                        </p>
                    </div>
                    
                    <a href="take-test.php?id=<?php echo (int)$ft['id']; ?>" class="btn btn-dark w-100 py-3 font-sans fw-bold rounded border-0 d-block text-center text-white text-decoration-none">
                        <i class="feather-play-circle me-1"></i> Start Examination Room
                    </a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <!-- Promotion Info -->
    <div class="col-lg-6">
        <div class="p-4 bg-primary bg-opacity-5 rounded-3 border h-100 d-flex flex-column justify-content-center">
            <h5 class="fw-bold text-dark font-sans d-flex align-items-center mb-3">
                <i class="feather-check-circle text-success me-2 fs-4"></i> Interactive CBT Console Rules
            </h5>
            <ul class="list-unstyled text-secondary small py-1" style="line-height:2;">
                <li><i class="feather-circle text-primary me-2 font-bold" style="font-size:8px;"></i> <strong>Timer Countdown</strong> starts immediately on clicking 'Start'.</li>
                <li><i class="feather-circle text-primary me-2 font-bold" style="font-size:8px;"></i> Use <strong>Save & Next</strong> to cache your option and move forward.</li>
                <li><i class="feather-circle text-primary me-2 font-bold" style="font-size:8px;"></i> Question palette on side charts <strong>Green</strong> for Answered, and <strong>Red</strong> for Unanswered.</li>
                <li><i class="feather-circle text-primary me-2 font-bold" style="font-size:8px;"></i> <strong>Auto Submit</strong> triggers itself if the examination timer expires.</li>
                <li><i class="feather-circle text-primary me-2 font-bold" style="font-size:8px;"></i> Subject wise accuracy graphs are rendered immediately on completion!</li>
            </ul>
        </div>
    </div>
</div>

<!-- Premium Packages Series Slider -->
<div class="row g-4 mb-5 text-dark">
    <div class="col-12 mb-2">
        <h4 class="fw-bold font-sans mb-1"><i class="feather-shopping-bag text-primary me-2"></i> Join Premium Mock Series (Subscription Plans)</h4>
        <p class="small text-muted">Purchase focused mock packages with complete analytics indices, rank cards, and detailed answers explanation cards.</p>
    </div>
    
    <?php foreach ($packs as $p): ?>
        <div class="col-md-6 col-lg-4">
            <div class="card bg-white p-4 h-100 rounded-3 shadow-sm border border-slate-100 glass-card position-relative d-flex flex-column justify-content-between">
                <div>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="badge rounded bg-primary bg-opacity-10 text-primary py-1 px-3" style="font-size: 11px;">
                            <?php echo s($p['category']); ?> Pack
                        </span>
                        <?php if (!empty($p['badge'])): ?>
                            <span class="badge rounded bg-warning text-dark py-1 px-3" style="font-size: 11px; font-weight:700;">
                                <?php echo s($p['badge']); ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <h5 class="fw-bold mb-1 text-dark font-sans"><?php echo s($p['name']); ?></h5>
                    <div class="text-muted small mb-3"><i class="feather-clock text-muted me-1"></i> Validity Duration: <?php echo s($p['duration_days']); ?> Days</div>
                    
                    <p class="small text-muted mb-4"><?php echo s($p['description']); ?></p>
                </div>
                
                <div>
                    <div class="d-flex align-items-baseline mb-4">
                        <span class="fs-2 fw-extrabold text-dark">₹<?php echo number_format($p['price'], 2); ?></span>
                        <span class="text-muted small ms-2">/ GST Inclusive</span>
                    </div>
                    
                    <a href="subscribe.php?pack=<?php echo s($p['code']); ?>" class="btn btn-primary w-100 py-3 border-0 rounded font-sans fw-bold shadow-sm" style="background-color: var(--secondary-color);">
                        Unlock Pack <i class="feather-shopping-cart ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Premium Mock Test List section -->
<div class="row g-4 mb-4 text-dark">
    <div class="col-12">
        <h4 class="fw-bold font-sans mb-1"><i class="feather-lock text-muted me-2"></i> Premium Live Test Series List</h4>
        <p class="small text-muted">Aspirants must unlock respective subscription packs above to activate these Premium CBT mocks.</p>
    </div>
    
    <?php if (empty($prem_tests)): ?>
        <div class="col-12 py-3 text-center text-muted">No premium exams online. Check back shortly.</div>
    <?php else: ?>
        <?php foreach ($prem_tests as $pt): ?>
            <div class="col-md-6">
                <div class="card p-4 border rounded shadow-sm bg-white d-flex flex-row justify-content-between align-items-center">
                    <div>
                        <span class="badge bg-secondary text-white text-uppercase font-sans py-1 px-3 mb-2" style="font-size:9px;">Locked Premium</span>
                        <h6 class="fw-bold mb-1 text-dark"><?php echo s($pt['title']); ?></h6>
                        <small class="text-muted"><?php echo s($pt['duration_minutes']); ?> Mins | <?php echo s($pt['total_questions']); ?> Questions</small>
                    </div>
                    <a href="take-test.php?id=<?php echo (int)$pt['id']; ?>" class="btn btn-outline-primary btn-sm rounded shadow-sm border px-3">
                        Launch <i class="feather-lock ms-1"></i>
                    </a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php
render_footer();
?>
