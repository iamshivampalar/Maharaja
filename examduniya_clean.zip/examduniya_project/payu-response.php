<?php
/**
 * ExamDuniya - PayU Payment Response validation & Subscription Activation
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

check_logged_in();

$payu_status = $_POST['payu_status'] ?? 'Failed';
$txn_id = $_POST['txn_id'] ?? '';
$sub_id = (int)($_POST['subscription_id'] ?? 1);
$amount = (float)($_POST['amount'] ?? 199.00);

if ($payu_status === 'Success') {
    // 1. Update Payment Status in database log (Simulation)
    $pdo->execute("UPDATE `payments` SET `status` = 'Success', `invoice_num` = 'ED-INV-" . rand(10302, 98402) . "' WHERE `txn_id` = '$txn_id'");
    
    // 2. Insert dynamic user subscription validity row in database map
    $expiry_date = date('Y-m-d', strtotime('+365 days'));
    $pdo->execute("INSERT INTO `user_subscriptions` (`user_id`, `subscription_id`, `expiry_date`, `status`) VALUES (" . (int)$_SESSION['user_id'] . ", $sub_id, '$expiry_date', 1)");
    
    set_flash_message('success', 'Thank you! Your payment of ₹' . number_format($amount, 2) . ' was processed successfully. High-tier CBT mock tests are now unlocked!');
    header('Location: ' . BASE_URL . 'dashboard.php');
    exit;
} else {
    $pdo->execute("UPDATE `payments` SET `status` = 'Failed' WHERE `txn_id` = '$txn_id'");
    set_flash_message('danger', 'Your payment was declined or aborted by user. Please try checking card rules or UPI authorization.');
    header('Location: ' . BASE_URL . 'subscribe.php');
    exit;
}
