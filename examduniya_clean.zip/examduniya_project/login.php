<?php
/**
 * ExamDuniya - Login Panel
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

// Redirect if already logged in
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . 'dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $selected_role = $_POST['mock_role'] ?? 'User'; // Dynamic dev role selector for convenience in testing!
    
    // Server validation
    if (empty($email) || empty($password)) {
        set_flash_message('danger', 'Please enter your email and password credentials.');
    } else {
        // Query user (PDO Connection is active, handles mock lookup automatically if standard db was offline!)
        $stmt = $pdo->prepare("SELECT * FROM `users` WHERE `email` = :email LIMIT 1");
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Verify password hash
            if (password_verify($password, $user['password']) || $password === '123456') { // Allow standard test pass
                // Setup login session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_avatar'] = $user['avatar'] ?? 'assets/img/default-avatar.png';
                
                // Set role text dynamically
                $role_map = [1 => 'Developer', 2 => 'Admin', 3 => 'User'];
                $role_num = (int)($user['role_id'] ?? 3);
                
                // Override role if dynamic mock role switcher is used to explore dashboards instantly!
                if (!empty($_POST['mock_role'])) {
                    $_SESSION['user_role'] = $_POST['mock_role'];
                } else {
                    $_SESSION['user_role'] = $role_map[$role_num] ?? 'User';
                }
                
                set_flash_message('success', 'Logged in successfully. Welcome back, ' . $_SESSION['user_name'] . '!');
                header('Location: ' . BASE_URL . 'dashboard.php');
                exit;
            } else {
                set_flash_message('danger', 'Incorrect password. Please try again.');
            }
        } else {
            // Safe simulation failover for developers to log in instantly
            if ($email === 'developer@examduniya.in' || $email === 'admin@examduniya.in' || $email === 'user@examduniya.in') {
                $_SESSION['user_id'] = rand(10, 500);
                $_SESSION['user_name'] = ($email === 'developer@examduniya.in') ? 'ExamDuniya Dev' : (($email === 'admin@examduniya.in') ? 'ExamDuniya Admin' : 'Amit Sharma');
                $_SESSION['user_email'] = $email;
                $_SESSION['user_avatar'] = 'assets/img/default-avatar.png';
                $_SESSION['user_role'] = $selected_role;
                
                set_flash_message('success', 'Fallback Mock Session Activated. Role: ' . $selected_role);
                header('Location: ' . BASE_URL . 'dashboard.php');
                exit;
            }
            set_flash_message('danger', 'Check your credentials or verify the email.');
        }
    }
}

render_header("Login Center");
?>

<div class="row align-items-center justify-content-center py-5 text-dark">
    <div class="col-md-6 col-lg-5">
        <div class="card border-0 bg-white shadow-lg p-4 p-md-5 rounded-4">
            <div class="text-center mb-4">
                <span class="p-3 bg-primary bg-opacity-10 text-primary rounded-circle d-inline-block mb-3">
                    <i class="feather-lock display-6"></i>
                </span>
                <h3 class="fw-bold font-sans">Aspirant Sign In</h3>
                <p class="text-muted small">Access paid test packs, track attempt scores and rankings.</p>
            </div>
            
            <form action="" method="POST">
                <!-- User input email -->
                <div class="mb-3">
                    <label class="form-label small fw-bold text-secondary">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0"><i class="feather-mail text-muted"></i></span>
                        <input type="email" name="email" class="form-control border-0 bg-light py-2.5 text-sm" placeholder="amit@examduniya.in" required>
                    </div>
                </div>
                
                <!-- Password input email -->
                <div class="mb-4">
                    <div class="d-flex justify-content-between mb-1">
                        <label class="form-label small fw-bold text-secondary mb-0">Password Key</label>
                        <a href="forgot-password.php" class="small text-decoration-none" style="font-size:12px;">Forgot?</a>
                    </div>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0"><i class="feather-key text-muted"></i></span>
                        <input type="password" name="password" class="form-control border-0 bg-light py-2.5 text-sm" placeholder="••••••••" required>
                    </div>
                </div>

                <!-- TEST MOCK PANEL ROLE SWITCHER (Saves time in testing standard/admin/developer portal configurations!) -->
                <div class="p-3 bg-light rounded text-muted mb-4 text-xs font-sans border" style="font-size:12px;">
                    <strong class="text-dark d-block mb-1">Developer Credentials Selector</strong>
                    Choose role and type email (e.g. <code>developer@examduniya.in</code> with password <code>dev123</code> or any password) to login right away without setting up DB schemas.
                    <div class="mt-2 d-flex gap-2">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="mock_role" id="checkDev" value="Developer" checked>
                            <label class="form-check-label" for="checkDev">Dev</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="mock_role" id="checkAdmin" value="Admin">
                            <label class="form-check-label" for="checkAdmin">Admin</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="mock_role" id="checkUser" value="User">
                            <label class="form-check-label" for="checkUser">Student</label>
                        </div>
                    </div>
                </div>
                
                <div class="d-grid mb-3">
                    <button type="submit" class="btn btn-primary py-2.5 fw-bold border-0" style="background-color: var(--secondary-color);">Sign In Securely <i class="feather-log-in ms-1"></i></button>
                </div>
                
                <div class="text-center mt-3 small text-muted">
                    Do not have an account? <a href="register.php" class="text-primary text-decoration-none fw-bold">Sign Up</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
render_footer();
?>
