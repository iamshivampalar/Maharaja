<?php
/**
 * ExamDuniya - Interactive CBT Mock Test Console
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

$test_id = $_GET['id'] ?? 1;

// Fetch Mock Test Parameters
$stmt = $pdo->prepare("SELECT * FROM `mock_tests` WHERE `id` = :id LIMIT 1");
$stmt->execute([':id' => (int)$test_id]);
$test = $stmt->fetch();

if (!$test) {
    set_flash_message('danger', 'The selected examination room does not exist.');
    header('Location: ' . BASE_URL . 'mock-tests.php');
    exit;
}

// Fetch questions mapped to this test
$stmt_q = $pdo->prepare("SELECT * FROM `questions` WHERE `mock_test_id` = :id ORDER BY `id` ASC");
$stmt_q->execute([':id' => (int)$test_id]);
$questions = $stmt_q->fetchAll();

if (empty($questions)) {
    // If empty, fetch standard mock pool questions from db mock state to satisfy test browse
    $stmt_q_fallback = $pdo->query("SELECT * FROM `questions` LIMIT 10");
    $questions = $stmt_q_fallback->fetchAll();
}

// Check verification (premium tests need login and activation)
if (!$test['is_free']) {
    check_logged_in();
    // Simulate check: check if purchased subscription pack exists
    $stmt_active = $pdo->prepare("SELECT * FROM `user_subscriptions` WHERE `user_id` = :uid AND `status` = 1");
    $stmt_active->execute([':uid' => $_SESSION['user_id']]);
    $active_sub = $stmt_active->fetch();
    if (!$active_sub) {
        set_flash_message('warning', 'This premium exam is locked. Please purchase corresponding package to continue.');
        header('Location: ' . BASE_URL . 'subscribe.php');
        exit;
    }
}

// Convert questions php array to JS JSON safe object
$questions_json = json_encode($questions);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CBT Examination Console - ExamDuniya</title>
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Feather Icons -->
    <link href="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #F1F5F9;
            color: #0F172A;
            overflow: hidden;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Top header */
        .cbt-header {
            background-color: #0F172A;
            color: #FFFFFF;
            border-bottom: 3px solid #2563EB;
            padding: 10px 20px;
            z-index: 1000;
        }

        /* Full layout splits */
        .cbt-container {
            display: flex;
            flex: 1;
            overflow: hidden;
            height: calc(100vh - 60px);
        }

        .question-panel {
            flex: 1;
            padding: 24px;
            overflow-y: auto;
            background-color: #FFFFFF;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .palette-panel {
            width: 320px;
            background-color: #F8FAFC;
            border-left: 1px solid #E2E8F0;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        /* Exam Option labels */
        .option-label {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            margin-bottom: 12px;
            background-color: #F8FAFC;
            border: 1px solid #E2E8F0;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .option-label:hover {
            background-color: #F1F5F9;
            border-color: #CBD5E1;
        }

        .option-input:checked + .option-label {
            background-color: #EFF6FF;
            border-color: #3B82F6;
            color: #1D4ED8;
            font-weight: 600;
        }

        .option-bullet {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: 2.5px solid #94A3B8;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 11px;
            margin-right: 15px;
            flex-shrink: 0;
            transition: all 0.2s;
        }

        .option-input:checked + .option-label .option-bullet {
            background-color: #3B82F6;
            border-color: #3B82F6;
            color: white;
        }

        /* Grid palette standard */
        .palette-btn {
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            border: 1px solid #CBD5E1;
            background-color: #FFFFFF;
            color: #475569;
            transition: all 0.1s ease;
        }

        .palette-btn.unanswered {
            background-color: #EF4444 !important; /* Red */
            color: #FFFFFF !important;
            border-color: #EF4444 !important;
        }

        .palette-btn.answered {
            background-color: #22C55E !important; /* Green */
            color: #FFFFFF !important;
            border-color: #22C55E !important;
        }

        .palette-btn.marked {
            background-color: #8B5CF6 !important; /* Purple */
            color: #FFFFFF !important;
            border-color: #8B5CF6 !important;
        }

        .palette-btn.active-q {
            border: 2px solid #0F172A !important;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.4);
        }

        /* Top sticky section bar */
        .section-tab {
            padding: 10px 20px;
            background-color: #E2E8F0;
            font-weight: 600;
            font-size: 13px;
            color: #475569;
            border-right: 1px solid #CBD5E1;
            cursor: pointer;
        }

        .section-tab.active {
            background-color: #FFFFFF;
            color: #2563EB;
            border-bottom: 2px solid #2563EB;
            font-weight: 700;
        }
    </style>
</head>
<body>

    <!-- CBT Console Top Header -->
    <header class="cbt-header d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center">
            <span class="badge bg-danger me-3 text-uppercase font-bold" style="font-size:11px; letter-spacing:0.5px;">Live Examination Room</span>
            <h5 class="m-0 text-white fw-bold font-sans" style="font-size:16px;"><?php echo s($test['title']); ?></h5>
        </div>
        
        <div class="d-flex align-items-center gap-3">
            <div class="d-flex align-items-center text-white font-mono bg-dark px-3 py-1.5 rounded" style="font-size: 15px;">
                <i class="feather-clock text-warning me-2 animate-pulse"></i>
                Time Left: <span id="timerClock" class="fw-bold ms-1 text-teal">00:00:00</span>
            </div>
            <button id="btnFullscreen" class="btn btn-outline-light btn-sm px-2.5 py-1" onclick="toggleFullScreen()"><i class="feather-maximize-2"></i></button>
        </div>
    </header>

    <!-- Navigation section topics tabs -->
    <div class="bg-light border-bottom d-flex align-items-center overflow-x-auto" style="height:44px;">
        <div class="section-tab active">General Awareness (GK)</div>
        <div class="section-tab text-muted">Quantitative Aptitude</div>
        <div class="section-tab text-muted">Logical Reasoning & Hindi</div>
    </div>

    <!-- Core Interactive split window block -->
    <div class="cbt-container">
        
        <!-- Questions view panels -->
        <div class="question-panel">
            <div id="loadingBox" class="text-center py-5 d-none">
                <div class="spinner-border text-primary" role="status"></div>
                <p class="text-muted mt-2">Loading question sheet...</p>
            </div>
            
            <div id="questionContainer">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <span class="badge bg-secondary font-sans" style="font-size: 11px;">Question <span id="currentQNum">1</span> of <span id="totalQs">10</span></span>
                    <span class="text-muted small">Marks: <span class="text-success fw-bold">+<?php echo s($test['positive_marks']); ?></span> | Negative: <span class="text-danger fw-bold">-<?php echo s($test['negative_marks']); ?></span></span>
                </div>
                
                <h5 id="questionText" class="fw-bold fs-5 text-dark mb-4 font-sans" style="line-height:1.6;">
                    -- Loaded Question Content --
                </h5>
                
                <!-- Options Container radios -->
                <div class="options-container">
                    <input type="radio" name="cbtOption" id="optA" value="A" class="option-input d-none">
                    <label for="optA" class="option-label">
                        <span class="option-bullet">A</span>
                        <span id="textOptA">Option parameter A text</span>
                    </label>

                    <input type="radio" name="cbtOption" id="optB" value="B" class="option-input d-none">
                    <label for="optB" class="option-label">
                        <span class="option-bullet">B</span>
                        <span id="textOptB">Option parameter B text</span>
                    </label>

                    <input type="radio" name="cbtOption" id="optC" value="C" class="option-input d-none">
                    <label for="optC" class="option-label">
                        <span class="option-bullet">C</span>
                        <span id="textOptC">Option parameter C text</span>
                    </label>

                    <input type="radio" name="cbtOption" id="optD" value="D" class="option-input d-none">
                    <label for="optD" class="option-label">
                        <span class="option-bullet">D</span>
                        <span id="textOptD">Option parameter D text</span>
                    </label>
                </div>
            </div>

            <!-- Question action bottom triggers -->
            <div class="border-top pt-4 mt-4 d-flex justify-content-between align-items-center">
                <div>
                    <button class="btn btn-outline-secondary me-2 py-2 px-3 fw-bold small text-uppercase" id="btnPrev" onclick="navigateQuestion(-1)"><i class="feather-chevron-left me-1"></i> Prev</button>
                    <button class="btn btn-outline-warning py-2 px-3 fw-bold small text-uppercase" id="btnMark" onclick="markForReview()"><i class="feather-tag me-1"></i> Mark for Review</button>
                </div>
                <div>
                    <button class="btn btn-outline-danger me-2 py-2 px-3 fw-bold small text-uppercase" id="btnClear" onclick="clearSelected()">Clear Response</button>
                    <button class="btn btn-primary py-2 px-4 fw-bold small text-uppercase border-0 shadow-sm" id="btnNext" onclick="saveAndNext()" style="background-color: var(--secondary-color);">Save & Next <i class="feather-chevron-right ms-1"></i></button>
                </div>
            </div>
        </div>

        <!-- Palette right panel -->
        <aside class="palette-panel">
            <!-- Sidebar Header user metadata details -->
            <div class="p-3 bg-white border-bottom shadow-sm">
                <div class="d-flex align-items-center">
                    <img src="<?php echo BASE_URL; ?><?php echo htmlspecialchars($_SESSION['user_avatar'] ?? 'assets/img/default-avatar.png'); ?>" alt="User avatar image" class="rounded-circle border me-2 shadow-sm" style="width: 44px; height: 44px; object-fit:cover;">
                    <div>
                        <div class="fw-bold small text-dark"><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'Candidate Demo'); ?></div>
                        <div class="text-muted" style="font-size: 10px;">Exam ID: ED-CBT-<?php echo rand(1005, 9920); ?></div>
                    </div>
                </div>
            </div>

            <!-- Scrollable palette triggers -->
            <div class="p-4 flex-grow-1">
                <h6 class="fw-bold text-dark font-sans small text-uppercase mb-3" style="letter-spacing:0.5px;">Choose Question Number</h6>
                <div class="d-flex flex-wrap gap-2" id="gridPalette">
                    <!-- JavaScript dynamically injects palette boxes -->
                </div>
            </div>

            <!-- Indicators legends info block -->
            <div class="p-3 bg-white border-top small font-sans">
                <div class="row g-2 text-dark mb-3">
                    <div class="col-6 d-flex align-items-center"><span class="badge bg-success rounded-0 me-2" style="width:12px; height:12px;">&nbsp;</span> Answered</div>
                    <div class="col-6 d-flex align-items-center"><span class="badge bg-danger rounded-0 me-2" style="width:12px; height:12px;">&nbsp;</span> Unanswered</div>
                    <div class="col-6 d-flex align-items-center"><span class="badge bg-purple rounded-0 me-2" style="width:12px; height:12px; background-color: #8B5CF6;">&nbsp;</span> Mark for Review</div>
                    <div class="col-6 d-flex align-items-center"><span class="badge rounded-0 border me-2" style="width:12px; height:12px; background-color:#FFFFFF;">&nbsp;</span> Not Visited</div>
                </div>

                <button class="btn btn-success w-100 py-2.5 fw-bold text-uppercase border-0 shadow-sm" id="btnSubmitTest" onclick="confirmStopTest()">
                    <i class="feather-check-square me-1"></i> Submit Examination
                </button>
            </div>
        </aside>
    </div>

    <!-- Hidden form to process selection payload and evaluate results -->
    <form id="submitForm" action="test-result.php" method="POST" class="d-none">
        <input type="hidden" name="test_id" value="<?php echo (int)$test_id; ?>">
        <input type="hidden" name="answers_payload" id="answers_payload">
        <input type="hidden" name="time_taken_seconds" id="time_taken_seconds">
    </form>

    <!-- Inline script handling entire CBT interactive UI logic -->
    <script>
        // Loaded Questions Object
        const questions = <?php echo $questions_json; ?>;
        const totalDurationMins = <?php echo (int)($test['duration_minutes'] ?? 60); ?>;
        
        let currentIdx = 0;
        let answers = {}; // Maps question ID to chosen option ('A', 'B', 'C', 'D')
        let markedForReview = {}; // Maps index to boolean indicating bookmark state
        let visitedStatus = {}; // Tracks indices that have been loaded
        
        // Timer tracking variables
        let totalSecs = totalDurationMins * 60;
        let elapsedSecs = 0;
        let timerInterval = null;

        // Start countdown timer
        function startTimer() {
            const timerContainer = document.getElementById('timerClock');
            timerInterval = setInterval(() => {
                if (totalSecs <= 0) {
                    clearInterval(timerInterval);
                    autoSubmitTest();
                    return;
                }
                
                totalSecs--;
                elapsedSecs++;
                
                const hrs = Math.floor(totalSecs / 3600);
                const mins = Math.floor((totalSecs % 3600) / 60);
                const secs = totalSecs % 60;
                
                timerContainer.textContent = 
                    String(hrs).padStart(2, '0') + ":" + 
                    String(mins).padStart(2, '0') + ":" + 
                    String(secs).padStart(2, '0');
            }, 1000);
        }

        // Initialize question buttons grid palette
        function renderPalette() {
            const container = document.getElementById('gridPalette');
            container.innerHTML = '';
            
            questions.forEach((q, idx) => {
                const btn = document.createElement('div');
                btn.className = 'palette-btn';
                btn.textContent = idx + 1;
                btn.id = 'palette-item-' + idx;
                
                // Colorize based on state
                updatePaletteItemStyle(btn, idx);
                
                btn.addEventListener('click', () => {
                    saveCurrentStateResponse();
                    currentIdx = idx;
                    loadQuestion(idx);
                });
                
                container.appendChild(btn);
            });
        }

        function updatePaletteItemStyle(btn, idx) {
            btn.className = 'palette-btn';
            
            if (idx === currentIdx) {
                btn.classList.add('active-q');
            }
            
            const qId = questions[idx].id;
            const chosen = answers[qId];
            
            if (markedForReview[idx]) {
                btn.classList.add('marked');
            } else if (chosen) {
                btn.classList.add('answered');
            } else if (visitedStatus[idx]) {
                btn.classList.add('unanswered');
            }
        }

        function refreshPaletteColors() {
            questions.forEach((q, idx) => {
                const btn = document.getElementById('palette-item-' + idx);
                if (btn) {
                    updatePaletteItemStyle(btn, idx);
                }
            });
        }

        // Load Question details onto console
        function loadQuestion(idx) {
            visitedStatus[idx] = true;
            
            document.getElementById('currentQNum').textContent = idx + 1;
            document.getElementById('totalQs').textContent = questions.length;
            
            const q = questions[idx];
            document.getElementById('questionText').textContent = q.question_text;
            document.getElementById('textOptA').textContent = q.option_a;
            document.getElementById('textOptB').textContent = q.option_b;
            document.getElementById('textOptC').textContent = q.option_c;
            document.getElementById('textOptD').textContent = q.option_d;
            
            // Clear check states
            document.querySelectorAll('.option-input').forEach(rad => rad.checked = false);
            
            // Reapply existing answer if any
            const chosen = answers[q.id];
            if (chosen) {
                const rad = document.getElementById('opt' + chosen);
                if (rad) rad.checked = true;
            }
            
            refreshPaletteColors();
        }

        // Keep responses cache updated in mapping object
        function saveCurrentStateResponse() {
            if (questions.length === 0) return;
            const currentQ = questions[currentIdx];
            
            const checkedRadio = document.querySelector('.option-input:checked');
            if (checkedRadio) {
                answers[currentQ.id] = checkedRadio.value;
            }
        }

        function clearSelected() {
            const currentQ = questions[currentIdx];
            delete answers[currentQ.id];
            
            document.querySelectorAll('.option-input').forEach(rad => rad.checked = false);
            refreshPaletteColors();
        }

        function markForReview() {
            saveCurrentStateResponse();
            markedForReview[currentIdx] = !markedForReview[currentIdx];
            navigateQuestion(1);
        }

        function saveAndNext() {
            saveCurrentStateResponse();
            // Free mark bookmark as false once confirmed answered
            markedForReview[currentIdx] = false;
            navigateQuestion(1);
        }

        function navigateQuestion(direction) {
            saveCurrentStateResponse();
            
            let nextIdx = currentIdx + direction;
            if (nextIdx >= 0 && nextIdx < questions.length) {
                currentIdx = nextIdx;
                loadQuestion(nextIdx);
            } else if (nextIdx === questions.length) {
                // If clicked next on final answer, highlight confirm box
                alert("You are at the final question! Verify your options using the right palette or click 'Submit Examination' below.");
            }
        }

        // Final Confirm Submission Trigger
        function confirmStopTest() {
            saveCurrentStateResponse();
            let count = Object.keys(answers).length;
            
            if (confirm("Are you sure you want to finalize and submit this mock test?\n\nTotal Attempted Questions: " + count + " / " + questions.length + "\n\nPress OK to obtain analysis reports immediately.")) {
                stopTestAndSubmit();
            }
        }

        function autoSubmitTest() {
            saveCurrentStateResponse();
            alert("⏰ TIMEOUT CHALLENGE! Examination console timer expired. Saving scorecards automatically...");
            stopTestAndSubmit();
        }

        function stopTestAndSubmit() {
            clearInterval(timerInterval);
            
            // Hydrate parameters in hidden input and push
            document.getElementById('answers_payload').value = JSON.stringify(answers);
            document.getElementById('time_taken_seconds').value = elapsedSecs;
            
            document.getElementById('submitForm').submit();
        }

        // Toggle Full screen presentation mode
        function toggleFullScreen() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(err => {
                    alert(`Error attempting to enable fullscreen mode: ${err.message}`);
                });
            } else {
                document.exitFullscreen();
            }
        }

        // Boot CBT Console
        window.onload = () => {
            visitedStatus[0] = true;
            renderPalette();
            loadQuestion(0);
            startTimer();
        };
    </script>
</body>
</html>
