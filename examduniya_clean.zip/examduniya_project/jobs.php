<?php
/**
 * ExamDuniya - Jobs Listings Page
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

$search = $_GET['search'] ?? '';
$org = $_GET['org'] ?? '';

// Build dynamic safe query
$query = "SELECT * FROM `jobs` WHERE `status` = 'Active'";
$params = [];

if (!empty($search)) {
    $query .= " AND (`title` LIKE :search OR `organization` LIKE :search OR `post_name` LIKE :search OR `qualification` LIKE :search)";
    $params[':search'] = '%' . $search . '%';
}

if (!empty($org)) {
    $query .= " AND `organization` = :org";
    $params[':org'] = $org;
}

$query .= " ORDER BY `created_at` DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$jobs = $stmt->fetchAll();

// Get unique organizations for filtering
$stmt_orgs = $pdo->query("SELECT DISTINCT `organization` FROM `jobs` WHERE `status` = 'Active'");
$orgs = $stmt_orgs->fetchAll();

render_header("Latest Government Jobs & Notification Alerts");
?>

<div class="row mb-4">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>index.php" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Latest Govt Jobs</li>
            </ol>
        </nav>
        <h2 class="fw-bold font-sans tracking-tight mb-2 text-dark">Latest Government Job Vacancies 2026</h2>
        <p class="text-muted">Explore active notification details, total post vacancies, age limitations, and application steps.</p>
    </div>
</div>

<!-- Filter Sidebar and Job List -->
<div class="row g-4 mb-5">
    <!-- Filters Column -->
    <div class="col-lg-3">
        <div class="card border-0 bg-white shadow-sm p-4 rounded-3 text-dark mb-4 sticky-top" style="top: 100px;">
            <h5 class="fw-bold mb-3 d-flex align-items-center" style="font-size:16px;">
                <i class="feather-filter text-primary me-2"></i> Filter Alerts
            </h5>
            
            <form action="" method="GET">
                <!-- Search term -->
                <div class="mb-3">
                    <label class="form-label small fw-bold">Keywords</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0"><i class="feather-search text-muted small"></i></span>
                        <input type="text" name="search" class="form-control form-control-sm border-0 bg-light" placeholder="Search..." value="<?php echo s($search); ?>">
                    </div>
                </div>
                
                <!-- Organization -->
                <div class="mb-4">
                    <label class="form-label small fw-bold">Organization Board</label>
                    <select name="org" class="form-select form-select-sm border-0 bg-light">
                        <option value="">All Organizations</option>
                        <?php foreach ($orgs as $o): ?>
                            <option value="<?php echo s($o['organization']); ?>" <?php echo $org === $o['organization'] ? 'selected' : ''; ?>>
                                <?php echo s($o['organization']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-sm border-0 py-2 fw-medium">Apply Filters</button>
                    <?php if (!empty($search) || !empty($org)): ?>
                        <a href="jobs.php" class="btn btn-light btn-sm py-2">Reset Filters</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Listings Column -->
    <div class="col-lg-9">
        <div class="row g-4">
            <?php if (empty($jobs)): ?>
                <div class="col-12 py-5 text-center">
                    <div class="card border-0 shadow-sm p-5 text-center rounded-3 bg-white">
                        <i class="feather-search display-4 text-muted d-block mb-3"></i>
                        <h5 class="fw-bold text-dark">No Matching Jobs Found</h5>
                        <p class="text-muted small">Try modifying your filter options or typing different keywords.</p>
                        <a href="jobs.php" class="btn btn-outline-primary btn-sm mt-2 px-4 rounded-pill">Reset All Filters</a>
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($jobs as $job): ?>
                    <div class="col-12">
                        <div class="card border-0 bg-white shadow-sm p-4 rounded-3 glass-card position-relative">
                            <div class="row align-items-center g-3">
                                <div class="col-md-9">
                                    <div class="d-flex flex-wrap gap-2 mb-2">
                                        <span class="badge badge-govt text-uppercase" style="font-size:10px;">
                                            <?php echo s($job['organization']); ?>
                                        </span>
                                        <span class="badge bg-light text-dark text-uppercase border" style="font-size:10px;">
                                            🎓 <?php echo s($job['qualification']); ?>
                                        </span>
                                        <?php if (!empty($job['is_trending']) && $job['is_trending'] == 1): ?>
                                            <span class="badge badge-trending" style="font-size:10px;">
                                                🔥 Hot Vacancy
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <h4 class="fw-bold mb-2 font-sans fs-5">
                                        <a href="job-detail.php?slug=<?php echo s($job['slug']); ?>" class="text-dark text-decoration-none hover-primary">
                                            <?php echo s($job['title']); ?>
                                        </a>
                                    </h4>
                                    
                                    <div class="row g-2 text-muted small mt-2">
                                        <div class="col-sm-4"><i class="feather-server me-1"></i> <strong>Total Posts:</strong> <?php echo number_format($job['total_vacancies']); ?></div>
                                        <div class="col-sm-4"><i class="feather-dollar-sign me-1"></i> <strong>Scale:</strong> <?php echo s($job['salary_scale'] ?? 'As per rule'); ?></div>
                                        <div class="col-sm-4"><i class="feather-calendar me-1"></i> <strong>Closing:</strong> <span class="text-danger font-bold"><?php echo date('d M, Y', strtotime($job['end_date'])); ?></span></div>
                                    </div>
                                </div>
                                <div class="col-md-3 text-md-end text-center pt-3 pt-md-0 border-top border-md-0">
                                    <a href="job-detail.php?slug=<?php echo s($job['slug']); ?>" class="btn btn-primary rounded px-4 py-2 border-0 w-100 mb-2 small fw-bold" style="background-color: var(--secondary-color);">
                                        View Job Alerts
                                    </a>
                                    <span class="text-muted small" style="font-size: 11px;"><i class="feather-eye me-1"></i> <?php echo number_format($job['views_count'] ?? 105); ?> readers</span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
render_footer();
?>
