<?php
/**
 * ExamDuniya - Mock Evaluation & Instant Analytics Result Board
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

// Retrieve values from POST payload
$test_id = $_POST['test_id'] ?? 1;
$answers_payload_str = $_POST['answers_payload'] ?? '{}';
$time_taken_seconds = (int)($_POST['time_taken_seconds'] ?? 480);

$answers_payload = json_decode($answers_payload_str, true);

// Fetch Mock test data parameters
$stmt_test = $pdo->prepare("SELECT * FROM `mock_tests` WHERE `id` = :id LIMIT 1");
$stmt_test->execute([':id' => (int)$test_id]);
$test = $stmt_test->fetch();

if (!$test) {
    set_flash_message('danger', 'Error evaluating result. Target examination session lost.');
    header('Location: ' . BASE_URL . 'mock-tests.php');
    exit;
}

// Fetch questions key sheet mapped to test
$stmt_qs = $pdo->prepare("SELECT * FROM `questions` WHERE `mock_test_id` = :id ORDER BY `id` ASC");
$stmt_qs->execute([':id' => (int)$test_id]);
$questions = $stmt_qs->fetchAll();

if (empty($questions)) {
    // Fallback seed question sets
    $stmt_qs_fallback = $pdo->query("SELECT * FROM `questions` LIMIT 10");
    $questions = $stmt_qs_fallback->fetchAll();
}

// Metric parameters variables
$total_questions = count($questions);
$attempted_questions = 0;
$correct_answers = 0;
$wrong_answers = 0;
$obtained_score = 0.00;

$positive_marks = (float)($test['positive_marks'] ?? 2.0);
$negative_marks = (float)($test['negative_marks'] ?? 0.5);

$question_analytics = []; // captures indices classifications

foreach ($questions as $q) {
    $qId = $q['id'];
    $correct_opt = strtoupper($q['correct_option']);
    $user_opt = isset($answers_payload[$qId]) ? strtoupper($answers_payload[$qId]) : '';
    
    $status = 'Unattempted';
    if (!empty($user_opt)) {
        $attempted_questions++;
        if ($user_opt === $correct_opt) {
            $correct_answers++;
            $obtained_score += $positive_marks;
            $status = 'Correct';
        } else {
            $wrong_answers++;
            $obtained_score -= $negative_marks;
            $status = 'Wrong';
        }
    }
    
    $question_analytics[] = [
        'question' => $q['question_text'],
        'option_a' => $q['option_a'],
        'option_b' => $q['option_b'],
        'option_c' => $q['option_c'],
        'option_d' => $q['option_d'],
        'correct' => $correct_opt,
        'user_choice' => $user_opt,
        'status' => $status,
        'explanation' => $q['explanation']
    ];
}

// Ensure score doesn't fall below zero
if ($obtained_score < 0) {
    $obtained_score = 0.00;
}

// Accuracy Formula
$accuracy = ($attempted_questions > 0) ? round(($correct_answers / $attempted_questions) * 100, 2) : 0;

// Render evaluation reports
render_header("Exam Report Card: " . $test['title']);
?>

<div class="row mb-4 text-dark">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>index.php" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>mock-tests.php" class="text-decoration-none">Mock Tests</a></li>
                <li class="breadcrumb-item active" aria-current="page">Result Analytics</li>
            </ol>
        </nav>
        <span class="badge bg-success bg-opacity-10 text-success px-3 py-1.5 mb-2 fw-bold" style="font-size:11px;">🏆 EVALUATION COMPLETE</span>
        <h2 class="fw-bold font-sans tracking-tight text-dark mb-1">Your Detailed CBT Metric Report Card</h2>
        <p class="text-muted small">Analytics updated live. Check correct templates and topic analysis sheets below.</p>
    </div>
</div>

<div class="row g-4 mb-5 text-dark">
    <!-- Big Performance Meter Chart -->
    <div class="col-lg-5">
        <div class="card border-0 bg-white shadow-sm p-4 text-center rounded-3 h-100 d-flex flex-column justify-content-between">
            <div>
                <h5 class="fw-bold text-dark font-sans text-start mb-3" style="font-size: 16px;">Overall Score Card Meter</h5>
                
                <!-- Circular Dial Metric -->
                <div class="my-4 d-inline-block position-relative">
                    <div class="rounded-circle border border-5 border-primary d-flex flex-column align-items-center justify-content-center" style="width: 180px; height: 180px; border-color: var(--secondary-color) !important; box-shadow: 0 4px 20px rgba(37,99,235,0.15)">
                        <span class="display-5 fw-extrabold text-dark"><?php echo $obtained_score; ?></span>
                        <span class="text-muted small font-sans fw-bold">Out of <?php echo ($total_questions * $positive_marks); ?></span>
                    </div>
                </div>
            </div>
            
            <div class="bg-light p-3 rounded-3 text-start">
                <div class="d-flex justify-content-between mb-2 small">
                    <span class="text-muted"><i class="feather-percent me-1 text-primary"></i> Accuracy Metric</span>
                    <strong class="text-dark"><?php echo $accuracy; ?> %</strong>
                </div>
                <div class="d-flex justify-content-between small">
                    <span class="text-muted"><i class="feather-clock me-1 text-primary"></i> Time Taken</span>
                    <strong class="text-dark"><?php echo floor($time_taken_seconds / 60); ?>m <?php echo ($time_taken_seconds % 60); ?>s</strong>
                </div>
            </div>
        </div>
    </div>

    <!-- Small Counters Cards Grid -->
    <div class="col-lg-7">
        <div class="row g-3 h-100">
            <div class="col-sm-6">
                <div class="card border-0 shadow-sm p-4 rounded-3 bg-white h-100 d-flex flex-row align-items-center justify-content-between">
                    <div>
                        <small class="text-muted-small text-uppercase fw-bold text-muted" style="font-size:10px;">Total Questions</small>
                        <h3 class="fw-bold text-dark mb-0 mt-1"><?php echo $total_questions; ?></h3>
                    </div>
                    <div class="p-3 bg-light rounded-circle text-muted"><i class="feather-help-circle fs-4"></i></div>
                </div>
            </div>
            
            <div class="col-sm-6">
                <div class="card border-0 shadow-sm p-4 rounded-3 h-100 bg-white d-flex flex-row align-items-center justify-content-between">
                    <div>
                        <small class="text-muted-small text-uppercase fw-bold text-success" style="font-size:10px;">Correct Selections</small>
                        <h3 class="fw-bold text-success mb-0 mt-1"><?php echo $correct_answers; ?></h3>
                    </div>
                    <div class="p-3 bg-success bg-opacity-10 rounded-circle text-success"><i class="feather-check fs-4"></i></div>
                </div>
            </div>

            <div class="col-sm-6">
                <div class="card border-0 shadow-sm p-4 rounded-3 h-100 bg-white d-flex flex-row align-items-center justify-content-between">
                    <div>
                        <small class="text-muted-small text-uppercase fw-bold text-danger" style="font-size:10px;">Wrong Responses</small>
                        <h3 class="fw-bold text-danger mb-0 mt-1"><?php echo $wrong_answers; ?></h3>
                    </div>
                    <div class="p-3 bg-danger bg-opacity-10 rounded-circle text-danger"><i class="feather-x fs-4"></i></div>
                </div>
            </div>

            <div class="col-sm-6">
                <div class="card border-0 shadow-sm p-4 rounded-3 h-100 bg-white d-flex flex-row align-items-center justify-content-between">
                    <div>
                        <small class="text-muted-small text-uppercase fw-bold text-muted" style="font-size:10px;">Skipped / Blank</small>
                        <h3 class="fw-bold text-dark mb-0 mt-1"><?php echo ($total_questions - $attempted_questions); ?></h3>
                    </div>
                    <div class="p-3 bg-light rounded-circle text-muted"><i class="feather-minus-circle fs-4"></i></div>
                </div>
            </div>
            
            <!-- Dynamic percentile mock calculation board -->
            <div class="col-12">
                <div class="card border-0 bg-primary bg-opacity-10 shadow-sm p-4 rounded-3 text-dark d-flex align-items-center justify-content-between flex-row">
                    <div>
                        <h6 class="fw-bold font-sans text-primary mb-1">CBT Rank Percentile Estimate</h6>
                        <p class="small text-muted mb-0">Based on historical mock attempt sets, you have outscored <strong><?php echo max(50, min(99, round(50 + ($accuracy * 0.49)))); ?>%</strong> of active state aspirants!</p>
                    </div>
                    <span class="badge text-white px-3 py-2 bg-primary fs-6" style="background-color: var(--secondary-color) !important;">Top <?php echo max(1, min(50, round(51 - ($accuracy * 0.5)))); ?>%</span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Detailed Solutions Accordion -->
<div class="row mb-5 text-dark">
    <div class="col-12">
        <h4 class="fw-bold font-sans mb-3"><i class="feather-list text-primary me-2"></i> Question Key & Explanatory Solutions</h4>
        
        <?php foreach ($question_analytics as $idx => $qa): ?>
            <?php 
                $alert_class = 'border-secondary';
                $badge_class = 'bg-secondary text-white';
                if ($qa['status'] === 'Correct') {
                    $alert_class = 'border-success border-2 bg-success bg-opacity-5';
                    $badge_class = 'bg-success text-white';
                } else if ($qa['status'] === 'Wrong') {
                    $alert_class = 'border-danger border-2 bg-danger bg-opacity-5';
                    $badge_class = 'bg-danger text-white';
                }
            ?>
            <div class="card p-4 rounded-3 border <?php echo $alert_class; ?> mb-3 shadow-sm">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="badge rounded px-3 py-1 <?php echo $badge_class; ?>" style="font-size: 11px;">
                        Que. <?php echo ($idx + 1); ?> • <?php echo s($qa['status']); ?>
                    </span>
                    <span class="text-muted small">Positive Marks: <?php echo $positive_marks; ?> MCQ</span>
                </div>
                
                <h5 class="fw-bold text-dark font-sans mb-3 fs-6" style="line-height:1.6;"><?php echo s($qa['question']); ?></h5>
                
                <!-- Options Grid -->
                <div class="row g-2 mb-3">
                    <div class="col-md-6">
                        <div class="p-2.5 rounded border text-sm <?php echo ($qa['correct'] === 'A') ? 'bg-success bg-opacity-15 border-success text-success fw-bold' : 'bg-light'; ?>">
                            A. <?php echo s($qa['option_a']); ?> <?php echo ($qa['user_choice'] === 'A') ? '👤 (Chosen)' : ''; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-2.5 rounded border text-sm <?php echo ($qa['correct'] === 'B') ? 'bg-success bg-opacity-15 border-success text-success fw-bold' : 'bg-light'; ?>">
                            B. <?php echo s($qa['option_b']); ?> <?php echo ($qa['user_choice'] === 'B') ? '👤 (Chosen)' : ''; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-2.5 rounded border text-sm <?php echo ($qa['correct'] === 'C') ? 'bg-success bg-opacity-15 border-success text-success fw-bold' : 'bg-light'; ?>">
                            C. <?php echo s($qa['option_c']); ?> <?php echo ($qa['user_choice'] === 'C') ? '👤 (Chosen)' : ''; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="p-2.5 rounded border text-sm <?php echo ($qa['correct'] === 'D') ? 'bg-success bg-opacity-15 border-success text-success fw-bold' : 'bg-light'; ?>">
                            D. <?php echo s($qa['option_d']); ?> <?php echo ($qa['user_choice'] === 'D') ? '👤 (Chosen)' : ''; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Explanation panel -->
                <div class="p-3 bg-light rounded text-muted" style="font-size:13px; line-height:1.6; border-left: 3px solid var(--secondary-color);">
                    <strong>💡 Solution Key Explanation:</strong> <?php echo s($qa['explanation'] ?? 'Detailed explanation not provided for demo.'); ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="row mb-4">
    <div class="col-12 text-center">
        <a href="<?php echo BASE_URL; ?>mock-tests.php" class="btn btn-outline-dark px-4 py-2 me-2 rounded font-sans small fw-bold">Explore More Mock Tests</a>
        <a href="<?php echo BASE_URL; ?>dashboard.php" class="btn btn-primary px-4 py-2 border-0 rounded font-sans small fw-bold" style="background-color: var(--secondary-color)">Return to Dashboard</a>
    </div>
</div>

<?php
render_footer();
?>
