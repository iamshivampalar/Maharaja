<?php
/**
 * ExamDuniya - Subscription Packages / Payment Gateways Redirection
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

// Enforce login
check_logged_in();

$selected_code = $_GET['pack'] ?? 'ALL_EXAMS';

// Fetch designated subscription card details
$stmt = $pdo->prepare("SELECT * FROM `subscriptions` WHERE `code` = :code LIMIT 1");
$stmt->execute([':code' => $selected_code]);
$pack = $stmt->fetch();

if (!$pack) {
    // Failover fallback details
    $pack = [
        'id' => 5, 'name' => 'All Exams Unlimited Combo', 'code' => 'ALL_EXAMS', 'price' => 499.00,
        'description' => 'Unlocks absolutely all mock test templates on ExamDuniya for a complete year.', 'duration_days' => 365
    ];
}

render_header("Subscribe to ExamDuniya Pack");
?>

<div class="row mb-4 text-dark">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>index.php" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>mock-tests.php" class="text-decoration-none">Mock Tests</a></li>
                <li class="breadcrumb-item active" aria-current="page">Invoice Checkout</li>
            </ol>
        </nav>
        <h2 class="fw-bold font-sans">Payment Checkout Form</h2>
        <p class="text-muted">Finalize your invoicing configurations and securely execute payment protocols.</p>
    </div>
</div>

<div class="row g-4 mb-5 text-dark">
    <!-- Invoice details card breakdown -->
    <div class="col-lg-6">
        <div class="card p-4 bg-white border border-slate-100 shadow-sm rounded-4 h-100 d-flex flex-column justify-content-between">
            <div>
                <span class="badge badge-govt py-1 px-3 mb-2 rounded-pill">🔒 SECURE INVOICE BILLING</span>
                <h4 class="fw-bold text-dark font-sans mb-1"><?php echo s($pack['name']); ?></h4>
                <div class="text-muted small mb-3">Service Code: <?php echo s($pack['code']); ?></div>
                
                <p class="small text-muted mb-4"><?php echo s($pack['description']); ?></p>
                <div class="small text-muted border-bottom pb-2 mb-3"><i class="feather-clock text-muted me-1"></i> Practice Center Active Duration: <strong><?php echo s($pack['duration_days']); ?> Days Valid</strong></div>
            </div>
            
            <div class="bg-light p-4 rounded-3 border">
                <div class="d-flex justify-content-between mb-2 small text-muted">
                    <span>Base Pack Cost</span>
                    <span>₹<?php echo number_format($pack['price'], 2); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2 small text-muted">
                    <span>CGST + SGST (18%)</span>
                    <span>₹<?php echo number_format($pack['price'] * 0.18, 2); ?></span>
                </div>
                <hr class="my-2 text-slate-300">
                <div class="d-flex justify-content-between fw-bold text-dark fs-5">
                    <span>Total Invoiced Cost</span>
                    <span>₹<?php echo number_format($pack['price'] * 1.18, 2); ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Payment Gateways Form simulation (PayU and Credit card options inside) -->
    <div class="col-lg-6">
        <div class="card p-4 bg-white border-0 shadow-lg rounded-4 h-100">
            <h5 class="fw-bold text-dark font-sans mb-3"><i class="feather-credit-card text-primary me-2"></i> Execute Gateway Checkout</h5>
            <p class="small text-muted mb-4">Complete payment parameters via simulated secure checkout environment mimicking active cPanel PayU webhook actions.</p>
            
            <form action="payu-checkout.php" method="POST">
                <input type="hidden" name="subscription_id" value="<?php echo (int)$pack['id']; ?>">
                <input type="hidden" name="total_amount" value="<?php echo ($pack['price'] * 1.18); ?>">
                
                <div class="mb-3">
                    <label class="form-label small fw-bold text-secondary">Aspirant Name (Billing name)</label>
                    <input type="text" class="form-control py-2.5 bg-light border-0 text-dark small" value="<?php echo htmlspecialchars($_SESSION['user_name']); ?>" readonly>
                </div>
                
                <div class="mb-3">
                    <label class="form-label small fw-bold text-secondary">Direct Email (Receipt Delivery)</label>
                    <input type="email" class="form-control py-2.5 bg-light border-0 text-dark small" value="<?php echo htmlspecialchars($_SESSION['user_email']); ?>" readonly>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-bold text-secondary">Choose Local Payment Mode</label>
                    <div class="form-check p-3 bg-light rounded border border-primary border-opacity-20 mb-2">
                        <input class="form-check-input ms-1" type="radio" name="payment_mode" id="payu_gateway" value="PayU" checked>
                        <label class="form-check-label ms-2 fw-medium text-dark text-sm" for="payu_gateway">
                            <span class="fw-bold">PayU Biz Gateway</span> (UPI, Cards, NetBanking, Wallet)
                        </label>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100 py-3 border-0 fw-bold rounded font-sans text-uppercase shadow-sm" style="background-color: var(--secondary-color);">
                    Proceed to Merchant Site <i class="feather-external-link ms-1"></i>
                </button>
            </form>
        </div>
    </div>
</div>

<?php
render_footer();
?>
