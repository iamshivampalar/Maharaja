<?php
/**
 * ExamDuniya - PayU Merchant Simulation Interstitial Script
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

check_logged_in();

$sub_id = (int)($_POST['subscription_id'] ?? 1);
$amount = (float)($_POST['total_amount'] ?? 199.00);
$txn_id = 'TXN_PAYU_' . rand(10049281, 99482910);

// Set payment logs placeholder
$pdo->execute("INSERT INTO `payments` (`user_id`, `subscription_id`, `txn_id`, `amount`, `status`) VALUES (" . (int)$_SESSION['user_id'] . ", $sub_id, '$txn_id', $amount, 'Pending')");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Redirecting to PayU Merchant Portal...</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Feather Icons -->
    <link href="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.css" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #0F172A; color: #FFFFFF; }
        .merchant-box { max-width: 450px; background-color: #1E293B; border-radius: 12px; }
    </style>
</head>
<body class="d-flex flex-column align-items-center justify-content-center min-vh-100 p-3">

    <div class="merchant-box text-center p-5 shadow-lg border border-slate-700">
        <div class="spinner-grow text-warning mb-4" style="width: 3rem; height: 3rem;" role="status"></div>
        <h4 class="fw-bold mb-2">Connecting PayU Biz Hub</h4>
        <p class="text-white-50 small mb-4">Please do not refresh nor navigate backward. We are establishing secure merchant handshakes for Invoice TXN: <strong><?php echo $txn_id; ?></strong>.</p>
        
        <div class="bg-dark p-3.5 rounded-3 mb-4 text-start border border-secondary">
            <div class="d-flex justify-content-between small text-muted"><span class="small font-sans">Payment Amount:</span> <strong class="text-white">₹<?php echo number_format($amount, 2); ?></strong></div>
            <div class="d-flex justify-content-between small text-muted"><span class="small font-sans">Merchant License:</span> <span class="text-success fw-bold small">examduniya.in</span></div>
        </div>
        
        <form action="payu-response.php" method="POST" class="d-grid gap-2">
            <input type="hidden" name="txn_id" value="<?php echo $txn_id; ?>">
            <input type="hidden" name="subscription_id" value="<?php echo $sub_id; ?>">
            <input type="hidden" name="amount" value="<?php echo $amount; ?>">
            
            <button type="submit" name="payu_status" value="Success" class="btn btn-success py-2.5 fw-bold border-0 text-sm shadow-sm"><i class="feather-check-circle me-1"></i> SIMULATE PAYMENT SUCCESS</button>
            <button type="submit" name="payu_status" value="Failed" class="btn btn-outline-danger py-2 col-12 text-sm"><i class="feather-x-circle me-1"></i> Simulate Payment Fail</button>
        </form>
    </div>

</body>
</html>
