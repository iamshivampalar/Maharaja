<?php
/**
 * ExamDuniya - Logout Handler
 */

require_once 'config/config.php';

$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

// Redirect back to login with success alert
session_start();
set_flash_message('success', 'Logged out successfully! Come back soon to practice.');
header('Location: ' . BASE_URL . 'login.php');
exit;
