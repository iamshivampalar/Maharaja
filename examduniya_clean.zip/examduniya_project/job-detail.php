<?php
/**
 * ExamDuniya - Job Detail Page
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

$slug = $_GET['slug'] ?? '';

// Fetch Job
$stmt = $pdo->prepare("SELECT * FROM `jobs` WHERE `slug` = :slug LIMIT 1");
$stmt->execute([':slug' => $slug]);
$job = $stmt->fetch();

if (!$job) {
    set_flash_message('danger', 'Requested job notification does not exist or has been removed.');
    header('Location: ' . BASE_URL . 'jobs.php');
    exit;
}

// Increment views (Safe simulation)
$pdo->execute("UPDATE `jobs` SET `views_count` = `views_count` + 1 WHERE `id` = " . (int)$job['id']);

render_header($job['title']);
?>

<div class="row mb-3">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>index.php" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo BASE_URL; ?>jobs.php" class="text-decoration-none">Latest Jobs</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo s($job['organization']); ?> Alert</li>
            </ol>
        </nav>
    </div>
</div>

<div class="row g-4 mb-5">
    <!-- Main Detail Col -->
    <div class="col-lg-8">
        <div class="card border-0 bg-white p-4 p-md-5 rounded-4 shadow-sm mb-4">
            
            <div class="d-flex flex-wrap gap-2 mb-3">
                <span class="badge badge-govt py-2 px-3 rounded shadow-sm text-uppercase" style="font-size:11px;">
                    🎯 <?php echo s($job['organization']); ?> Official Post
                </span>
                <span class="badge bg-light text-dark py-2 px-3 border rounded" style="font-size:11px;">
                    🎓 Eligibility: <?php echo s($job['qualification']); ?>
                </span>
            </div>
            
            <h1 class="fw-extrabold text-dark font-sans fs-2 mb-3 tracking-tight" style="line-height:1.25;">
                <?php echo s($job['title']); ?>
            </h1>
            
            <p class="text-muted small mb-4">
                <i class="feather-clock me-1"></i> Notification Published: <?php echo date('d M, Y', strtotime($job['start_date'] ?? '2026-06-01')); ?> 
                | <i class="feather-eye me-1 ms-2"></i> <?php echo number_format($job['views_count'] ?? 140); ?> active readers
            </p>
            
            <!-- Quick Info Grid -->
            <div class="bg-light p-4 rounded-3 border mb-4">
                <h5 class="fw-bold mb-3 text-secondary font-sans small text-uppercase" style="letter-spacing:1px; color: var(--secondary-color) !important;">
                    <i class="feather-info me-1"></i> Highlights Overview
                </h5>
                <div class="row g-3 text-dark">
                    <div class="col-sm-6 text-sm">
                        <strong>Organization Board:</strong> <?php echo s($job['organization']); ?>
                    </div>
                    <div class="col-sm-6 text-sm">
                        <strong>Role / Post Name:</strong> <?php echo s($job['post_name']); ?>
                    </div>
                    <div class="col-sm-6 text-sm">
                        <strong>Total Posts Available:</strong> <span class="badge bg-success bg-opacity-10 text-success fw-bold px-2 rounded"><?php echo number_format($job['total_vacancies']); ?> Positions</span>
                    </div>
                    <div class="col-sm-6 text-sm">
                        <strong>Remuneration Scale:</strong> <?php echo s($job['salary_scale'] ?? 'As per notification provisions'); ?>
                    </div>
                    <div class="col-sm-6 text-sm">
                        <strong>Age Band Limits:</strong> <?php echo s($job['age_limit'] ?? 'Min 18 Years'); ?>
                    </div>
                    <div class="col-sm-6 text-sm">
                        <strong>Closing Date:</strong> <strong class="text-danger"><?php echo date('d M, Y', strtotime($job['end_date'])); ?></strong>
                    </div>
                </div>
            </div>

            <!-- Mandatory Disclaimer Alert Box -->
            <div class="alert alert-warning border shadow-sm p-4 mb-4 rounded-3 d-flex align-items-start">
                <i class="feather-alert-triangle fs-4 text-warning me-3 mt-1"></i>
                <div class="small">
                    <strong class="text-dark d-block mb-1">Affiliation Disclaimer Declaration</strong>
                    <?php echo htmlspecialchars(DISCLAIMER_TEXT); ?>
                </div>
            </div>

            <!-- Detailed Description -->
            <h5 class="fw-bold text-dark font-sans mb-3 pb-2 border-bottom">Post Vacancy Details</h5>
            <div class="text-dark fs-6" style="line-height:1.75; text-align: justify;">
                <?php echo nl2br(s($job['description'])); ?>
                <p class="mt-4">Please download the official government notification PDF from the official board website. Keep ready scanned copies of educational certifications, photo identification parameters, and thumb impression models as defined strictly inside of statutory guidelines.</p>
            </div>

            <!-- Application Fees Table -->
            <h5 class="fw-bold text-dark font-sans mt-4 mb-3 pb-2 border-bottom">Application Tariffs & Exam Timings</h5>
            <div class="table-responsive mb-4">
                <table class="table table-bordered text-dark align-middle">
                    <tr class="bg-light">
                        <th style="width: 40%;">Tariff parameters</th>
                        <td><?php echo s($job['application_fee'] ?? 'Refer to official file'); ?></td>
                    </tr>
                    <tr>
                        <th>CBT Exam Schedules</th>
                        <td><span class="badge bg-dark py-2 px-3"><?php echo s($job['exam_date'] ?? 'To be notified'); ?></span></td>
                    </tr>
                </table>
            </div>

            <!-- Critical Call to Action buttons -->
            <div class="d-flex flex-wrap gap-2 pt-3">
                <a href="<?php echo s($job['official_notification_url']); ?>" target="_blank" class="btn btn-outline-danger btn-lg px-4 fs-6 rounded shadow-sm">
                    <i class="feather-file-text me-2"></i> Download Official PDF
                </a>
                <a href="<?php echo s($job['apply_online_url'] ?? '#'); ?>" target="_blank" class="btn btn-secondary btn-lg px-4 fs-6 rounded shadow-sm border-0" style="background-color: var(--secondary-color);">
                    <i class="feather-external-link me-2"></i> Apply Online Now <i class="feather-arrow-right ms-1"></i>
                </a>
                <a href="<?php echo s($job['official_website_url']); ?>" target="_blank" class="btn btn-outline-dark btn-lg px-4 fs-6 rounded shadow-sm">
                    <i class="feather-globe me-2"></i> Institutional Portal
                </a>
            </div>
            
        </div>
    </div>

    <!-- Sidebar Col -->
    <div class="col-lg-4">
        <!-- Mock test Promotion Widget -->
        <div class="card p-4 border border-primary border-opacity-20 shadow-sm rounded-4 text-center bg-white mb-4 d-flex flex-column align-items-center">
            <div class="p-3 bg-primary bg-opacity-10 text-primary rounded-circle mb-3">
                <i class="feather-award display-6"></i>
            </div>
            <h5 class="fw-bold text-dark font-sans mb-2">Simulate Custom Test Matches</h5>
            <p class="small text-muted mb-4">Prepare for UP Police, SSC exams with realistic web-based timer and answer scorecards designed to identify weak sections.</p>
            <a href="<?php echo BASE_URL; ?>mock-tests.php" class="btn btn-primary w-100 rounded border-0" style="background-color: var(--secondary-color);">
                Launch Mock Centers <i class="feather-chevron-right ms-1"></i>
            </a>
        </div>
        
        <!-- Social join share widgets -->
        <div class="card p-4 border-0 shadow-sm rounded-4 text-white text-center d-flex flex-column align-items-center" style="background-color: #229ED9;">
            <i class="feather-send fs-1 text-white mb-2"></i>
            <h5 class="fw-bold text-white mb-1">Telegram Sync Desk</h5>
            <p class="small text-white-50 mb-3">Get on-the-go notifications regarding merit ranks and selection cutoffs direct to your mobile messaging app.</p>
            <a href="https://t.me/examduniya_alerts" target="_blank" class="btn btn-white text-primary btn-sm px-4 bg-white border-0 fw-bold rounded-pill">
                Join Alerts Group
            </a>
        </div>
    </div>
</div>

<?php
render_footer();
?>
