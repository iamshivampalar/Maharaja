<?php
/**
 * ExamDuniya - Legal Disclaimer
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

render_header("Official Disclaimer & Non-Affiliation Clause");
?>

<div class="row mb-4 text-dark">
    <div class="col-12">
        <h2 class="fw-bold font-sans text-dark tracking-tight mb-2"><i class="feather-alert-triangle text-warning me-2"></i>Official Disclaimer Policy</h2>
        <p class="text-muted">Mandatory statement of non-affiliation with any official government institutions or agencies.</p>
    </div>
</div>

<div class="row text-dark mb-5">
    <div class="col-12">
        <div class="card p-4 p-md-5 border-0 bg-white shadow-sm rounded-4">
            <h5 class="fw-bold text-danger mb-4">1. Non-Affiliation Declaration</h5>
            <p class="fs-6 text-muted-small leading-relaxed" style="line-height:1.75; text-align: justify;">
                <strong>ExamDuniya (examduniya.in)</strong> is a completely independent private educational resources notification and mock-test practice website. We are <strong>NOT</strong> affiliated, associated, authorized, endorsed by, or in any way officially connected with any central, state, or municipal government organization, board, recruiter, or commission of India (such as SSC, UPSC, RRB, UPPRPB, state police boards, or any banking institutes). 
            </p>
            
            <h5 class="fw-bold text-dark mt-4 mb-3">2. Accuracy and Verification of Information</h5>
            <p class="fs-6 text-muted-small leading-relaxed" style="line-height:1.75; text-align: justify;">
                While supreme effort is put in to compile notification releases, vacancy structures, and dates accurately from authorized news channels, official boards, and government release bulletins, <strong>ExamDuniya is not responsible for any typographical mistakes, omissions, or obsolete links.</strong> All vacancy data provided here should be used solely for initial study references. Users, candidates, and students are strictly directed and obligated to verify vacancy features, qualifying standards, age requirements, and application fees directly from the respective institutional official websites.
            </p>
            
            <h5 class="fw-bold text-dark mt-4 mb-3">3. External Links Disclaimer</h5>
            <p class="fs-6 text-muted-small leading-relaxed" style="line-height:1.75; text-align: justify;">
                This portal hosts outbound hyperlinks pointing directly to recruitment board portals (such as official application urls, circular notification pdfs, and results boards). These links are owned and managed by fourth-party government institutions. ExamDuniya is not responsible for the privacy regulations, functionality, availability, or contents published on those third-party nodes. Clicking these links is done at the user's custom choice and discretion.
            </p>
            
            <div class="alert alert-warning border-0 p-4 mt-4 bg-warning bg-opacity-10 text-dark small rounded-3">
                <strong>Important Notice:</strong> If you identify any outdated link, typographical error, or incorrect qualification tag, please notify us immediately at <strong>contact@examduniya.in</strong>. We prioritize corrective adjustments within 24-48 working hours.
            </div>
        </div>
    </div>
</div>

<?php
render_footer();
?>
