<?php
/**
 * ExamDuniya - Privacy Policy
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

render_header("Privacy Regulations");
?>

<div class="row mb-4 text-dark">
    <div class="col-12">
        <h2 class="fw-bold font-sans text-dark tracking-tight mb-2"><i class="feather-shield text-success me-2"></i>Privacy Regulations & Cookie Guidelines</h2>
        <p class="text-muted">Understand how ExamDuniya captures, stores, and protects student information securely.</p>
    </div>
</div>

<div class="row text-dark mb-5">
    <div class="col-12">
        <div class="card p-4 p-md-5 border-0 bg-white shadow-sm rounded-4">
            <h5 class="fw-bold text-dark mb-3">1. Information We Collect</h5>
            <p class="small text-muted mb-3" style="line-height:1.75;">
                We values candidate data privacy. When registering on examduniya.in, we capture essential parameters such as your name, contact email address, mobile number, and password keys (hashed securely using industry-standard BCRYPT algorithms).
            </p>
            
            <h5 class="fw-bold text-dark mt-4 mb-3">2. Mock Attempt Logging</h5>
            <p class="small text-muted mb-3" style="line-height:1.75;">
                To compile precise student performance charts, leaderboard positions, and section accuracy percentages, we record and log student selected option patterns, time taken counters, and resulting scores. This criteria history is visible strictly to the authorized account user and is never sold to third-party institutions.
            </p>
            
            <h5 class="fw-bold text-dark mt-4 mb-3">3. Cookies and Session Tokens</h5>
            <p class="small text-muted mb-3" style="line-height:1.75;">
                This platform implements standard state cookies and session tokens necessary to keep you securely signed in to the online Mock Exam Console, support shopping-cart preferences, and mitigate cross-site request forgery attacks (CSRF).
            </p>
            
            <h5 class="fw-bold text-dark mt-4 mb-3">4. Secured Payments Handshaking</h5>
            <p class="small text-muted mb-3" style="line-height:1.75;">
                All payment transactions are completed offsite directly using PayU Biz Merchant gateway parameters. We never capture nor save financial credit card keys or banking pin details in our MySQL tables.
            </p>
        </div>
    </div>
</div>

<?php
render_footer();
?>
