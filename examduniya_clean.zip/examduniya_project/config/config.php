<?php
/**
 * ExamDuniya - Project Configuration File
 * Designed for cPanel Shared Hosting & Standard Apache servers.
 * Hand-tailored securely.
 */

// Start session if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Host detection and Base URL definition
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
define('BASE_URL', $protocol . $host . '/');

// Absolute Base Path
define('ROOT_PATH', dirname(__DIR__) . '/');

// Security: Generate a CSRF token if one does not exist
if (empty($_SESSION['csrf_token'])) {
    if (function_exists('random_bytes')) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } else {
        $_SESSION['csrf_token'] = md5(uniqid(rand(), true));
    }
}

// Default Site Information Settings
define('SITE_NAME', 'ExamDuniya');
define('SITE_TAGLINE', "India's Smartest Government Exam Notification & Mock Test Platform");
define('DISCLAIMER_TEXT', "This website is an independent educational information platform and is not affiliated with any government organization. Users should verify information through official government websites.");

// Standard Time Zone
date_default_timezone_set('Asia/Kolkata');

// Simple Session Flash Message Helpers
function set_flash_message($type, $msg) {
    $_SESSION['flash_message'] = [
        'type' => $type, // 'danger', 'success', 'warning', 'info'
        'message' => $msg
    ];
}

function display_flash_message() {
    if (!empty($_SESSION['flash_message'])) {
        $flash = $_SESSION['flash_message'];
        unset($_SESSION['flash_message']);
        
        $icon = ($flash['type'] === 'success') ? 'check-circle' : 'alert-circle';
        echo '<div class="alert alert-' . htmlspecialchars($flash['type']) . ' alert-dismissible fade show border-0 shadow-sm d-flex align-items-center" role="alert">
                <i class="feather-' . $icon . ' me-2 fs-5"></i>
                <div>' . htmlspecialchars($flash['message']) . '</div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
    }
}

// XSS Sanitizer Helper
function s($data) {
    return htmlspecialchars($data ?? '', ENT_QUOTES, 'UTF-8');
}

// Verify User Role Action Helper
function check_logged_in() {
    if (empty($_SESSION['user_id'])) {
        set_flash_message('warning', 'Please login to access this page.');
        header('Location: ' . BASE_URL . 'login.php');
        exit;
    }
}

function check_role($allowed_roles) {
    check_logged_in();
    $role = $_SESSION['user_role'] ?? 'User';
    if (!in_array($role, $allowed_roles)) {
        set_flash_message('danger', 'Unauthorized access! You do not have permissions for this page.');
        header('Location: ' . BASE_URL . 'index.php');
        exit;
    }
}
