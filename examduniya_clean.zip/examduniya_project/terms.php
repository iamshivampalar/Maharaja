<?php
/**
 * ExamDuniya - Terms of Service
 */

require_once 'config/db.php';
require_once 'app/Helpers/functions.php';

render_header("Terms of Service");
?>

<div class="row mb-4 text-dark">
    <div class="col-12">
        <h2 class="fw-bold font-sans text-dark tracking-tight mb-2"><i class="feather-file-text text-primary me-2"></i>Terms of Service Conditions</h2>
        <p class="text-muted">Review rules, cancellation guidelines, and licensing terms governing the practice suites.</p>
    </div>
</div>

<div class="row text-dark mb-5">
    <div class="col-12">
        <div class="card p-4 p-md-5 border-0 bg-white shadow-sm rounded-4">
            <h5 class="fw-bold text-dark mb-3">1. Platform License and Usage</h5>
            <p class="small text-muted mb-3" style="line-height:1.75;">
                Upon purchase of a premium package key, ExamDuniya grants you a finite, non-sublicensable, individual educational license to practice mock test modules and reviews. Shared logins or copying practice questions onto competitor portals is strictly prohibited.
            </p>
            
            <h5 class="fw-bold text-dark mt-4 mb-3">2. Mock Examination Content</h5>
            <p class="small text-muted mb-3" style="line-height:1.75;">
                The multiple-choice questions (MCQs) and solutions provided here are compiled for standard state practice purposes only. We do not warrant that identical questions will show up in the actual recruitments.
            </p>
            
            <h5 class="fw-bold text-dark mt-4 mb-3">3. Billing Policies & Cancellation</h5>
            <p class="small text-muted mb-3" style="line-height:1.75;">
                Package purchases represent intangible SaaS activation services instantiated immediately in user accounts. No cancellations or refunds can be completed once mock test slots are loaded and verified active in candidate desks.
            </p>
        </div>
    </div>
</div>

<?php
render_footer();
?>
