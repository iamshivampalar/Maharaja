<?php
/**
 * ProLandmark Elite - Testimonial System Editor
 * Dynamic client reviews builder for CMS.
 */
require_once '../config.php';

$action = $_GET['action'] ?? 'list';
$t_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$message = "";
$status_class = "";

// DELETE ACTION
if ($action === 'delete' && $t_id > 0) {
    if ($db) {
        try {
            $stmt = $db->prepare("DELETE FROM testimonials WHERE id = ?");
            $stmt->execute([$t_id]);
            set_alert("Client testimonial successfully removed from landing directories.", "success");
            log_activity("Exiled testimonial ID: " . $t_id, "Warning");
        } catch (Exception $e) {
            set_alert("Removal failed: " . $e->getMessage(), "danger");
        }
    }
    header("Location: testimonials.php");
    exit;
}

// SAVE ACTION
if (isset($_POST['save_testimonial'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = "CSRF verification mismatch.";
        $status_class = "danger";
    } else {
        $client_name = trim($_POST['client_name'] ?? '');
        $client_title = trim($_POST['client_title'] ?? '');
        $rating = intval($_POST['rating'] ?? 5);
        $review = trim($_POST['review'] ?? '');

        if (empty($client_name) || empty($client_title) || empty($review)) {
            $message = "Client name, corporate designation, and review writeup are mandatory.";
            $status_class = "warning";
        } else {
            try {
                if ($t_id > 0) {
                    $up_stmt = $db->prepare("UPDATE testimonials SET client_name=?, client_title=?, rating=?, review=? WHERE id=?");
                    $up_stmt->execute([$client_name, $client_title, $rating, $review, $t_id]);
                    set_alert("Client testimonial for '$client_name' updated successfully.", "success");
                    log_activity("Updated client testimonial ID: " . $t_id, "Info");
                } else {
                    $ins_stmt = $db->prepare("INSERT INTO testimonials (client_name, client_title, rating, review) VALUES (?, ?, ?, ?)");
                    $ins_stmt->execute([$client_name, $client_title, $rating, $review]);
                    set_alert("New testimonial for '$client_name' has been enabled.", "success");
                    log_activity("Added client testimonial for: " . $client_name, "Info");
                }
                header("Location: testimonials.php");
                exit;
            } catch (Exception $e) {
                $message = "Database save failed: " . $e->getMessage();
                $status_class = "danger";
            }
        }
    }
}

// FETCH SPECIFIC TESTIMONIAL
$testimonial = null;
if (($action === 'edit' || $action === 'add') && $t_id > 0) {
    try {
        $stmt = $db->prepare("SELECT * FROM testimonials WHERE id = ? LIMIT 1");
        $stmt->execute([$t_id]);
        $testimonial = $stmt->fetch();
    } catch (Exception $e) {}
}

render_admin_header("Testimonials CMS Module");
?>

<div class="row pt-2 g-4 text-start">
    <div class="col-12 d-flex justify-content-between align-items-center flex-wrap gap-2 pb-2 border-bottom">
        <div>
            <h1 class="h3 fw-bold text-dark luxury-heading mb-1">
                <?php echo ($action === 'add') ? 'Enable Testimonial' : (($action === 'edit') ? 'Modify Review Profile' : 'Client Testimonials Panel'); ?>
            </h1>
            <p class="text-secondary small mb-0">Publish direct feedback from esteemed partners who finalized direct acquisitions.</p>
        </div>
        <?php if ($action !== 'list') { ?>
            <a href="testimonials.php" class="btn btn-outline-dark btn-sm rounded-3"><i class="bi bi-arrow-left me-1"></i> Back to testimonials</a>
        <?php } else { ?>
            <a href="testimonials.php?action=add" class="btn btn-dark btn-sm rounded-3 px-3 py-2"><i class="bi bi-plus-circle me-1"></i> Enable New Testimonial</a>
        <?php } ?>
    </div>

    <!-- Alert Dialog -->
    <?php if (!empty($message)) { ?>
        <div class="col-12">
            <div class="alert alert-<?php echo $status_class; ?> border-0 shadow-sm rounded-3 py-3 m-0 d-flex align-items-center">
                <i class="bi bi-info-circle-fill fs-5 me-2"></i>
                <div><strong>Testimonial response:</strong> <?php echo s($message); ?></div>
            </div>
        </div>
    <?php } ?>

    <?php if ($action === 'list') { 
        $reviews = [];
        if ($db) {
            try {
                $reviews = $db->query("SELECT * FROM testimonials ORDER BY id DESC")->fetchAll();
            } catch (Exception $e) {}
        }
        ?>
        <div class="col-12">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <?php if (empty($reviews)) { ?>
                    <div class="text-center py-5">
                        <i class="bi bi-chat-quote fs-1 text-secondary opacity-35 mb-2"></i>
                        <h4 class="fw-bold mt-2">Testimonics register is clear</h4>
                        <p class="small text-secondary mb-4">Integrate pre-verified investor words to display beautifully on the landing showcase.</p>
                        <a href="testimonials.php?action=add" class="btn btn-accent rounded-3 px-4 py-2">Add First Feedback</a>
                    </div>
                <?php } else { ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 small">
                            <thead>
                                <tr class="table-light">
                                    <th>Partner Name & Designation</th>
                                    <th>Representative Review Text</th>
                                    <th>Rating Metric</th>
                                    <th>Registered Date</th>
                                    <th class="text-end">Command</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($reviews as $rev) { ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold text-dark"><?php echo s($rev['client_name']); ?></div>
                                            <span class="text-muted text-xs"><?php echo s($rev['client_title']); ?></span>
                                        </td>
                                        <td class="text-secondary" style="max-width:350px;">
                                            <span>"<?php echo s(substr($rev['review'], 0, 100)) . (strlen($rev['review']) > 100 ? '...' : ''); ?>"</span>
                                        </td>
                                        <td class="text-warning">
                                            <?php for($i=1;$i<=$rev['rating'];$i++) { echo '<i class="bi bi-star-fill"></i>'; } ?>
                                        </td>
                                        <td><span class="text-muted text-xs mono"><?php echo s($rev['created_at']); ?></span></td>
                                        <td class="text-end">
                                            <div class="d-flex justify-content-end gap-1">
                                                <a href="testimonials.php?action=edit&id=<?php echo $rev['id']; ?>" class="btn btn-xs btn-outline-dark p-1 px-2 text-xs"><i class="bi bi-pencil-square"></i> Edit</a>
                                                <a href="testimonials.php?action=delete&id=<?php echo $rev['id']; ?>" class="btn btn-xs btn-outline-danger p-1 px-2 text-xs" onclick="return confirm('Confirm complete termination of this partner testimonial?');"><i class="bi bi-trash-fill"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                <?php } ?>
            </div>
        </div>
    <?php } else { ?>
        <!-- FORM TO ADD/EDIT -->
        <div class="col-lg-6 mx-auto">
            <form method="POST" action="" class="card border-0 shadow-sm p-4 bg-white rounded-4 text-start">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                
                <h5 class="fw-bold text-dark border-bottom pb-2 mb-3"><i class="bi bi-person-fill border text-accent p-1.5 rounded-circle"></i> Testimonial Identity Sheet</h5>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Esteemed Client Name *</label>
                    <input type="text" name="client_name" value="<?php echo s($testimonial['client_name'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. Sienna Sterling" required>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Corporate Designation *</label>
                    <input type="text" name="client_title" value="<?php echo s($testimonial['client_title'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. CFO, Vance Asset Management" required>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Advisory Rating *</label>
                    <select name="rating" class="form-select border bg-light py-2">
                        <option value="5" <?php echo (($testimonial['rating'] ?? 5) == 5) ? 'selected' : ''; ?>>5 Stars Standard (Highly Exquisit)</option>
                        <option value="4" <?php echo (($testimonial['rating'] ?? 5) == 4) ? 'selected' : ''; ?>>4 Stars Executive standard</option>
                        <option value="3" <?php echo (($testimonial['rating'] ?? 5) == 3) ? 'selected' : ''; ?>>3 Stars (Satisfied)</option>
                    </select>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-semibold text-secondary">Direct Client Review *</label>
                    <textarea name="review" class="form-control border bg-light" rows="5" placeholder="Detail verified remarks regarding direct closings, structural parameters, or professional behavior..." required><?php echo s($testimonial['review'] ?? ''); ?></textarea>
                </div>

                <button type="submit" name="save_testimonial" class="btn btn-dark py-2.5 rounded-3 fw-bold w-full"><i class="bi bi-shield-check me-1"></i> Commit testimonial details</button>
            </form>
        </div>
    <?php } ?>
</div>

<?php
render_admin_footer();
?>
