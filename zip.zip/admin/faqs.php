<?php
/**
 * ProLandmark Elite - FAQ CMS Editor
 * Dynamic Question Answer blocks builder.
 */
require_once '../config.php';

$action = $_GET['action'] ?? 'list';
$faq_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$message = "";
$status_class = "";

// DELETE ACTION
if ($action === 'delete' && $faq_id > 0) {
    if ($db) {
        try {
            $stmt = $db->prepare("DELETE FROM faqs WHERE id = ?");
            $stmt->execute([$faq_id]);
            set_alert("FAQ listing successfully deleted from public directories.", "success");
            log_activity("Deleted FAQ ID: " . $faq_id, "Warning");
        } catch (Exception $e) {
            set_alert("Deletion failed: " . $e->getMessage(), "danger");
        }
    }
    header("Location: faqs.php");
    exit;
}

// SAVE ACTION
if (isset($_POST['save_faq'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = "CSRF verification mismatch.";
        $status_class = "danger";
    } else {
        $category = trim($_POST['category'] ?? 'General');
        $question = trim($_POST['question'] ?? '');
        $answer = trim($_POST['answer'] ?? '');

        if (empty($question) || empty($answer)) {
            $message = "A valid question and detailed resolution answer are necessary.";
            $status_class = "warning";
        } else {
            try {
                if ($faq_id > 0) {
                    $up_stmt = $db->prepare("UPDATE faqs SET category=?, question=?, answer=? WHERE id=?");
                    $up_stmt->execute([$category, $question, $answer, $faq_id]);
                    set_alert("FAQ record compiled and updated successfully.", "success");
                    log_activity("Updated FAQ item ID: " . $faq_id, "Info");
                } else {
                    $ins_stmt = $db->prepare("INSERT INTO faqs (category, question, answer) VALUES (?, ?, ?)");
                    $ins_stmt->execute([$category, $question, $answer]);
                    set_alert("New FAQ entry added to direct portal displays.", "success");
                    log_activity("Added FAQ entry: " . $question, "Info");
                }
                header("Location: faqs.php");
                exit;
            } catch (Exception $e) {
                $message = "FAQ saving failed: " . $e->getMessage();
                $status_class = "danger";
            }
        }
    }
}

// FETCH SPECIFIC FAQ
$faq = null;
if (($action === 'edit' || $action === 'add') && $faq_id > 0) {
    try {
        $stmt = $db->prepare("SELECT * FROM faqs WHERE id = ? LIMIT 1");
        $stmt->execute([$faq_id]);
        $faq = $stmt->fetch();
    } catch (Exception $e) {}
}

render_admin_header("Manage Portal FAQs");
?>

<div class="row pt-2 g-4 text-start">
    <div class="col-12 d-flex justify-content-between align-items-center flex-wrap gap-2 pb-2 border-bottom">
        <div>
            <h1 class="h3 fw-bold text-dark luxury-heading mb-1">
                <?php echo ($action === 'add') ? 'Add FAQ Item' : (($action === 'edit') ? 'Modify FAQ Details' : 'Manage Dynamic FAQs'); ?>
            </h1>
            <p class="text-secondary small mb-0 font-sans">Draft precise responses concerning client deeds, wire transfers, absolute sales, or site visiting parameters.</p>
        </div>
        <?php if ($action !== 'list') { ?>
            <a href="faqs.php" class="btn btn-outline-dark btn-sm rounded-3"><i class="bi bi-arrow-left me-1"></i> Back to Lists</a>
        <?php } else { ?>
            <a href="faqs.php?action=add" class="btn btn-dark btn-sm rounded-3 px-3 py-2"><i class="bi bi-plus-circle me-1"></i> Add Portfolio FAQ</a>
        <?php } ?>
    </div>

    <!-- Response Alerts -->
    <?php if (!empty($message)) { ?>
        <div class="col-12">
            <div class="alert alert-<?php echo $status_class; ?> border-0 shadow-sm rounded-3 py-3 m-0 d-flex align-items-center">
                <i class="bi bi-info-circle-fill fs-5 me-2"></i>
                <div><strong>FAQ Console:</strong> <?php echo s($message); ?></div>
            </div>
        </div>
    <?php } ?>

    <?php if ($action === 'list') { 
        $entries = [];
        if ($db) {
            try {
                $entries = $db->query("SELECT * FROM faqs ORDER BY category ASC, id DESC")->fetchAll();
            } catch (Exception $e) {}
        }
        ?>
        <div class="col-12">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <?php if (empty($entries)) { ?>
                    <div class="text-center py-5">
                        <i class="bi bi-question-diamond fs-1 text-secondary opacity-35 mb-2"></i>
                        <h4 class="fw-bold mt-2">Dynamic FAQs catalog empty</h4>
                        <p class="small text-secondary mb-4">Provide instant clarification parameters for prospective investors to read on public menus.</p>
                        <a href="faqs.php?action=add" class="btn btn-accent rounded-3 px-4 py-2">Add First FAQ</a>
                    </div>
                <?php } else { ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 small">
                            <thead>
                                <tr class="table-light">
                                    <th>Classification Category</th>
                                    <th>Corporate Inquiry Question</th>
                                    <th>Detailed Administrative Resolution</th>
                                    <th class="text-end">Command Options</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($entries as $item) { ?>
                                    <tr>
                                        <td>
                                            <span class="badge border bg-white p-2 text-dark font-sans" style="font-size:0.72rem;"><i class="bi bi-folder-fill text-accent me-1"></i> <?php echo s($item['category']); ?></span>
                                        </td>
                                        <td><strong class="text-dark fs-6"><?php echo s($item['question']); ?></strong></td>
                                        <td class="text-secondary" style="max-width:350px;">
                                            <span><?php echo s($item['answer']); ?></span>
                                        </td>
                                        <td class="text-end">
                                            <div class="d-flex justify-content-end gap-1">
                                                <a href="faqs.php?action=edit&id=<?php echo $item['id']; ?>" class="btn btn-xs btn-outline-dark p-1 px-2 text-xs"><i class="bi bi-pencil-square"></i></a>
                                                <a href="faqs.php?action=delete&id=<?php echo $item['id']; ?>" class="btn btn-xs btn-outline-danger p-1 px-2 text-xs" onclick="return confirm('Exterminate this registered FAQ option?');"><i class="bi bi-trash-fill"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                <?php } ?>
            </div>
        </div>
    <?php } else { ?>
        <!-- FAQ INPUT FORM -->
        <div class="col-lg-6 mx-auto">
            <form method="POST" action="" class="card border-0 shadow-sm p-4 bg-white rounded-4 text-start">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                
                <h5 class="fw-bold text-dark border-bottom pb-2 mb-3"><i class="bi bi-question-circle text-accent"></i> FAQ Formulation Sheet</h5>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Operational Category</label>
                    <select name="category" class="form-select border bg-light py-2">
                        <option value="Company Operations" <?php echo (($faq['category'] ?? '') === 'Company Operations') ? 'selected' : ''; ?>>Company Operations</option>
                        <option value="Asset Acquisitions" <?php echo (($faq['category'] ?? '') === 'Asset Acquisitions') ? 'selected' : ''; ?>>Asset Acquisitions</option>
                        <option value="Legal & Closures" <?php echo (($faq['category'] ?? '') === 'Legal & Closures') ? 'selected' : ''; ?>>Legal & Closures</option>
                        <option value="Direct Site Visits" <?php echo (($faq['category'] ?? '') === 'Direct Site Visits') ? 'selected' : ''; ?>>Direct Site Visits</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Frequently Questioned Query *</label>
                    <input type="text" name="question" value="<?php echo s($faq['question'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. Do you support direct title transfer clearances?" required>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-semibold text-secondary">Detailed Informational Resolution Answer *</label>
                    <textarea name="answer" class="form-control border bg-light" rows="5" placeholder="Formulate an absolute, detailed response regarding corporate deeds, wire methods, or clearing structures..." required><?php echo s($faq['answer'] ?? ''); ?></textarea>
                </div>

                <button type="submit" name="save_faq" class="btn btn-dark py-2.5 rounded-3 fw-bold w-full"><i class="bi bi-patch-check-fill me-1"></i> Register FAQ Parameter</button>
            </form>
        </div>
    <?php } ?>
</div>

<?php
render_admin_footer();
?>
