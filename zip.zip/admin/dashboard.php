<?php
/**
 * ProLandmark Elite - Super Admin Dashboard
 * Direct controller and overview panel for direct company holdings.
 */
require_once '../config.php';

// Fetch key stat counters
$total_properties = 0;
$total_leads = 0;
$upcoming_visits = 0;
$recent_leads = [];
$recent_visits = [];

if ($db) {
    try {
        $total_properties = $db->query("SELECT COUNT(*) FROM properties")->fetchColumn() ?: 0;
        $total_leads = $db->query("SELECT COUNT(*) FROM leads")->fetchColumn() ?: 0;
        $upcoming_visits = $db->query("SELECT COUNT(*) FROM site_visits WHERE status = 'Upcoming'")->fetchColumn() ?: 0;
        
        // Fetch 5 most recent lead entries
        $l_stmt = $db->query("SELECT l.*, p.title as property_title 
                             FROM leads l 
                             LEFT JOIN properties p ON l.property_id = p.id 
                             ORDER BY l.id DESC LIMIT 5");
        $recent_leads = $l_stmt->fetchAll();

        // Fetch 5 upcoming site visits
        $v_stmt = $db->query("SELECT v.*, p.title as property_title 
                             FROM site_visits v 
                             LEFT JOIN properties p ON v.property_id = p.id 
                             ORDER BY v.id DESC LIMIT 5");
        $recent_visits = $v_stmt->fetchAll();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

render_admin_header("Executive Admin Console");
?>

<div class="row pt-2 g-4">
    <!-- Title Section -->
    <div class="col-12 d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div>
            <h1 class="h3 fw-bold text-dark luxury-heading mb-1">Executive Dashboard</h1>
            <p class="text-secondary small mb-0">Direct portfolio status and acquisition pipelines for <?php echo s($app_company_name); ?>.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="properties.php?action=add" class="btn btn-dark btn-sm rounded-3 px-3 py-2"><i class="bi bi-plus-circle me-1"></i> Add Direct Asset</a>
            <a href="../db_setup.php" class="btn btn-outline-secondary btn-sm rounded-3"><i class="bi bi-database-gear me-1"></i> DB Engine</a>
        </div>
    </div>

    <!-- Stats Bento Cards -->
    <div class="col-12">
        <div class="row g-3">
            <div class="col-sm-6 col-lg-4">
                <div class="card-stat p-4 d-flex align-items-center gap-3">
                    <div class="p-3 bg-primary bg-opacity-10 text-primary rounded-3">
                        <i class="bi bi-buildings-fill fs-3"></i>
                    </div>
                    <div>
                        <span class="text-secondary small text-uppercase fw-semibold">Assets Held</span>
                        <h3 class="fw-bold text-dark m-0 mt-1"><?php echo $total_properties; ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="card-stat p-4 d-flex align-items-center gap-3">
                    <div class="p-3 bg-success bg-opacity-10 text-success rounded-3">
                        <i class="bi bi-people-fill fs-3"></i>
                    </div>
                    <div>
                        <span class="text-secondary small text-uppercase fw-semibold">Total Inquiries</span>
                        <h3 class="fw-bold text-dark m-0 mt-1"><?php echo $total_leads; ?></h3>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="card-stat p-4 d-flex align-items-center gap-3">
                    <div class="p-3 bg-warning bg-opacity-10 text-warning rounded-3">
                        <i class="bi bi-calendar-check-fill fs-3"></i>
                    </div>
                    <div>
                        <span class="text-secondary small text-uppercase fw-semibold">Upcoming Visits</span>
                        <h3 class="fw-bold text-dark m-0 mt-1"><?php echo $upcoming_visits; ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Left Main CRM Queue -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 p-4 bg-white mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                <h5 class="fw-bold m-0 text-dark"><i class="bi bi-clipboard2-pulse-fill text-accent"></i> Recent Direct Inquiries Pipeline</h5>
                <a href="leads.php" class="btn btn-outline-dark btn-xs px-2 py-1 small rounded">Full CRM <i class="bi bi-arrow-right"></i></a>
            </div>

            <?php if (empty($recent_leads)) { ?>
                <div class="text-center py-4">
                    <i class="bi bi-mailbox fs-2 text-secondary opacity-35 mb-2"></i>
                    <p class="text-muted small">No client inquiries received in active registries.</p>
                </div>
            <?php } else { ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 small">
                        <thead>
                            <tr class="table-light">
                                <th>Client Info</th>
                                <th>Asset Requested</th>
                                <th>Contact Method</th>
                                <th>Status</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_leads as $lead) { ?>
                                <tr>
                                    <td>
                                        <div class="fw-bold text-dark"><?php echo s($lead['name']); ?></div>
                                        <span class="text-muted text-xs"><?php echo s($lead['email']); ?> &bull; <?php echo s($lead['phone']); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-secondary fw-semibold"><?php echo s($lead['property_title'] ?: 'General Advisory Desk'); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge border bg-white text-dark"><?php echo s($lead['type']); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary bg-opacity-10 text-secondary"><?php echo s($lead['status']); ?></span>
                                    </td>
                                    <td class="text-end">
                                        <a href="leads.php?action=edit&id=<?php echo $lead['id']; ?>" class="btn btn-xs btn-outline-dark p-1.5 py-1 rounded"><i class="bi bi-eye"></i></a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php } ?>
        </div>

        <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
            <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                <h5 class="fw-bold m-0 text-dark"><i class="bi bi-clock-history text-success"></i> Upcoming Scheduled Site Itineraries</h5>
                <a href="site-visits.php" class="btn btn-outline-dark btn-xs px-2 py-1 small rounded">Visits List</a>
            </div>

            <?php if (empty($recent_visits)) { ?>
                <div class="text-center py-4">
                    <i class="bi bi-calendar-x fs-2 text-secondary opacity-35 mb-2"></i>
                    <p class="text-muted small">No scheduled active site inspections listed.</p>
                </div>
            <?php } else { ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 small">
                        <thead>
                            <tr class="table-light">
                                <th>Visitor Info</th>
                                <th>Schedule Date & Time</th>
                                <th>Property Name</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_visits as $visit) { ?>
                                <tr>
                                    <td>
                                        <div class="fw-bold text-dark"><?php echo s($visit['visitor_name']); ?></div>
                                        <span class="text-muted text-xs"><?php echo s($visit['visitor_phone']); ?></span>
                                    </td>
                                    <td>
                                        <div class="mono text-dark fw-bold"><?php echo s($visit['visit_date']); ?></div>
                                        <span class="text-muted text-xs"><?php echo s($visit['visit_time']); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-secondary"><?php echo s($visit['property_title']); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo ($visit['status'] == 'Upcoming') ? 'bg-primary text-light' : 'bg-dark text-secondary'; ?>"><?php echo s($visit['status']); ?></span>
                                    </td>
                                    <td class="text-end">
                                        <a href="site-visits.php?action=edit&id=<?php echo $visit['id']; ?>" class="btn btn-xs btn-outline-dark p-1.5 py-1 rounded"><i class="bi bi-pencil-square"></i></a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            <?php } ?>
        </div>
    </div>

    <!-- Right Side Quick Links and Server Info -->
    <div class="col-lg-4">
        <!-- Shortcuts Widget -->
        <div class="card border-0 shadow-sm rounded-4 p-4 bg-white mb-4">
            <h5 class="fw-bold mb-3 text-dark border-bottom pb-2">Quick Administration Access</h5>
            <div class="d-grid gap-2">
                <a href="properties.php?action=add" class="btn btn-outline-dark text-start py-2.5 rounded-3 d-flex align-items-center justify-content-between">
                    <span><i class="bi bi-building-add text-accent me-2"></i> Launch Brand Asset</span>
                    <i class="bi bi-chevron-right fs-9"></i>
                </a>
                <a href="leads.php" class="btn btn-outline-dark text-start py-2.5 rounded-3 d-flex align-items-center justify-content-between">
                    <span><i class="bi bi-envelope-check text-success me-2"></i> Check Advisory Inquiries</span>
                    <i class="bi bi-chevron-right fs-9"></i>
                </a>
                <a href="rebranding.php" class="btn btn-outline-dark text-start py-2.5 rounded-3 d-flex align-items-center justify-content-between">
                    <span><i class="bi bi-palette text-warning me-2"></i> Update Theme Parameters</span>
                    <i class="bi bi-chevron-right fs-9"></i>
                </a>
                <a href="../db_setup.php" class="btn btn-outline-secondary text-dark text-start py-2.5 rounded-3 d-flex align-items-center justify-content-between">
                    <span><i class="bi bi-database me-2"></i> SQL Deployment Vault</span>
                    <i class="bi bi-chevron-right fs-9"></i>
                </a>
            </div>
        </div>

        <!-- Structural Status Widget -->
        <div class="card border-0 shadow-sm rounded-4 p-4 bg-white text-start">
            <h5 class="fw-bold mb-3 text-dark border-bottom pb-2">Platform Metrology</h5>
            <div class="d-flex flex-column gap-2.5 small">
                <div class="d-flex justify-content-between border-bottom pb-2">
                    <span class="text-secondary">Core Framework</span>
                    <span class="fw-bold text-dark">PHP 8.3 Plain Core</span>
                </div>
                <div class="d-flex justify-content-between border-bottom pb-2">
                    <span class="text-secondary">MySQL Relational</span>
                    <span class="fw-bold text-success">SQLite Hybrid Driver Active</span>
                </div>
                <div class="d-flex justify-content-between border-bottom pb-2">
                    <span class="text-secondary">White-Label Lock</span>
                    <span class="fw-bold text-primary">Fully Enabled (Own portfolio)</span>
                </div>
                <div class="d-flex justify-content-between pb-2">
                    <span class="text-secondary">Hosting Mode</span>
                    <span class="fw-bold text-dark text-uppercase">cPanel Shared Ready</span>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
render_admin_footer();
?>
