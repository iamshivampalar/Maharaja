<?php
/**
 * ProLandmark Elite - Direct Site Visit Schedule Director
 * Central planning node for administrative personnel to coordinate structural asset tours.
 */
require_once '../config.php';

$action = $_GET['action'] ?? 'list';
$v_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$message = "";
$status_class = "";

// UPDATE ITINERARY ACTION
if (isset($_POST['save_itinerary'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = "CSRF verification mismatch.";
        $status_class = "danger";
    } else {
        $status = $_POST['status'] ?? 'Upcoming';
        $admin_notes = trim($_POST['admin_notes'] ?? '');
        $visit_date = $_POST['visit_date'] ?? '';
        $visit_time = $_POST['visit_time'] ?? '';

        if (empty($visit_date) || empty($visit_time)) {
            $message = "Date and Time coordinates are necessary.";
            $status_class = "warning";
        } else {
            try {
                $up_stmt = $db->prepare("UPDATE site_visits SET visit_date = ?, visit_time = ?, status = ?, admin_notes = ? WHERE id = ?");
                $up_stmt->execute([$visit_date, $visit_time, $status, $admin_notes, $v_id]);
                set_alert("Visit itinerary updated for schedule ID #" . $v_id, "success");
                log_activity("Updated site visit schedule parameters for identifier: " . $v_id, "Info");
                header("Location: site-visits.php");
                exit;
            } catch (Exception $e) {
                $message = "Itinerary save failed: " . $e->getMessage();
                $status_class = "danger";
            }
        }
    }
}

// FETCH SPECIFIC VISIT
$visit = null;
if ($action === 'edit' && $v_id > 0) {
    try {
        $stmt = $db->prepare("SELECT v.*, p.title as property_title 
                             FROM site_visits v 
                             LEFT JOIN properties p ON v.property_id = p.id 
                             WHERE v.id = ? LIMIT 1");
        $stmt->execute([$v_id]);
        $visit = $stmt->fetch();
    } catch (Exception $e) {}
}

render_admin_header("Manage Site Visits itineraries");
?>

<div class="row pt-2 g-4">
    <div class="col-12 d-flex justify-content-between align-items-center flex-wrap gap-2 pb-2 border-bottom">
        <div>
            <h1 class="h3 fw-bold text-dark luxury-heading mb-1">
                <?php echo ($action === 'edit') ? 'Edit Inspection Slot #' . $v_id : 'Site Inspection Schedules'; ?>
            </h1>
            <p class="text-secondary small mb-0">Coordinate exclusive, high-definition real estate walk-through sessions with elite clients.</p>
        </div>
        <?php if ($action !== 'list') { ?>
            <a href="site-visits.php" class="btn btn-outline-dark btn-sm rounded-3"><i class="bi bi-arrow-left me-1"></i> Back to Schedule</a>
        <?php } ?>
    </div>

    <?php if (!empty($message)) { ?>
        <div class="col-12">
            <div class="alert alert-<?php echo $status_class; ?> border-0 shadow-sm rounded-3 py-3 m-0 d-flex align-items-center">
                <i class="bi bi-info-circle-fill fs-5 me-2"></i>
                <div><strong>Scheduler response:</strong> <?php echo s($message); ?></div>
            </div>
        </div>
    <?php } ?>

    <?php if ($action === 'edit' && $visit) { ?>
        <!-- INTERACTIVE ITINERARY EDITOR -->
        <div class="col-lg-6 mx-auto">
            <form method="POST" action="" class="card border-0 shadow-sm p-4 bg-white rounded-4 text-start">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                
                <div class="text-center mb-4 pb-2 border-bottom">
                    <span class="badge border border-warning text-accent text-uppercase px-2.5 py-1 mb-2">Review Appointment Coordinates</span>
                    <h5 class="fw-bold text-dark m-0"><?php echo s($visit['visitor_name']); ?></h5>
                    <p class="small text-secondary mb-1">Target Asset: <strong><?php echo s($visit['property_title'] ?: 'Direct Asset'); ?></strong></p>
                    <span class="small text-muted d-block"><?php echo s($visit['visitor_email']); ?> &bull; <?php echo s($visit['visitor_phone']); ?></span>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Coordination Schedule Date</label>
                    <input type="date" name="visit_date" value="<?php echo s($visit['visit_date']); ?>" class="form-control border bg-light py-2" required>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Coordination Hour Window</label>
                    <select name="visit_time" class="form-select border bg-light py-2" required>
                        <option value="09:00 AM - 12:00 PM" <?php echo ($visit['visit_time'] === '09:00 AM - 12:00 PM') ? 'selected' : ''; ?>>Morning: 09:00 AM - 12:00 PM</option>
                        <option value="12:00 PM - 03:00 PM" <?php echo ($visit['visit_time'] === '12:00 PM - 03:00 PM') ? 'selected' : ''; ?>>Midday: 12:00 PM - 03:00 PM</option>
                        <option value="03:00 PM - 06:00 PM" <?php echo ($visit['visit_time'] === '03:00 PM - 06:00 PM') ? 'selected' : ''; ?>>Evening: 03:00 PM - 06:00 PM</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Visit Progress Status</label>
                    <select name="status" class="form-select border bg-light py-2">
                        <option value="Upcoming" <?php echo ($visit['status'] === 'Upcoming') ? 'selected' : ''; ?>>Upcoming scheduled slot</option>
                        <option value="Completed" <?php echo ($visit['status'] === 'Completed') ? 'selected' : ''; ?>>Completed successfully</option>
                        <option value="Cancelled" <?php echo ($visit['status'] === 'Cancelled') ? 'selected' : ''; ?>>Cancelled slot</option>
                    </select>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-semibold text-secondary">Internal Executive Notes (Chauffeur schedules, entry logs...)</label>
                    <textarea name="admin_notes" class="form-control border bg-light" rows="4" placeholder="Draft specialized entry authorizations or custom access remarks..."><?php echo s($visit['admin_notes']); ?></textarea>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" name="save_itinerary" class="btn btn-dark py-2.5 rounded-3 fw-bold"><i class="bi bi-check-circle me-1"></i> Update Itinerary Dispatch</button>
                    <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $visit['visitor_phone']); ?>" target="_blank" class="btn btn-outline-success border-success-subtle py-2.5 rounded-3"><i class="bi bi-whatsapp me-1"></i> Call Passenger/Visitor</a>
                </div>
            </form>
        </div>
    <?php } else { 
        $visits = [];
        if ($db) {
            try {
                $visits = $db->query("SELECT v.*, p.title as property_title 
                                      FROM site_visits v 
                                      LEFT JOIN properties p ON v.property_id = p.id 
                                      ORDER BY v.id DESC")->fetchAll();
            } catch (Exception $e) {}
        }
        ?>
        <!-- SCHEDULE LIST PANEL -->
        <div class="col-12">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <?php if (empty($visits)) { ?>
                    <div class="text-center py-5">
                        <i class="bi bi-calendar3 fs-1 opacity-25"></i>
                        <h4 class="fw-bold mt-2">Visits calendar is clear</h4>
                        <p class="small text-secondary mb-0">Client scheduled appointments from public pages appear in this chronological matrix.</p>
                    </div>
                <?php } else { ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 small text-start">
                            <thead>
                                <tr class="table-light">
                                    <th>Visitor Metadata</th>
                                    <th>Target Investment Asset</th>
                                    <th>Scheduled Date Coordinates</th>
                                    <th>Status Approval</th>
                                    <th>Brief Executive Memo</th>
                                    <th class="text-end font-sans">Operation</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($visits as $v) { ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold text-dark"><?php echo s($v['visitor_name']); ?></div>
                                            <span class="text-muted text-xs"><?php echo s($v['visitor_email']); ?> &bull; <?php echo s($v['visitor_phone']); ?></span>
                                        </td>
                                        <td>
                                            <span class="text-secondary fw-semibold"><?php echo s($v['property_title'] ?: 'Bespoke Asset'); ?></span>
                                        </td>
                                        <td>
                                            <div class="mono text-dark font-bold"><i class="bi bi-calendar-event text-accent"></i> <?php echo s($v['visit_date']); ?></div>
                                            <span class="text-muted text-xs"><i class="bi bi-clock"></i> <?php echo s($v['visit_time']); ?></span>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo ($v['status'] === 'Upcoming') ? 'bg-primary' : (($v['status'] === 'Completed') ? 'bg-success' : 'bg-secondary text-light'); ?>"><?php echo s($v['status']); ?></span>
                                        </td>
                                        <td>
                                            <span class="text-secondary tracking-tight"><?php echo s($v['admin_notes'] ? substr($v['admin_notes'], 0, 50) . '...' : 'Direct schedule validation initialized.'); ?></span>
                                        </td>
                                        <td class="text-end">
                                            <a href="site-visits.php?action=edit&id=<?php echo $v['id']; ?>" class="btn btn-sm btn-outline-dark px-3 py-1"><i class="bi bi-pencil-square"></i> Coordinate</a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                <?php } ?>
            </div>
        </div>
    <?php } ?>
</div>

<?php
render_admin_footer();
?>
