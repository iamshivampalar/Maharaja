<?php
/**
 * ProLandmark Elite - Portfolio Editor & Creator Node
 * Full dynamic asset builder with complete form fields, slug mapping, and error guards.
 */
require_once '../config.php';

$action = $_GET['action'] ?? 'list';
$p_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$categories = [];
if ($db) {
    try {
        $categories = $db->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();
    } catch (Exception $e) {}
}

$message = "";
$status_class = "";

// DELETE ACTION
if ($action === 'delete' && $p_id > 0) {
    if ($db) {
        try {
            $stmt = $db->prepare("DELETE FROM properties WHERE id = ?");
            $stmt->execute([$p_id]);
            set_alert("Asset deleted successfully from company registries.", "success");
            log_activity("Deleted property asset id: " . $p_id, "Warning");
        } catch (Exception $e) {
            set_alert("Failed to delete asset: " . $e->getMessage(), "danger");
        }
    }
    header("Location: properties.php");
    exit;
}

// FORM SAVE / CREATE ACTION
if (isset($_POST['save_property'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = "CSRF protection signature verification failed.";
        $status_class = "danger";
    } else {
        $category_id = intval($_POST['category_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $slug = trim($_POST['slug'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $short_description = trim($_POST['short_description'] ?? '');
        $highlights = trim($_POST['highlights'] ?? '');
        $features = trim($_POST['features'] ?? '');
        $amenities = trim($_POST['amenities'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $city = trim($_POST['city'] ?? '');
        $state = trim($_POST['state'] ?? '');
        $price = intval($_POST['price'] ?? 0);
        $area = intval($_POST['area'] ?? 0);
        $bedrooms = intval($_POST['bedrooms'] ?? 0);
        $bathrooms = intval($_POST['bathrooms'] ?? 0);
        $parking = intval($_POST['parking'] ?? 0);
        $balconies = intval($_POST['balconies'] ?? 0);
        $virtual_tour_url = trim($_POST['virtual_tour_url'] ?? '');
        $video_url = trim($_POST['video_url'] ?? '');
        $nearby_schools = trim($_POST['nearby_schools'] ?? '');
        $nearby_hospitals = trim($_POST['nearby_hospitals'] ?? '');
        $nearby_markets = trim($_POST['nearby_markets'] ?? '');
        $nearby_metro = trim($_POST['nearby_metro'] ?? '');
        $status = $_POST['status'] ?? 'Ready To Move';
        $type = $_POST['type'] ?? 'Apartment';
        $featured = isset($_POST['featured']) ? 1 : 0;

        if (empty($title) || empty($slug) || empty($description) || empty($short_description) || $price <= 0 || $area <= 0) {
            $message = "Mandatory information (Title, Slug, Descriptions, Price, and Area) must be filled.";
            $status_class = "warning";
        } else {
            if ($p_id > 0) {
                // Update
                try {
                    $up_sql = "UPDATE properties SET 
                                category_id=?, title=?, slug=?, description=?, short_description=?, highlights=?, features=?, amenities=?,
                                address=?, city=?, state=?, price=?, area=?, bedrooms=?, bathrooms=?, parking=?, balconies=?,
                                virtual_tour_url=?, video_url=?, nearby_schools=?, nearby_hospitals=?, nearby_markets=?, nearby_metro=?,
                                status=?, type=?, featured=? 
                                WHERE id=?";
                    $up_stmt = $db->prepare($up_sql);
                    $up_stmt->execute([
                        $category_id, $title, $slug, $description, $short_description, $highlights, $features, $amenities,
                        $address, $city, $state, $price, $area, $bedrooms, $bathrooms, $parking, $balconies,
                        $virtual_tour_url, $video_url, $nearby_schools, $nearby_hospitals, $nearby_markets, $nearby_metro,
                        $status, $type, $featured, $p_id
                    ]);
                    set_alert("Portfolio asset '$title' updated successfully.", "success");
                    log_activity("Updated portfolio property: " . $title, "Info");
                    header("Location: properties.php");
                    exit;
                } catch (Exception $e) {
                    $message = "Database writing error: " . $e->getMessage();
                    $status_class = "danger";
                }
            } else {
                // Insert
                try {
                    $ins_sql = "INSERT INTO properties (
                                    category_id, title, slug, description, short_description, highlights, features, amenities,
                                    address, city, state, price, area, bedrooms, bathrooms, parking, balconies,
                                    virtual_tour_url, video_url, nearby_schools, nearby_hospitals, nearby_markets, nearby_metro,
                                    status, type, featured
                                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $ins_stmt = $db->prepare($ins_sql);
                    $ins_stmt->execute([
                        $category_id, $title, $slug, $description, $short_description, $highlights, $features, $amenities,
                        $address, $city, $state, $price, $area, $bedrooms, $bathrooms, $parking, $balconies,
                        $virtual_tour_url, $video_url, $nearby_schools, $nearby_hospitals, $nearby_markets, $nearby_metro,
                        $status, $type, $featured
                    ]);
                    set_alert("New landmark asset '$title' registered to portfolio database.", "success");
                    log_activity("Added new portfolio property: " . $title, "Info");
                    header("Location: properties.php");
                    exit;
                } catch (Exception $e) {
                    $message = "Database registration failed: " . $e->getMessage();
                    $status_class = "danger";
                }
            }
        }
    }
}

// Fetch single property if we are in EDIT mode
$property = null;
if (($action === 'edit' || $action === 'add') && $p_id > 0) {
    try {
        $stmt = $db->prepare("SELECT * FROM properties WHERE id = ? LIMIT 1");
        $stmt->execute([$p_id]);
        $property = $stmt->fetch();
    } catch (Exception $e) {}
}

render_admin_header("Manage Properties Portfolio");
?>

<div class="row pt-2 g-4">
    <div class="col-12 d-flex justify-content-between align-items-center flex-wrap gap-2 pb-2 border-bottom">
        <div>
            <h1 class="h3 fw-bold text-dark luxury-heading mb-1">
                <?php echo ($action === 'add') ? 'Launch New Property' : (($action === 'edit') ? 'Modify Property Parameters' : 'Portfolio Registers'); ?>
            </h1>
            <p class="text-secondary small mb-0">Control direct, elite real estate creations available to prospective buyers.</p>
        </div>
        <?php if ($action !== 'list') { ?>
            <a href="properties.php" class="btn btn-outline-dark btn-sm rounded-3"><i class="bi bi-arrow-left me-1"></i> Back to Catalog</a>
        <?php } else { ?>
            <a href="properties.php?action=add" class="btn btn-dark btn-sm rounded-3 px-3 py-2"><i class="bi bi-plus-circle me-1"></i> Launch Landmark Asset</a>
        <?php } ?>
    </div>

    <!-- Alert Responses -->
    <?php if (!empty($message)) { ?>
        <div class="col-12">
            <div class="alert alert-<?php echo $status_class; ?> border-0 shadow-sm rounded-3 py-3 m-0 d-flex align-items-center">
                <i class="bi bi-info-circle-fill fs-5 me-2"></i>
                <div><strong>Vault Notice:</strong> <?php echo s($message); ?></div>
            </div>
        </div>
    <?php } ?>

    <?php if ($action === 'list') { 
        // Fetch properties list
        $props = [];
        if ($db) {
            try {
                $props = $db->query("SELECT p.*, c.name as category_name 
                                     FROM properties p 
                                     LEFT JOIN categories c ON p.category_id = c.id 
                                     ORDER BY p.id DESC")->fetchAll();
            } catch (Exception $e) {}
        }
        ?>
        <div class="col-12">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <?php if (empty($props)) { ?>
                    <div class="text-center py-5">
                        <i class="bi bi-hospital fs-1 text-secondary opacity-35 mb-2"></i>
                        <h4 class="fw-bold mt-2 text-dark">No Assets Registered Yet</h4>
                        <p class="text-secondary small mb-4">Launch your first corporate-owned property to showcase on the main portal.</p>
                        <a href="properties.php?action=add" class="btn btn-accent rounded-3 px-4 py-2">Add New Property Now</a>
                    </div>
                <?php } else { ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 small">
                            <thead>
                                <tr class="table-light">
                                    <th>Asset Title</th>
                                    <th>Category & Style</th>
                                    <th>Established Price</th>
                                    <th>Square Footage</th>
                                    <th>Views</th>
                                    <th>Status</th>
                                    <th class="text-end">Actions Matrix</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($props as $p) { ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold text-dark fs-6 d-flex align-items-center gap-1.5">
                                                <?php if($p['featured']) { echo '<i class="bi bi-star-fill text-warning fs-8"></i>'; } ?>
                                                <?php echo s($p['title']); ?>
                                            </div>
                                            <span class="text-muted text-xs"><i class="bi bi-geo-alt"></i> <?php echo s($p['city']); ?>, <?php echo s($p['state']); ?></span>
                                        </td>
                                        <td>
                                            <span class="text-secondary fw-semibold"><?php echo s($p['category_name'] ?: 'None Set'); ?></span>
                                            <span class="badge bg-light text-dark font-sans" style="font-size: 0.7rem;"><?php echo s($p['type']); ?></span>
                                        </td>
                                        <td><strong class="text-accent fs-6"><?php echo format_price($p['price']); ?></strong></td>
                                        <td><span class="mono fw-semibold"><?php echo number_format($p['area']); ?> Sq Ft</span></td>
                                        <td><span class="badge border bg-white text-muted"><i class="bi bi-eye"></i> <?php echo intval($p['views']); ?></span></td>
                                        <td><span class="badge-status status-<?php echo str_replace(' ', '', $p['status']); ?> badge"><?php echo s($p['status']); ?></span></td>
                                        <td class="text-end">
                                            <div class="d-flex justify-content-end gap-1">
                                                <a href="../property-details.php?slug=<?php echo s($p['slug']); ?>" target="_blank" class="btn btn-sm btn-outline-info p-1 px-2 text-xs" title="Preview Publicly"><i class="bi bi-link-45deg"></i></a>
                                                <a href="properties.php?action=edit&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-dark p-1 px-2 text-xs" title="Edit Parameters"><i class="bi bi-pencil-square"></i></a>
                                                <a href="properties.php?action=delete&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-outline-danger p-1 px-2 text-xs" title="Exile from Catalog" onclick="return confirm('Confirm complete removal of this asset from direct portfolios? This action is irreversible.');"><i class="bi bi-trash-fill"></i></a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                <?php } ?>
            </div>
        </div>
    <?php } else { ?>
        <!-- ADD OR EDIT SLIDERS FORM -->
        <div class="col-12">
            <form method="POST" action="" class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                
                <div class="row g-3 text-start">
                    <!-- Primary Identifiers -->
                    <div class="col-12">
                        <h4 class="fw-bold text-dark border-bottom pb-2 mb-3 h5"><i class="bi bi-tag text-accent"></i> Core Identifiers</h4>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Asset Title *</label>
                        <input type="text" name="title" id="pTitle" value="<?php echo s($property['title'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. The Obsidian Cliff Estate" required onkeyup="generateSlug(this.value)">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Dynamic SEO Slug *</label>
                        <input type="text" name="slug" id="pSlug" value="<?php echo s($property['slug'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. the-obsidian-cliff-estate" required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label small fw-semibold text-secondary">Parent Category *</label>
                        <select name="category_id" class="form-select border bg-light py-2">
                            <option value="">Choose Category</option>
                            <?php foreach ($categories as $cat) { ?>
                                <option value="<?php echo $cat['id']; ?>" <?php echo (($property['category_id'] ?? 0) == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo s($cat['name']); ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label small fw-semibold text-secondary">Property Type *</label>
                        <select name="type" class="form-select border bg-light py-2">
                            <option value="Apartment" <?php echo (($property['type'] ?? '') == 'Apartment') ? 'selected' : ''; ?>>Apartment</option>
                            <option value="Flat" <?php echo (($property['type'] ?? '') == 'Flat') ? 'selected' : ''; ?>>Flat</option>
                            <option value="Villa" <?php echo (($property['type'] ?? '') == 'Villa') ? 'selected' : ''; ?>>Villa</option>
                            <option value="Office" <?php echo (($property['type'] ?? '') == 'Office') ? 'selected' : ''; ?>>Premium Office</option>
                            <option value="Land" <?php echo (($property['type'] ?? '') == 'Land') ? 'selected' : ''; ?>>Development Land</option>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label small fw-semibold text-secondary">Acquisition Status *</label>
                        <select name="status" class="form-select border bg-light py-2">
                            <option value="Ready To Move" <?php echo (($property['status'] ?? '') == 'Ready To Move') ? 'selected' : ''; ?>>Ready To Move</option>
                            <option value="For Sale" <?php echo (($property['status'] ?? '') == 'For Sale') ? 'selected' : ''; ?>>For Sale</option>
                            <option value="Under Construction" <?php echo (($property['status'] ?? '') == 'Under Construction') ? 'selected' : ''; ?>>Under Construction</option>
                            <option value="Upcoming" <?php echo (($property['status'] ?? '') == 'Upcoming') ? 'selected' : ''; ?>>Upcoming Release</option>
                            <option value="Sold" <?php echo (($property['status'] ?? '') == 'Sold') ? 'selected' : ''; ?>>Sold Out</option>
                        </select>
                    </div>

                    <!-- Geographics -->
                    <div class="col-12 mt-4">
                        <h4 class="fw-bold text-dark border-bottom pb-2 mb-3 h5"><i class="bi bi-geo-alt text-accent"></i> Physical Navigation & Coordinates</h4>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Physical Address *</label>
                        <input type="text" name="address" value="<?php echo s($property['address'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. 1002 Obsidian Boulevard, Coastline Cliff" required>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label small fw-semibold text-secondary">City Block *</label>
                        <input type="text" name="city" value="<?php echo s($property['city'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. Metropolis" required>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label small fw-semibold text-secondary">State Domain *</label>
                        <input type="text" name="state" value="<?php echo s($property['state'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. New York" required>
                    </div>

                    <!-- Values metrics -->
                    <div class="col-12 mt-4">
                        <h4 class="fw-bold text-dark border-bottom pb-2 mb-3 h5"><i class="bi bi-cash-stack text-accent"></i> Valuation and Sizing Bounds</h4>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label small fw-semibold text-secondary">Portfolio Value Price ($) *</label>
                        <input type="number" name="price" value="<?php echo intval($property['price'] ?? 0); ?>" class="form-control border bg-light py-2" placeholder="e.g. 14500000" required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label small fw-semibold text-secondary">Structural Footprint Area (Sq Ft) *</label>
                        <input type="number" name="area" value="<?php echo intval($property['area'] ?? 0); ?>" class="form-control border bg-light py-2" placeholder="e.g. 14500" required>
                    </div>

                    <div class="col-md-2">
                        <label class="form-label small fw-semibold text-secondary">Bedrooms</label>
                        <input type="number" name="bedrooms" value="<?php echo intval($property['bedrooms'] ?? 0); ?>" class="form-control border bg-light py-2" placeholder="4">
                    </div>

                    <div class="col-md-2">
                        <label class="form-label small fw-semibold text-secondary">Bathrooms</label>
                        <input type="number" name="bathrooms" value="<?php echo intval($property['bathrooms'] ?? 0); ?>" class="form-control border bg-light py-2" placeholder="5">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label small fw-semibold text-secondary">Parking Lot Slots</label>
                        <input type="number" name="parking" value="<?php echo intval($property['parking'] ?? 0); ?>" class="form-control border bg-light py-2" placeholder="3">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label small fw-semibold text-secondary">Balconies Count</label>
                        <input type="number" name="balconies" value="<?php echo intval($property['balconies'] ?? 0); ?>" class="form-control border bg-light py-2" placeholder="2">
                    </div>

                    <div class="col-md-4 pt-sm-4">
                        <div class="form-check form-switch pt-md-2">
                            <input class="form-check-input" type="checkbox" name="featured" id="chkFeat" <?php echo (!empty($property['featured'])) ? 'checked' : ''; ?>>
                            <label class="form-check-label fw-bold text-dark small" for="chkFeat">Feature On Landing Slider</label>
                        </div>
                    </div>

                    <!-- Descriptions -->
                    <div class="col-12 mt-4">
                        <h4 class="fw-bold text-dark border-bottom pb-2 mb-3 h5"><i class="bi bi-body-text text-accent"></i> Descriptions and Philosophy Text</h4>
                    </div>

                    <div class="col-12">
                        <label class="form-label small fw-semibold text-secondary">Direct Short Pitch Description (Featured Listings) *</label>
                        <input type="text" name="short_description" value="<?php echo s($property['short_description'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="Keep it neat, clean, and catchy..." required>
                    </div>

                    <div class="col-12">
                        <label class="form-label small fw-semibold text-secondary">Full Structural Philosophy / Features Writeup *</label>
                        <textarea name="description" class="form-control border bg-light" rows="5" placeholder="Details concerning stone types, custom steel cores, high ceilings, etc..." required><?php echo s($property['description'] ?? ''); ?></textarea>
                    </div>

                    <!-- Marketing and nearby locations -->
                    <div class="col-12 mt-4">
                        <h4 class="fw-bold text-dark border-bottom pb-2 mb-3 h5"><i class="bi bi-map text-accent"></i> Local Infrastructure Proximities</h4>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Nearby Academic Blocks</label>
                        <input type="text" name="nearby_schools" value="<?php echo s($property['nearby_schools'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. Saint Sophia Academy (1.5 km)">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Nearby Trauma Hospitals</label>
                        <input type="text" name="nearby_hospitals" value="<?php echo s($property['nearby_hospitals'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. Regional Medical Center (2.0 km)">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Nearby Luxe Malls</label>
                        <input type="text" name="nearby_markets" value="<?php echo s($property['nearby_markets'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. The Galleria High-Street Arcade (0.5 km)">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Nearby Transit Interchanges</label>
                        <input type="text" name="nearby_metro" value="<?php echo s($property['nearby_metro'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. Central Avenue Interchange (4 mins walk)">
                    </div>

                    <!-- Advanced embed vectors -->
                    <div class="col-12 mt-4">
                        <h4 class="fw-bold text-dark border-bottom pb-2 mb-3 h5"><i class="bi bi-badge-3d text-accent"></i> Virtual Walkthrough and Media Wrappers</h4>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Virtual Tour Walkthrough URL (Matterport / Frame Embed Link)</label>
                        <input type="url" name="virtual_tour_url" value="<?php echo s($property['virtual_tour_url'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. https://my.matterport.com/show/?m=...">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Cinematic Video Tour URL (YouTube Embeddable Iframe source)</label>
                        <input type="url" name="video_url" value="<?php echo s($property['video_url'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="e.g. https://www.youtube.com/embed/...">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Company Bullet Highlights (Comma separated, premium details)</label>
                        <input type="text" name="highlights" value="<?php echo s($property['highlights'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="Bullet 1, Bullet 2, Bullet 3">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Amenities Panel (Comma separated, custom layouts)</label>
                        <input type="text" name="amenities" value="<?php echo s($property['amenities'] ?? ''); ?>" class="form-control border bg-light py-2" placeholder="Helipad, Infinity Pool, Butler Quarters">
                    </div>

                    <!-- Submit action button -->
                    <div class="col-12 mt-5 border-top pt-4 text-end">
                        <button type="submit" name="save_property" class="btn btn-dark rounded-3 px-4 py-2.5 fw-bold"><i class="bi bi-patch-check-fill me-1"></i> Save Asset Parameter Registry</button>
                    </div>
                </div>
            </form>
        </div>
    <?php } ?>
</div>

<script>
function generateSlug(val) {
    const pSlug = document.getElementById('pSlug');
    if (pSlug) {
        pSlug.value = val.toLowerCase()
                       .replace(/[^a-z0-9\s-]/g, '')
                       .replace(/\s+/g, '-')
                       .replace(/-+/g, '-');
    }
}
</script>

<?php
render_admin_footer();
?>
