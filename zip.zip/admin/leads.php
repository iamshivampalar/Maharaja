<?php
/**
 * ProLandmark Elite - Direct Advisory Corporate CRM & Lead Center
 * Comprehensive tracking from initial inquiry to negotiation schedules, reminders, and CSV reporting.
 */
require_once '../config.php';

$action = $_GET['action'] ?? 'list';
$l_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$message = "";
$status_class = "";

// CSV EXPORT ROUTE
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    if ($db) {
        try {
            $leads_export = $db->query("SELECT l.*, p.title as property_title 
                                        FROM leads l 
                                        LEFT JOIN properties p ON l.property_id = p.id 
                                        ORDER BY l.id DESC")->fetchAll();

            // Clear buffers and prepare headers
            ob_end_clean();
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=corporate_acquisition_leads_' . date('Y_m_d') . '.csv');
            
            $output = fopen('php://output', 'w');
            fputcsv($output, ['ID', 'Requested Property', 'Client Name', 'Private Email', 'Direct Phone', 'Classification', 'Status', 'Reminders Scheduled', 'Client Notes', 'Logged Time']);
            
            foreach ($leads_export as $lex) {
                fputcsv($output, [
                    $lex['id'],
                    $lex['property_title'] ?: 'General Advisory Desk',
                    $lex['name'],
                    $lex['email'],
                    $lex['phone'],
                    $lex['type'],
                    $lex['status'],
                    $lex['reminder_date'] ?: 'None Set',
                    $lex['message'] ?: '',
                    $lex['created_at']
                ]);
            }
            fclose($output);
            exit;
        } catch (Exception $e) {
            set_alert("Report export crashed: " . $e->getMessage(), "danger");
        }
    }
}

// SAVE INTERACTION / UPDATE CRM STATUS
if (isset($_POST['save_crm'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = "CSRF verification signature error. Dismissed.";
        $status_class = "danger";
    } else {
        $status = $_POST['status'] ?? 'New';
        $notes = trim($_POST['notes'] ?? '');
        $reminder_date = !empty($_POST['reminder_date']) ? $_POST['reminder_date'] : null;
        $history_add = trim($_POST['history_add'] ?? '');

        if ($l_id > 0) {
            try {
                // Fetch standard history first
                $history_stmt = $db->prepare("SELECT interaction_history FROM leads WHERE id = ?");
                $history_stmt->execute([$l_id]);
                $old_hist = $history_stmt->fetchColumn() ?: "[]";
                
                $timeline = json_decode($old_hist, true) ?: [];
                if (!empty($history_add)) {
                    $timeline[] = [
                        'timestamp' => date('Y-m-d H:i:s'),
                        'author' => $_SESSION['uname'],
                        'note' => $history_add
                    ];
                }

                $up_sql = "UPDATE leads SET status = ?, notes = ?, reminder_date = ?, interaction_history = ? WHERE id = ?";
                $up_stmt = $db->prepare($up_sql);
                $up_stmt->execute([$status, $notes, $reminder_date, json_encode($timeline), $l_id]);

                set_alert("Client lead record ID #" . $l_id . " updated on executive ledger.", "success");
                log_activity("Updated CRM lead parameters for target ID: " . $l_id, "Info");
                header("Location: leads.php");
                exit;
            } catch (Exception $e) {
                $message = "CRM Database update failed: " . $e->getMessage();
                $status_class = "danger";
            }
        }
    }
}

// FETCH LEAD IF ACTION = EDIT
$lead = null;
if ($action === 'edit' && $l_id > 0) {
    if ($db) {
        try {
            $stmt = $db->prepare("SELECT l.*, p.title as property_title 
                                  FROM leads l 
                                  LEFT JOIN properties p ON l.property_id = p.id 
                                  WHERE l.id = ? LIMIT 1");
            $stmt->execute([$l_id]);
            $lead = $stmt->fetch();
        } catch (Exception $e) {}
    }
}

render_admin_header("Corporate Relations CRM");
?>

<div class="row pt-2 g-4">
    <div class="col-12 d-flex justify-content-between align-items-center flex-wrap gap-2 pb-2 border-bottom">
        <div>
            <h1 class="h3 fw-bold text-dark luxury-heading mb-1">
                <?php echo ($action === 'edit') ? 'CRM Advisory File #' . $l_id : 'CRM Acquisition Pipelines'; ?>
            </h1>
            <p class="text-secondary small mb-0">Aggregate private inquiries, advisory logs, document requisitions, and title negotiations in-house.</p>
        </div>
        <div>
            <?php if ($action !== 'list') { ?>
                <a href="leads.php" class="btn btn-outline-dark btn-sm rounded-3"><i class="bi bi-arrow-left me-1"></i> Back to Ledger</a>
            <?php } else { ?>
                <a href="leads.php?export=csv" class="btn btn-dark btn-sm rounded-3 px-3 py-2"><i class="bi bi-file-earmark-spreadsheet me-1"></i> Export CSV Spreadsheet</a>
            <?php } ?>
        </div>
    </div>

    <?php if (!empty($message)) { ?>
        <div class="col-12">
            <div class="alert alert-<?php echo $status_class; ?> border-0 shadow-sm rounded-3 py-3 m-0 d-flex align-items-center">
                <i class="bi bi-info-circle-fill fs-5 me-2"></i>
                <div><strong>CRM Center:</strong> <?php echo s($message); ?></div>
            </div>
        </div>
    <?php } ?>

    <!-- 1. DETAILED CRM FILE FOR A SINGLE LEAD -->
    <?php if ($action === 'edit' && $lead) { 
        $timeline = json_decode($lead['interaction_history'] ?? "[]", true) ?: [];
        ?>
        <div class="col-lg-5">
            <div class="card border-0 shadow-sm p-4 bg-white rounded-4 text-start h-full mb-4">
                <div class="text-center pb-3 border-bottom mb-4">
                    <span class="badge border border-success text-success text-uppercase p-2 mb-2"><i class="bi bi-person-badge"></i> Client Metadata Card</span>
                    <h4 class="fw-bold m-0 text-dark"><?php echo s($lead['name']); ?></h4>
                    <p class="small text-muted mt-1 mb-0">Registered via: <?php echo s($lead['type']); ?></p>
                </div>

                <div class="d-flex flex-column gap-3 mb-4 small">
                    <div>
                        <span class="text-secondary d-block">Private Email Vector</span>
                        <a href="mailto:<?php echo s($lead['email']); ?>" class="fw-bold text-dark text-decoration-none"><i class="bi bi-envelope me-1 text-accent"></i> <?php echo s($lead['email']); ?></a>
                    </div>
                    <div>
                        <span class="text-secondary d-block">Voice Direct Line</span>
                        <a href="tel:<?php echo s($lead['phone']); ?>" class="fw-bold text-dark text-decoration-none"><i class="bi bi-telephone me-1 text-accent"></i> <?php echo s($lead['phone']); ?></a>
                    </div>
                    <div>
                        <span class="text-secondary d-block">Requested Landmark Asset</span>
                        <span class="fw-bold text-dark"><i class="bi bi-building me-1 text-accent"></i> <?php echo s($lead['property_title'] ?: 'General Advisory Desk'); ?></span>
                    </div>
                    <div>
                        <span class="text-secondary d-block">First Logged Query / Letter</span>
                        <div class="p-3 bg-light rounded-3 border italic mt-1 text-secondary">
                            "<?php echo s($lead['message'] ?: 'Client requested immediate general callback.'); ?>"
                        </div>
                    </div>
                    <div>
                        <span class="text-secondary d-block">Inquiry Registered</span>
                        <span class="fw-bold text-dark"><i class="bi bi-clock me-1 text-accent"></i> <?php echo s($lead['created_at']); ?></span>
                    </div>
                </div>

                <div class="d-grid mt-4">
                    <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', $lead['phone']); ?>" target="_blank" class="btn btn-success fw-bold py-2.5 rounded-3"><i class="bi bi-whatsapp me-1"></i> Open Direct WhatsApp</a>
                </div>
            </div>
        </div>

        <div class="col-lg-7">
            <!-- Negotiation Controller -->
            <form method="POST" action="" class="card border-0 shadow-sm p-4 bg-white rounded-4 text-start mb-4">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                
                <h5 class="fw-bold text-dark mb-3 pb-2 border-bottom"><i class="bi bi-sliders text-accent"></i> Portfolio Advisory Negotiation Panel</h5>
                
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Lead Workflow status</label>
                        <select name="status" class="form-select border bg-light py-2">
                            <option value="New" <?php echo ($lead['status'] === 'New') ? 'selected' : ''; ?>>New Registry Lead</option>
                            <option value="Contacted" <?php echo ($lead['status'] === 'Contacted') ? 'selected' : ''; ?>>Contact Established</option>
                            <option value="Interested" <?php echo ($lead['status'] === 'Interested') ? 'selected' : ''; ?>>High Interest Active</option>
                            <option value="Site Visit Scheduled" <?php echo ($lead['status'] === 'Site Visit Scheduled') ? 'selected' : ''; ?>>Site Visit Itinerary Active</option>
                            <option value="Negotiation" <?php echo ($lead['status'] === 'Negotiation') ? 'selected' : ''; ?>>Pricing / Contract Negotiation</option>
                            <option value="Closed" <?php echo ($lead['status'] === 'Closed') ? 'selected' : ''; ?>>Fulfillment Secured & Closed</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label small fw-semibold text-secondary">Schedule Next Reminder Date</label>
                        <input type="datetime-local" name="reminder_date" value="<?php echo $lead['reminder_date'] ? date('Y-m-d\TH:i', strtotime($lead['reminder_date'])) : ''; ?>" class="form-control border bg-light py-2">
                    </div>

                    <div class="col-12">
                        <label class="form-label small fw-semibold text-secondary">Advisory Follow-up Notes (Append permanent interaction entry)</label>
                        <input type="text" name="history_add" class="form-control border bg-light py-2.5" placeholder="e.g. Conducted callback. Client requested direct site visit coordination.">
                    </div>

                    <div class="col-12">
                        <label class="form-label small fw-semibold text-secondary">General Manager Administrative Remainder Dossier</label>
                        <textarea name="notes" class="form-control border bg-light" rows="4" placeholder="Personal remarks, budget limitations, client background details..."><?php echo s($lead['notes'] ?? ''); ?></textarea>
                    </div>

                    <div class="col-12 mt-4 text-end">
                        <button type="submit" name="save_crm" class="btn btn-dark rounded-3 px-4"><i class="bi bi-check-circle-fill me-1"></i> Commit Advisory Notes</button>
                    </div>
                </div>
            </form>

            <!-- Interaction history logs -->
            <div class="card border-0 shadow-sm p-4 bg-white rounded-4 text-start">
                <h5 class="fw-bold text-dark mb-3 pb-2 border-bottom"><i class="bi bi-clock-history text-secondary"></i> Interaction History Timeline</h5>
                <?php if (empty($timeline)) { ?>
                    <div class="text-center py-4 text-muted small">No dynamic advisory actions logged inside CRM. Added logs append here perfectly.</div>
                <?php } else { ?>
                    <div class="d-flex flex-column gap-3">
                        <?php foreach (array_reverse($timeline) as $evt) { ?>
                            <div class="p-3 bg-light rounded-3 border-start border-4 border-warning">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <span class="fw-bold text-dark fs-7"><?php echo s($evt['author']); ?> (Representative)</span>
                                    <span class="text-secondary fs-8 mono"><?php echo s($evt['timestamp']); ?></span>
                                </div>
                                <p class="mb-0 small text-secondary">"<?php echo s($evt['note']); ?>"</p>
                            </div>
                        <?php } ?>
                    </div>
                <?php } ?>
            </div>
        </div>

    <!-- 2. HIGH QUALITY PAGINATED LEDGER FOR ALL LEADS -->
    <?php } else { 
        $leads = [];
        if ($db) {
            try {
                $leads = $db->query("SELECT l.*, p.title as property_title 
                                     FROM leads l 
                                     LEFT JOIN properties p ON l.property_id = p.id 
                                     ORDER BY l.id DESC")->fetchAll();
            } catch (Exception $e) {}
        }
        ?>
        <div class="col-12">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <?php if (empty($leads)) { ?>
                    <div class="text-center py-5 text-muted">
                        <i class="bi bi-inboxes fs-1 opacity-25"></i>
                        <h4 class="fw-bold mt-2">CRM Portfolio Database is Empty</h4>
                        <p class="small text-secondary mb-0">Client submissions, site schedules, and manual leads show up here immediately.</p>
                    </div>
                <?php } else { ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 small text-start">
                            <thead>
                                <tr class="table-light">
                                    <th>Client Target Name</th>
                                    <th>Classification</th>
                                    <th>Asset Interest</th>
                                    <th>Status Value</th>
                                    <th>Reminder Target</th>
                                    <th>Submitting Time</th>
                                    <th class="text-end">CRM Controls</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($leads as $l) { ?>
                                    <tr>
                                        <td>
                                            <div class="fw-bold text-dark fs-6"><?php echo s($l['name']); ?></div>
                                            <div class="text-muted text-xs"><?php echo s($l['email']); ?> &bull; <?php echo s($l['phone']); ?></div>
                                        </td>
                                        <td>
                                            <span class="badge border bg-white mt-1 text-uppercase text-secondary" style="font-size: 0.65rem;"><?php echo s($l['type']); ?></span>
                                        </td>
                                        <td>
                                            <span class="text-secondary fw-semibold"><?php echo s($l['property_title'] ?: 'General Advisory Desk'); ?></span>
                                        </td>
                                        <td>
                                            <span class="badge-status status-<?php echo str_replace(' ', '', $l['status']); ?> badge"><?php echo s($l['status']); ?></span>
                                        </td>
                                        <td>
                                            <?php if (!empty($l['reminder_date'])) { ?>
                                                <span class="text-warning fw-bold text-xs d-flex align-items-center gap-1"><i class="bi bi-bell-fill fs-9"></i> <?php echo date('M d, h:i A', strtotime($l['reminder_date'])); ?></span>
                                            <?php } else { ?>
                                                <span class="text-muted text-xs">No Scheduled Followups</span>
                                            <?php } ?>
                                        </td>
                                        <td><span class="text-secondary text-xs mono"><?php echo s($l['created_at']); ?></span></td>
                                        <td class="text-end">
                                            <a href="leads.php?action=edit&id=<?php echo $l['id']; ?>" class="btn btn-sm btn-outline-dark px-3 py-1 text-xs rounded"><i class="bi bi-folder2-open me-1"></i> Edit CRM Profile</a>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                <?php } ?>
            </div>
        </div>
    <?php } ?>
</div>

<?php
render_admin_footer();
?>
