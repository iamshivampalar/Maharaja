<?php
/**
 * ProLandmark Elite - White Label Dynamic Rebranding Console
 * Superb settings board to rewrite company names, styling parameters, palette color schemes, and SEO tags.
 */
require_once '../config.php';

$message = "";
$status_class = "";

if (isset($_POST['save_rebrand'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = "CSRF verification mismatch. Parameters rejected.";
        $status_class = "danger";
    } else {
        $site_name = trim($_POST['site_name'] ?? '');
        $company_name = trim($_POST['company_name'] ?? '');
        $tagline = trim($_POST['tagline'] ?? '');
        $primary_color = trim($_POST['primary_color'] ?? '#0f172a');
        $secondary_color = trim($_POST['secondary_color'] ?? '#1e293b');
        $accent_color = trim($_POST['accent_color'] ?? '#c5a880');
        $font_family = $_POST['font_family'] ?? 'Inter';
        $contact_email = trim($_POST['contact_email'] ?? '');
        $contact_phone = trim($_POST['contact_phone'] ?? '');
        $whatsapp_number = trim($_POST['whatsapp_number'] ?? '');
        $office_address = trim($_POST['office_address'] ?? '');
        $seo_meta_title = trim($_POST['seo_meta_title'] ?? '');
        $seo_meta_description = trim($_POST['seo_meta_description'] ?? '');
        $active_theme = $_POST['active_theme'] ?? 'luxury';
        $maps_embed = $_POST['maps_embed'] ?? '';
        $about_heading = trim($_POST['about_heading'] ?? '');
        $about_body = trim($_POST['about_body'] ?? '');
        $about_history = trim($_POST['about_history'] ?? '');
        $about_mission = trim($_POST['about_mission'] ?? '');
        $about_vision = trim($_POST['about_vision'] ?? '');
        $established_year = trim($_POST['established_year'] ?? '');
        $completed_projects = trim($_POST['completed_projects'] ?? '');
        $capital_reserves = trim($_POST['capital_reserves'] ?? '');

        if (empty($site_name) || empty($company_name) || empty($contact_email)) {
            $message = "Core operational fields (Web Name, Corp Name, Contact Email) are required.";
            $status_class = "warning";
        } else {
            try {
                // Ensure settings record ID #1 exists
                $db->exec("INSERT OR IGNORE INTO site_settings (id, site_name, company_name) VALUES (1, 'Platinum Holdings', 'Platinum Holdings')");
                
                // Update settings parameters
                $up_sql = "UPDATE site_settings SET 
                            site_name=?, company_name=?, tagline=?, primary_color=?, secondary_color=?, accent_color=?, font_family=?,
                            contact_email=?, contact_phone=?, whatsapp_number=?, office_address=?, seo_meta_title=?,
                            seo_meta_description=?, active_theme=?, maps_embed=?,
                            about_heading=?, about_body=?, about_history=?, about_mission=?, about_vision=?, established_year=?, completed_projects=?, capital_reserves=? 
                            WHERE id=1";
                $up_stmt = $db->prepare($up_sql);
                $up_stmt->execute([
                    $site_name, $company_name, $tagline, $primary_color, $secondary_color, $accent_color, $font_family,
                    $contact_email, $contact_phone, $whatsapp_number, $office_address, $seo_meta_title,
                    $seo_meta_description, $active_theme, $maps_embed,
                    $about_heading, $about_body, $about_history, $about_mission, $about_vision, $established_year, $completed_projects, $capital_reserves
                ]);

                // Log system activity change
                log_activity("Rebrand adjustments committed: Applied " . esc_theme_name($active_theme) . " parameters", "Warning");
                set_alert("White-Label Rebranding modifications finalized successfully! Refresh page to apply brand elements.", "success");
                header("Location: rebranding.php");
                exit;
            } catch (Exception $e) {
                $message = "Rebrand write error: " . $e->getMessage();
                $status_class = "danger";
            }
        }
    }
}

// Fetch single settings profile
$stg = null;
if ($db) {
    try {
        $stg = $db->query("SELECT * FROM site_settings WHERE id = 1 LIMIT 1")->fetch();
    } catch (Exception $e) {}
}

function esc_theme_name($theme_slug) {
    switch ($theme_slug) {
        case 'luxury': return 'Monolithic Luxury Dark';
        case 'corporate': return 'Swiss Corporate Navy';
        case 'gold': return 'Royal Imperial Gold';
        default: return ucfirst($theme_slug);
    }
}

render_admin_header("Brand Identity customizer");
?>

<div class="row pt-2 g-4 text-start">
    <div class="col-12 pb-2 border-bottom">
        <h1 class="h3 fw-bold text-dark luxury-heading mb-1"><i class="bi bi-palette-fill text-accent"></i> White-Label Setup & Theme Engine</h1>
        <p class="text-secondary small mb-0">Completely re-configure global brand colors, contact hotlines, dynamic maps, and search-engine schemas.</p>
    </div>

    <!-- Alert Box -->
    <?php if (!empty($message)) { ?>
        <div class="col-12">
            <div class="alert alert-<?php echo $status_class; ?> border-0 shadow-sm rounded-3 py-3 m-0 d-flex align-items-center">
                <i class="bi bi-info-circle-fill fs-5 me-2"></i>
                <div><strong>Identity notice:</strong> <?php echo s($message); ?></div>
            </div>
        </div>
    <?php } ?>

    <div class="col-12">
        <form method="POST" action="" class="card border-0 shadow-sm p-4 bg-white rounded-4">
            <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">

            <div class="row g-4">
                <!-- Administrative Details -->
                <div class="col-lg-6">
                    <h5 class="fw-bold text-dark mb-3 pb-2 border-bottom"><i class="bi bi-card-heading text-accent"></i> Core Brand Names</h5>
                    
                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Web Identity Name</label>
                        <input type="text" name="site_name" value="<?php echo s($stg['site_name'] ?? 'Platinum Holdings'); ?>" class="form-control border bg-light py-2" placeholder="e.g. Platinum Holdings" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Parent Company Legal Name</label>
                        <input type="text" name="company_name" value="<?php echo s($stg['company_name'] ?? 'Platinum Holdings Real Estate Group'); ?>" class="form-control border bg-light py-2" placeholder="e.g. Platinum Holdings Group Ltd" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Aesthetic Tagline Banner</label>
                        <input type="text" name="tagline" value="<?php echo s($stg['tagline'] ?? 'Elite Real Estate Assets'); ?>" class="form-control border bg-light py-2" placeholder="e.g. Developer direct acquisitions">
                    </div>
                </div>

                <!-- Color Palette Customizer -->
                <div class="col-lg-6">
                    <h5 class="fw-bold text-dark mb-3 pb-2 border-bottom"><i class="bi bi-paint-bucket text-accent"></i> Style Palette Customizer</h5>
                    
                    <div class="row g-2">
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold text-secondary">Primary Color</label>
                            <input type="color" name="primary_color" value="<?php echo s($stg['primary_color'] ?? '#0f172a'); ?>" class="form-control border bg-light py-1" style="height:40px;">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold text-secondary">Secondary Color</label>
                            <input type="color" name="secondary_color" value="<?php echo s($stg['secondary_color'] ?? '#1e293b'); ?>" class="form-control border bg-light py-1" style="height:40px;">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small fw-semibold text-secondary">Accent Branding</label>
                            <input type="color" name="accent_color" value="<?php echo s($stg['accent_color'] ?? '#c5a880'); ?>" class="form-control border bg-light py-1" style="height:40px;">
                        </div>
                    </div>

                    <div class="row g-2 mt-2">
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-secondary">Theme Accent Preset</label>
                            <select name="active_theme" class="form-select border bg-light py-2">
                                <option value="luxury" <?php echo (($stg['active_theme'] ?? '') === 'luxury') ? 'selected' : ''; ?>>Monolithic Imperial Charcoal</option>
                                <option value="corporate" <?php echo (($stg['active_theme'] ?? '') === 'corporate') ? 'selected' : ''; ?>>Swiss Corporate Navy</option>
                                <option value="gold" <?php echo (($stg['active_theme'] ?? '') === 'gold') ? 'selected' : ''; ?>>Royal Prestige Gold</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-semibold text-secondary">Core Font Family</label>
                            <select name="font_family" class="form-select border bg-light py-2">
                                <option value="Inter" <?php echo (($stg['font_family'] ?? '') === 'Inter') ? 'selected' : ''; ?>>Inter (Sans-Serif Clean UI)</option>
                                <option value="Playfair Display" <?php echo (($stg['font_family'] ?? '') === 'Playfair Display') ? 'selected' : ''; ?>>Playfair Display (Serif Classic Luxury)</option>
                                <option value="Space Grotesk" <?php echo (($stg['font_family'] ?? '') === 'Space Grotesk') ? 'selected' : ''; ?>>Space Grotesk (Tech Modern)</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Communications Directory -->
                <div class="col-12 mt-4">
                    <h5 class="fw-bold text-dark mb-3 pb-2 border-bottom"><i class="bi bi-telephone-inbound text-accent"></i> Global Communications Directory</h5>
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold text-secondary">Official Advisory Email</label>
                    <input type="email" name="contact_email" value="<?php echo s($stg['contact_email'] ?? 'contact@elitepartners.com'); ?>" class="form-control border bg-light py-2" placeholder="e.g. desk@parentbrand.com" required>
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold text-secondary">Voice Advisory Hotline</label>
                    <input type="text" name="contact_phone" value="<?php echo s($stg['contact_phone'] ?? '+1 (800) 555-0199'); ?>" class="form-control border bg-light py-2" placeholder="e.g. +18005550200">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold text-secondary">WhatsApp Advisory Raw API Digits (Exclude symbols)</label>
                    <input type="text" name="whatsapp_number" value="<?php echo s($stg['whatsapp_number'] ?? '18005550200'); ?>" class="form-control border bg-light py-2" placeholder="e.g. 18005550200">
                </div>

                <div class="col-12">
                    <label class="form-label small fw-semibold text-secondary">Corporate Main Headquarters Address</label>
                    <input type="text" name="office_address" value="<?php echo s($stg['office_address'] ?? '742 Platinum Boulevard, Tower A, Elite Metropolis'); ?>" class="form-control border bg-light py-2" placeholder="Street, block, City, State...">
                </div>

                <div class="col-12">
                    <label class="form-label small fw-semibold text-secondary">Integrated Google Maps Embed Source (Paste custom iframe embed node)</label>
                    <textarea name="maps_embed" class="form-control border bg-light" rows="3" placeholder="<iframe src='https://maps.google.com/...'></iframe>"><?php echo s($stg['maps_embed'] ?? ''); ?></textarea>
                </div>

                <!-- SEO Control Console -->
                <div class="col-12 mt-4">
                    <h5 class="fw-bold text-dark mb-3 pb-2 border-bottom"><i class="bi bi-globe2 text-accent"></i> Dynamic Search Engine Optimization (SEO Schema)</h5>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold text-secondary">Web Index Schema Title</label>
                    <input type="text" name="seo_meta_title" value="<?php echo s($stg['seo_meta_title'] ?? 'Platinum Holdings - Curated Real Estate'); ?>" class="form-control border bg-light py-2" placeholder="SEO Master title tags...">
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold text-secondary">Dynamic Schema Description Tag</label>
                    <input type="text" name="seo_meta_description" value="<?php echo s($stg['seo_meta_description'] ?? 'Ultra-private luxury real estate assets and direct developer acquisitions.'); ?>" class="form-control border bg-light py-2" placeholder="Custom google searches description content...">
                </div>

                <!-- About Us Custom Editor -->
                <div class="col-12 mt-4">
                    <h5 class="fw-bold text-dark mb-3 pb-2 border-bottom"><i class="bi bi-info-circle-fill text-accent"></i> Dynamic About Us & Corporate Information Customizer</h5>
                </div>

                <div class="col-12">
                    <label class="form-label small fw-semibold text-secondary">About Segment Heading Title</label>
                    <input type="text" name="about_heading" value="<?php echo s($stg['about_heading'] ?? 'Direct Developers of Sovereign Real Estate Assets'); ?>" class="form-control border bg-light py-2" placeholder="e.g. Master Builders of Pristine Civics">
                </div>

                <div class="col-lg-6">
                    <label class="form-label small fw-semibold text-secondary">Corporate Core Introduction</label>
                    <textarea name="about_body" class="form-control border bg-light" rows="5" placeholder="Introduction statement for the direct-ownership developer business model..."><?php echo s($stg['about_body'] ?? ''); ?></textarea>
                </div>

                <div class="col-lg-6">
                    <label class="form-label small fw-semibold text-secondary">Corporate Historical Context & Heritage</label>
                    <textarea name="about_history" class="form-control border bg-light" rows="5" placeholder="Detailing the founding year, path taken, code of ethics..."><?php echo s($stg['about_history'] ?? ''); ?></textarea>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold text-secondary">Corporate Mission Statement</label>
                    <input type="text" name="about_mission" value="<?php echo s($stg['about_mission'] ?? 'To engineer zero-commission, direct-to-owner premium acquisitions that establish long-term security, spatial majesty, and absolute pricing honesty.'); ?>" class="form-control border bg-light py-2" placeholder="Mission statement...">
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold text-secondary">Corporate Vision Statement</label>
                    <input type="text" name="about_vision" value="<?php echo s($stg['about_vision'] ?? 'To stand as the world\'s most trusted luxury direct developer, setting the benchmark for sovereign asset safety and carbon-conscious structural logic.'); ?>" class="form-control border bg-light py-2" placeholder="Vision statement...">
                </div>

                <!-- Performance Stat Badges -->
                <div class="col-md-4">
                    <label class="form-label small fw-semibold text-secondary">Established Year Badge</label>
                    <input type="text" name="established_year" value="<?php echo s($stg['established_year'] ?? '2008'); ?>" class="form-control border bg-light py-2" placeholder="e.g. 2008">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold text-secondary">Completed Developments Vol</label>
                    <input type="text" name="completed_projects" value="<?php echo s($stg['completed_projects'] ?? '42 Capital Developments'); ?>" class="form-control border bg-light py-2" placeholder="e.g. 42 Capital Developments">
                </div>

                <div class="col-md-4">
                    <label class="form-label small fw-semibold text-secondary">Capital Reserves Volume</label>
                    <input type="text" name="capital_reserves" value="<?php echo s($stg['capital_reserves'] ?? '$1.2B Sovereign Capital'); ?>" class="form-control border bg-light py-2" placeholder="e.g. $1.2B Sovereign Capital">
                </div>

                <!-- Action form buttons -->
                <div class="col-12 mt-5 border-top pt-4 text-end">
                    <button type="submit" name="save_rebrand" class="btn btn-dark rounded-3 px-4 py-2.5 fw-bold"><i class="bi bi-shield-check-fill me-1"></i> Apply Global Rebrand Parameters</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php
render_admin_footer();
?>
