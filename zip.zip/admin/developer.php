<?php
/**
 * ProLandmark Elite - Principal Architect Developer Console
 * Secure terminal presenting: dynamic database query testing, system metrology diagnostics, and security logs.
 */
require_once '../config.php';

// Safe lock: ensure role is authorized Developer
require_developer();

$query_result = null;
$query_error = "";
$executed_sql = "";

// SQL Query Console executor
if (isset($_POST['execute_sql'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $query_error = "CSRF Verification challenge rejected.";
    } else {
        $raw_sql = trim($_POST['raw_sql'] ?? '');
        $executed_sql = $raw_sql;

        if (empty($raw_sql)) {
            $query_error = "SQL instruction string cannot be empty.";
        } else {
            // Anti destruction parsing filter for security safety inside sandbox
            $uppercase_sql = strtoupper($raw_sql);
            if (strpos($uppercase_sql, 'DROP ') !== false || strpos($uppercase_sql, 'TRUNCATE ') !== false) {
                $query_error = "Console Policy Block: Structural DROP or TRUNCATE commands are forbidden in terminal.";
            } else {
                try {
                    $q_stmt = $db->query($raw_sql);
                    if ($q_stmt) {
                        if (strpos($uppercase_sql, 'SELECT') === 0 || strpos($uppercase_sql, 'PRAGMA') === 0) {
                            $query_result = $q_stmt->fetchAll();
                        } else {
                            $query_result = "Instruction executed successfully. Affected row count: " . $q_stmt->rowCount();
                        }
                        log_activity("Developer executed manual query console expression", "Warning");
                    }
                } catch (Exception $e) {
                    $query_error = $e->getMessage();
                }
            }
        }
    }
}

// Clear system security logs route
if (isset($_POST['clear_logs'])) {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        try {
            $db->exec("DELETE FROM activity_logs");
            log_activity("Security logs purged by Principal Architect", "Warning");
            set_alert("Security and audit databases successfully cleared.", "success");
            header("Location: developer.php");
            exit;
        } catch (Exception $e) {}
    }
}

// Fetch security logs list
$logs = [];
if ($db) {
    try {
        $logs = $db->query("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 50")->fetchAll();
    } catch (Exception $e) {}
}

render_admin_header("Developer Command Terminal");
?>

<div class="row pt-2 g-4 text-start">
    <div class="col-12 pb-2 border-bottom">
        <h1 class="h3 fw-bold text-dark luxury-heading mb-1"><i class="bi bi-terminal-fill text-warning"></i> Developer Command Terminal</h1>
        <p class="text-secondary small mb-0 font-sans">Principal Architect diagnostics terminal. Interrogate relational tables, audit network security logs, and monitor system servers.</p>
    </div>

    <!-- Metrology Dashboard Blocks -->
    <div class="col-12 text-start">
        <div class="row g-3">
            <div class="col-md-3">
                <div class="card p-3 shadow-sm border rounded-3 bg-white">
                    <span class="text-secondary small text-uppercase">Runtime Core</span>
                    <strong class="text-dark fs-5 mt-1 block">PHP <?php echo phpversion(); ?></strong>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 shadow-sm border rounded-3 bg-white">
                    <span class="text-secondary small text-uppercase">Memory Limit</span>
                    <strong class="text-dark fs-5 mt-1 block"><?php echo ini_get('memory_limit'); ?></strong>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 shadow-sm border rounded-3 bg-white">
                    <span class="text-secondary small text-uppercase">Database Driver</span>
                    <strong class="text-success fs-5 mt-1 block"><i class="bi bi-database-check"></i> PDO Active</strong>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3 shadow-sm border rounded-3 bg-white">
                    <span class="text-secondary small text-uppercase">Direct Land Registries</span>
                    <strong class="text-dark fs-5 mt-1 block">10 Tables Configured</strong>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <!-- Interactive SQL Query Console -->
        <div class="card border-0 shadow-sm p-4 bg-white rounded-4 mb-4">
            <h5 class="fw-bold mb-3 text-dark pb-2 border-bottom"><i class="bi bi-code-square text-accent"></i> Relational SQLite/MySQL Query Terminal</h5>
            <p class="text-secondary small">Interrogate state settings or category tables instantly. Strictly SELECT queries or non-destructive adjustments are supported.</p>

            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                
                <div class="mb-3">
                    <label class="form-label small text-secondary fw-semibold">SQL Instruction Block</label>
                    <textarea name="raw_sql" class="form-control bg-dark text-light border-0 py-2.5 rounded-3 mono" rows="5" style="font-size:0.8rem; line-height:1.45;" placeholder="SELECT * FROM site_settings LIMIT 1;"><?php echo s($executed_sql ?: 'SELECT * FROM site_settings LIMIT 1;'); ?></textarea>
                </div>

                <div class="text-end">
                    <button type="submit" name="execute_sql" class="btn btn-dark rounded-3 px-3.5"><i class="bi bi-lightning-fill text-warning me-1"></i> Run SQL Instruction</button>
                </div>
            </form>

            <?php if (!empty($query_error)) { ?>
                <div class="alert alert-danger border-0 rounded-3 mt-3 py-2.5 small">
                    <strong class="font-bold d-block mb-1">Execution Failure:</strong>
                    <code class="text-danger"><?php echo s($query_error); ?></code>
                </div>
            <?php } ?>

            <?php if ($query_result !== null) { ?>
                <div class="mt-4">
                    <h6 class="fw-bold text-dark mb-2">Relational Command Returns:</h6>
                    <div class="bg-light border rounded-3 p-3 overflow-auto text-start" style="max-height: 250px;">
                        <?php if (is_string($query_result)) { ?>
                            <pre class="mb-0 small mono text-success"><?php echo s($query_result); ?></pre>
                        <?php } elseif (empty($query_result)) { ?>
                            <span class="small text-muted mono">Query completed. Returns empty dataset (0 rows).</span>
                        <?php } else { ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-sm align-middle mb-0 text-xs mono">
                                    <thead>
                                        <tr class="table-dark">
                                            <?php foreach (array_keys($query_result[0]) as $col) { echo "<th>" . s($col) . "</th>"; } ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($query_result as $row) { ?>
                                            <tr>
                                                <?php foreach ($row as $val) { echo "<td>" . s($val) . "</td>"; } ?>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

    <!-- Security Audits Registry log table -->
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm p-4 bg-white rounded-4 h-full">
            <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                <h5 class="fw-bold m-0 text-dark"><i class="bi bi-shield-lock-fill text-danger"></i> System Security & Action Audit Logs</h5>
                <form method="POST" action="" onsubmit="return confirm('Purge entire active audit logs registry?');">
                    <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                    <button type="submit" name="clear_logs" class="btn btn-xs btn-outline-danger px-2.5 py-1 text-xs rounded">Purge logs</button>
                </form>
            </div>

            <?php if (empty($logs)) { ?>
                <div class="text-center py-5 text-muted small">
                    <i class="bi bi-shield-check fs-1 text-success block opacity-35 mb-2"></i>
                    No security violations or administrator actions logged on this shard.
                </div>
            <?php } else { ?>
                <div class="overflow-auto border rounded-3 text-start" style="max-height: 400px; background-color:#fafafa;">
                    <div class="d-flex flex-column gap-0.5">
                        <?php foreach ($logs as $log) { 
                            $bg_badge = 'bg-secondary';
                            if ($log['severity'] === 'Warning') $bg_badge = 'bg-warning text-dark';
                            if ($log['severity'] === 'Error') $bg_badge = 'bg-danger';
                            ?>
                            <div class="p-2.5 border-bottom small d-flex flex-column gap-1 bg-white">
                                <div class="d-flex justify-content-between align-items-center flex-wrap">
                                    <span class="fw-bold text-dark"><?php echo s($log['user_name']); ?></span>
                                    <span class="text-muted text-xs mono"><?php echo s($log['created_at']); ?></span>
                                </div>
                                <div class="d-flex justify-content-between align-items-start gap-2 flex-wrap">
                                    <span class="text-secondary" style="font-size: 0.85rem;">&bull; <?php echo s($log['action_performed']); ?></span>
                                    <span class="badge <?php echo $bg_badge; ?> fs-10" style="font-size: 0.65rem;"><?php echo s($log['severity']); ?></span>
                                </div>
                                <span class="text-muted text-xs font-mono" style="font-size: 0.68rem;"><i class="bi bi-globe"></i> IP: <?php echo s($log['ip_address']); ?></span>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>

<?php
render_admin_footer();
?>
