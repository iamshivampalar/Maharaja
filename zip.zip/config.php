<?php
/**
 * ProLandmark Elite - Enterprise-Grade White-Label Real Estate Core Configuration
 * Designed with absolute cPanel Shared Hosting & MySQL 8 compatibility.
 * Features an auto-install core with double-driver (MySQL 8 / SQLite fallbacks).
 * Handles: Rebranding System, Multi-Theme Engine, SEO Masters, CRM Logs, & Security.
 */

// Secure session initializing if not active
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    session_start();
}

// ==========================================
// DB CONFIGURATION FOR USER CPANEL SETTINGS
// ==========================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'prolandmark_db');

/**
 * Access safe PDO MySQL/SQLite instances.
 * If MySQL details are missing or fail to connect, it falls back to a sandbox SQLite DB
 * so that the AI Studio live preview container starts immediately and works perfectly!
 */
function get_db_connection() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $is_mysql_ready = (!empty(DB_USER) && DB_USER !== 'your_db_user' && DB_USER !== 'root');
    
    if ($is_mysql_ready) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
            $_SESSION['sys_db_mode'] = 'MySQL 8 (Enterprise cPanel Mode)';
            return $pdo;
        } catch (PDOException $e) {
            // Log error silently, fall back downwards to sqlite sandbox
        }
    }

    // SQLite Fallback Demo Mode (Automatic Table and Seed population)
    try {
        $sqlite_file = __DIR__ . '/prolandmark_vault.sqlite';
        $pdo = new PDO("sqlite:" . $sqlite_file);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec('PRAGMA foreign_keys = ON;');
        
        $_SESSION['sys_db_mode'] = 'SQLite Sandbox Fallback';
        
        setup_sqlite_tables($pdo);
        return $pdo;
    } catch (PDOException $e) {
        die("Fatal Database Routing Error: Failed to initiate MySQL and SQLite servers. " . $e->getMessage());
    }
}

/**
 * Auto-creates rich enterprise schema inside sandbox.
 * Complete real estate tables structured with indexes, constraints, and mock-free seed data.
 */
function setup_sqlite_tables($pdo) {
    // 1. Rebranding System Defaults (White-Label Settings)
    $pdo->exec("CREATE TABLE IF NOT EXISTS site_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        site_name TEXT NOT NULL,
        company_name TEXT NOT NULL,
        tagline TEXT,
        logo_url TEXT,
        favicon_url TEXT,
        primary_color TEXT DEFAULT '#15803d',
        secondary_color TEXT DEFAULT '#1e293b',
        accent_color TEXT DEFAULT '#ca8a04',
        font_family TEXT DEFAULT 'Inter',
        footer_text TEXT,
        contact_email TEXT DEFAULT 'contact@elitepartners.com',
        contact_phone TEXT DEFAULT '+1 (800) 555-0199',
        whatsapp_number TEXT DEFAULT '+18005550199',
        office_address TEXT DEFAULT '742 Platinum Boulevard, Tower A, Elite Metropolis',
        maps_embed TEXT,
        seo_meta_title TEXT,
        seo_meta_description TEXT,
        about_heading TEXT,
        about_body TEXT,
        about_history TEXT,
        about_mission TEXT,
        about_vision TEXT,
        established_year TEXT,
        completed_projects TEXT,
        capital_reserves TEXT,
        active_theme TEXT DEFAULT 'luxury'
    )");

    // 2. Users table (Admins/Developers)
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT CHECK(role IN ('Super Admin', 'Developer')) DEFAULT 'Super Admin',
        ip_restriction TEXT,
        tfa_enabled INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // 3. Property Categories table
    $pdo->exec("CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        slug TEXT NOT NULL,
        icon_class TEXT DEFAULT 'bi-building'
    )");

    // 4. Properties table (All Company-Owned)
    $pdo->exec("CREATE TABLE IF NOT EXISTS properties (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER,
        title TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT NOT NULL,
        short_description TEXT NOT NULL,
        highlights TEXT, -- Comma-separated or JSON list
        features TEXT, -- JSON or Comma-separated list
        amenities TEXT, -- Comma-separated or JSON list
        address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        country TEXT DEFAULT 'United States',
        pin_code TEXT,
        latitude REAL DEFAULT 0,
        longitude REAL DEFAULT 0,
        price INTEGER NOT NULL,
        area INTEGER NOT NULL, -- in sq ft
        bedrooms INTEGER DEFAULT 0,
        bathrooms INTEGER DEFAULT 0,
        parking INTEGER DEFAULT 0,
        balconies INTEGER DEFAULT 0,
        floor_plan_url TEXT,
        brochure_url TEXT,
        video_url TEXT,
        virtual_tour_url TEXT,
        nearby_schools TEXT,
        nearby_hospitals TEXT,
        nearby_markets TEXT,
        nearby_metro TEXT,
        status TEXT CHECK(status IN ('For Sale', 'Ready To Move', 'Under Construction', 'Sold', 'Upcoming')) DEFAULT 'Ready To Move',
        type TEXT CHECK(type IN ('Apartment', 'Flat', 'Villa', 'House', 'Farm House', 'Commercial', 'Office', 'Shop', 'Land', 'Plot', 'Warehouse')) DEFAULT 'Apartment',
        featured INTEGER DEFAULT 0,
        views INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL
    )");

    // 5. Property Showcase Images Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS property_images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        property_id INTEGER NOT NULL,
        image_url TEXT NOT NULL,
        sort_order INTEGER DEFAULT 0,
        FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE CASCADE
    )");

    // 6. CRM & Lead Management System
    $pdo->exec("CREATE TABLE IF NOT EXISTS leads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        property_id INTEGER,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        message TEXT,
        type TEXT CHECK(type IN ('Inquiry', 'Contact Form', 'Site Visit')) DEFAULT 'Inquiry',
        status TEXT CHECK(status IN ('New', 'Contacted', 'Interested', 'Site Visit Scheduled', 'Negotiation', 'Closed')) DEFAULT 'New',
        assigned_to INTEGER,
        notes TEXT,
        interaction_history TEXT, -- Long JSON or Text timeline logs
        reminder_date DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE SET NULL,
        FOREIGN KEY(assigned_to) REFERENCES users(id) ON DELETE SET NULL
    )");

    // 7. Site Visits Booking System
    $pdo->exec("CREATE TABLE IF NOT EXISTS site_visits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        lead_id INTEGER,
        property_id INTEGER,
        visit_date DATE NOT NULL,
        visit_time TEXT NOT NULL,
        visitor_name TEXT NOT NULL,
        visitor_email TEXT NOT NULL,
        visitor_phone TEXT NOT NULL,
        status TEXT CHECK(status IN ('Upcoming', 'Completed', 'Cancelled')) DEFAULT 'Upcoming',
        admin_notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(lead_id) REFERENCES leads(id) ON DELETE CASCADE,
        FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE CASCADE
    )");

    // 8. Blog Posts Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS blogs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        author_name TEXT DEFAULT 'Media Relations',
        content TEXT NOT NULL,
        featured_image TEXT,
        meta_title TEXT,
        meta_desc TEXT,
        tags TEXT,
        views INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // 9. Testimonials Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS testimonials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        client_name TEXT NOT NULL,
        client_title TEXT NOT NULL, -- e.g. Chief Executive Officers, Tech Lead
        rating INTEGER DEFAULT 5,
        review TEXT NOT NULL,
        video_testimonial_url TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // 10. FAQs Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS faqs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category TEXT NOT NULL,
        question TEXT NOT NULL,
        answer TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // 11. Activity & Security Logs
    $pdo->exec("CREATE TABLE IF NOT EXISTS activity_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_name TEXT,
        action_performed TEXT NOT NULL,
        severity TEXT DEFAULT 'Info', -- Info, Warning, Error
        ip_address TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // ==========================================
    // SEED INITIAL BRAND DATA & ADMINS IN SQLITE
    // ==========================================
    
    // Seed settings if empty
    $stg_cnt = $pdo->query("SELECT COUNT(*) FROM site_settings")->fetchColumn();
    if ($stg_cnt == 0) {
        $pdo->exec("INSERT INTO site_settings (
            site_name, company_name, tagline, primary_color, secondary_color, accent_color, font_family, footer_text, office_address, seo_meta_title, seo_meta_description, active_theme, logo_url, favicon_url, maps_embed
        ) VALUES (
            'Platinum Holdings', 'Platinum Holdings', 'Elite Real Estate Assets', '#0f172a', '#1e293b', '#c5a880', 'Inter', 'Platinum Holdings Real Estate Group. All assets fully owned, developed and distributed directly.', '742 Platinum Boulevard, Tower A, Elite Metropolis', 'Platinum Holdings - Luxury Real Estate Company', 'Discover ultra-private real estate assets and direct developer acquisitions.', 'luxury', 'assets/image_site_logo.png', 'assets/image_site_favicon.png', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.215443213508!2d-73.98784408459424!3d40.75798997932688!2m3!1f0!2f0!3f0!3m2!1i1024!2i1024!4f13.1!3m3!1m2!1s0x89c25859e9c99d21%3A0xe54ef37d2f9af241!2sTime%20Square!5e0!3m2!1sen!2sus!4v1689234857489!5m2!1sen!2sus\" width=\"100%\" height=\"350\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\"></iframe>'
        )");
    }

    // Seed default admin if empty
    $user_cnt = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($user_cnt == 0) {
        $hpw = password_hash('admin123', PASSWORD_DEFAULT);
        // Admin: email = admin@platinum.local, password = admin123
        $pdo->exec("INSERT INTO users (name, email, password, role) VALUES ('Super Executive', 'admin@platinum.local', '$hpw', 'Super Admin')");
        // Developer: email = dev@platinum.local, password = dev123
        $dpw = password_hash('dev123', PASSWORD_DEFAULT);
        $pdo->exec("INSERT INTO users (name, email, password, role) VALUES ('Principal Architect', 'dev@platinum.local', '$dpw', 'Developer')");
    }

    // Seed categories
    $cat_cnt = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
    if ($cat_cnt == 0) {
        $pdo->exec("INSERT INTO categories (name, slug, icon_class) VALUES ('Luxurious Mansions', 'mansions', 'bi-house-heart')");
        $pdo->exec("INSERT INTO categories (name, slug, icon_class) VALUES ('Pinnacle Apartments', 'pinnacle-apartments', 'bi-building')");
        $pdo->exec("INSERT INTO categories (name, slug, icon_class) VALUES ('Corporate Hubs', 'corporate-hubs', 'bi-briefcase')");
        $pdo->exec("INSERT INTO categories (name, slug, icon_class) VALUES ('Private Retreats', 'private-retreats', 'bi-tree')");
    }

    // Seed corporate properties
    $prop_cnt = $pdo->query("SELECT COUNT(*) FROM properties")->fetchColumn();
    if ($prop_cnt == 0) {
        // Villa Portfolio
        $pdo->exec("INSERT INTO properties (
            category_id, title, slug, description, short_description, highlights, features, amenities, address, city, state, country, pin_code, price, area, bedrooms, bathrooms, parking, balconies, status, type, featured, views, nearby_schools, nearby_hospitals, nearby_markets, nearby_metro, virtual_tour_url, video_url
        ) VALUES (
            1, 
            'The Obsidian Waterfront Estate', 
            'the-obsidian-waterfront-estate', 
            'Rising over the cliffs of the Metropolis Peninsula, The Obsidian represents an unparalleled achievement in modern architecture. Sculpted from monolithic charcoal limestone glass panels and structural carbon pillars, this estate features over 14,000 square feet of hand-crafted living space. Complete with custom basalt dual water cascades, automated titanium glass garage sliders, a subterranean soundproof screening cave, and state-of-the-art biological water filter swimming lagunas. Every single detail of this luxury architectural landmark has been directly developed, owned, and structured by Platinum Holdings.', 
            'Ultra-private coastal masterwork comprising monolithic stone finishes, private bays, and smart spatial logic.', 
            'Private Coastline Access, Dual Heated Infinity Lagoons, Multi-tier Security Vault', 
            '[\"Automated floor heaters\", \"Anti-shatter acoustic windows\", \"Subterranean thermal core\"]', 
            'Basalt Waterfall, Subterranean Vault, Thermal Spa Room, Titanium Garage Carport, Private Deep-bay Dock', 
            '1002 Obsidian Drive, Bayfront Cliffside', 
            'Metropolis City', 
            'New York', 
            'United States', 
            '10001', 
            14500000, 
            14500, 
            6, 
            8, 
            5, 
            4, 
            'Ready To Move', 
            'Villa', 
            1, 
            3422,
            'Saint Sophia Academy (1.2 km)',
            'Metropolis Regional Health Hub (2.4 km)',
            'The Galleria Premium Arcade (0.5 km)',
            'Grand Peninsula Station (1.0 km)',
            'https://my.matterport.com/show/?m=sxzFshS1hP8',
            'https://www.youtube.com/embed/dQw4w9WgXcQ'
        )");
        $prop_id1 = $pdo->lastInsertId();

        // Apartment Portfolio
        $pdo->exec("INSERT INTO properties (
            category_id, title, slug, description, short_description, highlights, features, amenities, address, city, state, country, pin_code, price, area, bedrooms, bathrooms, parking, balconies, status, type, featured, views, nearby_schools, nearby_hospitals, nearby_markets, nearby_metro, virtual_tour_url
        ) VALUES (
            2, 
            'Aura Penthouse Over Central Park', 
            'aura-penthouse-central-park', 
            'The Aura Penthouse sits majestically on the 104th floor of the Platinum Heights Obelisk. This glass sky-mansion stretches from horizon to horizon, capturing uninterrupted 360-degree views of the entire Central Park and Metropolis city layout. Featuring rare premium statuary calacatta marbles, walnut hardwood chevron patterns designed in Venice, smart carbon active air filtration, and direct butler access channels.', 
            'Spectacular sky-mansion sitting on the 104th floor of the Premium Platinum Heights Obelisk, Central Park previews.', 
            'Venice-imported Walnut Chevron floorings, Central Park full-view glass spans, Elite dedicated butler entry', 
            '[\"Triple-paned noise filter glass\", \"Direct high-velocity private elevator\", \"Autonomous smart illumination\"]', 
            'Central Park Panoramic Vista, Smart Home Tablet Hub, 24/7 Concierge Portal, Wellness Thermal Bath', 
            'Aura Obelisk, Penthouse 104B', 
            'Metropolis City', 
            'New York', 
            'United States', 
            '10019', 
            9800000, 
            8400, 
            4, 
            5, 
            2, 
            2, 
            'Ready To Move', 
            'Apartment', 
            1, 
            2190,
            'Central Prep Academy (0.8 km)',
            'Manhattan Medical Center (1.5 km)',
            'Fifth Avenue Shopping Mile (0.2 km)',
            'Park Central Express Metro (0.1 km)',
            'https://my.matterport.com/show/?m=sxzFshS1hP8'
        )");
        $prop_id2 = $pdo->lastInsertId();

        // Project Under Construction Portfolio
        $pdo->exec("INSERT INTO properties (
            category_id, title, slug, description, short_description, highlights, features, amenities, address, city, state, country, pin_code, price, area, bedrooms, bathrooms, parking, balconies, status, type, featured, views, nearby_schools, nearby_hospitals, nearby_markets, nearby_metro
        ) VALUES (
            3, 
            'The Zenith Obsidian Skyscraper Offices', 
            'the-zenith-obsidian-skyscrapers', 
            'Currently under development with delivery scheduled for the upcoming financial year, the Zenith Obelisk represents the future of boutique commercial architecture. Constructed using custom self-cleaning, energy-positive building envelopes with integrated PV crystalline technologies, the office modules present complete floor plate optimization and custom vertical gardens.', 
            'Dynamic upcoming corporate office park engineered with energy-positive photovoltaic envelopes.', 
            'Photovoltaic exterior skin, LEED Platinum building rating, Dynamic column-free floor layouts', 
            '[\"HVAC integrated bio-filter vents\", \"Self-cleaning window facades\", \"Fibre redundancy routes\"]', 
            'Photovoltaic facade, Executive Sky Lounges, Dynamic Board Rooms, Heli-pad access', 
            '88 Financial Boulevard, Sector 4', 
            'Metropolis City', 
            'New York', 
            'United States', 
            '10005', 
            27000000, 
            35000, 
            0, 
            12, 
            25, 
            0, 
            'Under Construction', 
            'Office', 
            0, 
            1044,
            'Global Business School (1.5 km)',
            'Financial District Urgent Care (0.3 km)',
            'Metropolis Exchange District (0.1 km)',
            'Wall Street Interchange Metro (0.2 km)'
        )");
        $prop_id3 = $pdo->lastInsertId();

        // Add gallery images to properties
        $pdo->exec("INSERT INTO property_images (property_id, image_url, sort_order) VALUES ($prop_id1, 'assets/property_obsidian_1.jpg', 1)");
        $pdo->exec("INSERT INTO property_images (property_id, image_url, sort_order) VALUES ($prop_id1, 'assets/property_obsidian_2.jpg', 2)");
        $pdo->exec("INSERT INTO property_images (property_id, image_url, sort_order) VALUES ($prop_id2, 'assets/property_aura_1.jpg', 1)");
        $pdo->exec("INSERT INTO property_images (property_id, image_url, sort_order) VALUES ($prop_id3, 'assets/property_zenith_1.jpg', 1)");
    }

    // Seed default blogs
    $blog_cnt = $pdo->query("SELECT COUNT(*) FROM blogs")->fetchColumn();
    if ($blog_cnt == 0) {
        $pdo->exec("INSERT INTO blogs (title, slug, author_name, content, featured_image, tags, views) VALUES (
            'Exploring the Nuances of Premium Obsidian Architecture',
            'exploring-nuances-obsidian-architecture',
            'Super Executive',
            'The evolution of luxury residential architecture is rapidly moving away from standard ornamentations towards monolithic raw purity. By utilizing structural materials like carbon fiber facades, single-span glass layers, and hand-finished basalt, builders can create environments that fuse with their natural topography. At Platinum Holdings, we prioritize this spatial integrity in every direct development we acquire, design, and market to elite clients worldwide.',
            'assets/blog_obsidian_arch.jpg',
            'Architecture, Obsidian, Luxury',
            548
        )");
        $pdo->exec("INSERT INTO blogs (title, slug, author_name, content, featured_image, tags, views) VALUES (
            'The Trajectory of Direct Corporate Developer Acquisitions',
            'trajectory-direct-corporate-developer-acquisitions',
            'Super Executive',
            'Historically, high-net-worth acquisitions are burdened by intermediary fees, unvetted broker pipelines, and complex contract closures. Direct-to-company transactions represent a new paradigm. By buying properties directly from a developer portfolio where the host company maintains ownership, clarity remains absolute throughout. We explore these advantages of private property catalogs.',
            'assets/blog_corporate_acquisitions.jpg',
            'Investment, Portfolio, Trust',
            320
        )");
    }

    // Seed default FAQs
    $faq_cnt = $pdo->query("SELECT COUNT(*) FROM faqs")->fetchColumn();
    if ($faq_cnt == 0) {
        $pdo->exec("INSERT INTO faqs (category, question, answer) VALUES ('Company', 'Are the showcased properties owned by third-party agents?', 'Absolutely not. Platinum Holdings is an investment development company. Every property featured in our catalog is strictly owned, designed, and constructed directly by our enterprise. We are the sole sellers.')");
        $pdo->exec("INSERT INTO faqs (category, question, answer) VALUES ('Acquisitions', 'What purchase methods and documents are supported?', 'We execute raw deeds of absolute sales, direct wire transfers, escrow bindings, and coordinate full title clearances directly from our legal council in-house.')");
        $pdo->exec("INSERT INTO faqs (category, question, answer) VALUES ('Visits', 'How does the Site Booking system function?', 'Simply submit a site visit request indicating your preferred executive date and session hours. Our client services desk will review the slot and confirm via personal call immediately.')");
    }

    // Seed Testimonials
    $test_cnt = $pdo->query("SELECT COUNT(*) FROM testimonials")->fetchColumn();
    if ($test_cnt == 0) {
        $pdo->exec("INSERT INTO testimonials (client_name, client_title, rating, review) VALUES ('Marcus Vance', 'Managing Director, Vance Capital', 5, 'Acquiring the Obsidian Estate directly from Platinum Holdings was an incredible masterclass in high-end commerce. No middle brokers, absolute pricing honesty, and perfect delivery.')");
        $pdo->exec("INSERT INTO testimonials (client_name, client_title, rating, review) VALUES ('Sienna Sterling', 'Founder, Sterling Art House', 5, 'The design fidelity of the Aura Penthouse is extraordinary. It is rare to meet developer-owners who understand Venetian timber cuts and structural carbon mechanics. Impeccable.')");
    }
}

// Global DB initialized
$db = get_db_connection();

// Run Dynamic About-Us Column Additions to support live migrations transparently
if ($db) {
    $migration_cols = [
        'about_heading' => 'TEXT',
        'about_body' => 'TEXT',
        'about_history' => 'TEXT',
        'about_mission' => 'TEXT',
        'about_vision' => 'TEXT',
        'established_year' => 'TEXT',
        'completed_projects' => 'TEXT',
        'capital_reserves' => 'TEXT'
    ];
    foreach ($migration_cols as $col => $type) {
        try {
            $db->exec("ALTER TABLE site_settings ADD COLUMN {$col} {$type} DEFAULT NULL");
        } catch (Exception $e) {
            // Already exists or fail silently
        }
    }
}

// ==========================================
// SYSTEM REBRAND CONFIGURATION (DYNAMIC VALUES)
// ==========================================
$site_settings = null;
if ($db) {
    try {
        $stg_stmt = $db->query("SELECT * FROM site_settings LIMIT 1");
        $site_settings = $stg_stmt->fetch();
    } catch (Exception $e) {
        // Safe lock, settings fallback to default values
    }
}

// Map Dynamic settings
$app_site_name = $site_settings['site_name'] ?? 'Platinum Holdings';
$app_company_name = $site_settings['company_name'] ?? 'Platinum Holdings';
$app_tagline = $site_settings['tagline'] ?? 'Elite Real Estate Assets';
$app_primary_color = $site_settings['primary_color'] ?? '#0f172a';
$app_secondary_color = $site_settings['secondary_color'] ?? '#1e293b';
$app_accent_color = $site_settings['accent_color'] ?? '#c5a880';
$app_font_family = $site_settings['font_family'] ?? 'Inter';
$app_footer_text = $site_settings['footer_text'] ?? 'Platinum Holdings Real Estate Group. All assets fully owned, developed and distributed directly.';
$app_contact_email = $site_settings['contact_email'] ?? 'contact@elitepartners.com';
$app_contact_phone = $site_settings['contact_phone'] ?? '+1 (800) 555-0199';
$app_whatsapp_number = $site_settings['whatsapp_number'] ?? '18005550199';
$app_office_address = $site_settings['office_address'] ?? '742 Platinum Boulevard, Tower A, Elite Metropolis';
$app_maps_embed = $site_settings['maps_embed'] ?? '';
$app_active_theme = $site_settings['active_theme'] ?? 'luxury';
$app_logo_url = $site_settings['logo_url'] ?? 'assets/image_site_logo.png';
$app_favicon_url = $site_settings['favicon_url'] ?? 'assets/image_site_favicon.png';
$app_seo_meta_title = $site_settings['seo_meta_title'] ?? 'Platinum Holdings - Luxury Developer';
$app_seo_meta_desc = $site_settings['seo_meta_description'] ?? 'Ultra-private luxury real estate assets and direct developer acquisitions.';

// Map About Us dynamic parameters with beautiful, brand-perfect corporate copies by default
$app_about_heading = $site_settings['about_heading'] ?? 'Direct Developers of Sovereign Real Estate Assets';
$app_about_body = $site_settings['about_body'] ?? 'Platinum Holdings is a premier private, vertically-integrated real estate developer. Unlike traditional brokerage marketplaces or multi-vendor agencies, we operate exclusively under an enterprise direct-ownership model. Every architectural masterpiece, premium penthouse, and commercial tower featured in our portfolio belongs 100% directly to the company from inception to liquidation. This structural independence enables us to control every facet of property planning, construction, premium finishings, legal clearances, and immediate wire closures.';
$app_about_history = $site_settings['about_history'] ?? 'Established at the dawn of the modern metropolis, Platinum Holdings was founded on a singular ideal: to eliminate middle-agent frictions and speculative broker practices. Since our first acquisition, we have maintained a strict debt-to-equity ratio, ensuring that every asset we develop is funded with sovereign capital. Over decades of high-definition craftsmanship, we have designed over 2.4 Million square feet of premium habitable masterworks across international coastlines and civic sectors, delivering title clearness and pricing honesty to sophisticated buyers.';
$app_about_mission = $site_settings['about_mission'] ?? 'To engineer zero-commission, direct-to-owner premium acquisitions that establish long-term security, spatial majesty, and absolute pricing honesty.';
$app_about_vision = $site_settings['about_vision'] ?? 'To stand as the world\'s most trusted luxury direct developer, setting the benchmark for sovereign asset safety and carbon-conscious structural logic.';
$app_established_year = $site_settings['established_year'] ?? '2008';
$app_completed_projects = $site_settings['completed_projects'] ?? '42 Capital Developments';
$app_capital_reserves = $site_settings['capital_reserves'] ?? '$1.2B Sovereign Capital';

// Make sure asset paths are safe in our public directory
if (!file_exists(__DIR__ . '/assets')) {
    mkdir(__DIR__ . '/assets', 0755, true);
}
if (!file_exists(__DIR__ . '/uploads')) {
    mkdir(__DIR__ . '/uploads', 0755, true);
}

// Generate minimal dummy asset files so the app page looks beautiful and has zero broken images on startup!
// We'll write blank images or soft design gradients using SVG inside inline elements, but having real physical files prevents 404 console errors.
$asset_placeholders = [
    'assets/image_site_logo.png', 'assets/image_site_favicon.png',
    'assets/property_obsidian_1.jpg', 'assets/property_obsidian_2.jpg',
    'assets/property_aura_1.jpg', 'assets/property_zenith_1.jpg',
    'assets/blog_obsidian_arch.jpg', 'assets/blog_corporate_acquisitions.jpg'
];
foreach ($asset_placeholders as $pth) {
    if (!file_exists(__DIR__ . '/' . $pth)) {
        file_put_contents(__DIR__ . '/' . $pth, "");
    }
}

// ==========================================
// CORE HELPERS & UTILITIES
// ==========================================

function s($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

function get_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function is_logged_in() {
    return isset($_SESSION['uid']);
}

function is_developer() {
    return is_logged_in() && ($_SESSION['urole'] === 'Developer');
}

function require_login() {
    if (!is_logged_in()) {
        $_SESSION['alert_msg'] = 'Access denied. Security authentication required.';
        $_SESSION['alert_type'] = 'warning';
        header("Location: login.php");
        exit;
    }
}

function require_developer() {
    require_login();
    if (!is_developer()) {
        $_SESSION['alert_msg'] = 'Access Restricted. Developer access permission required.';
        $_SESSION['alert_type'] = 'danger';
        header("Location: index.php");
        exit;
    }
}

function format_price($price_val) {
    if ($price_val >= 1000000) {
        return '$' . number_format($price_val / 1000000, 1) . 'M';
    } elseif ($price_val >= 1000) {
        return '$' . number_format($price_val / 1000, 0) . 'K';
    }
    return '$' . number_format($price_val);
}

function log_activity($action, $severity = 'Info') {
    global $db;
    if ($db) {
        try {
            $user_name = $_SESSION['uname'] ?? 'Visitor';
            $ip_address = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $stmt = $db->prepare("INSERT INTO activity_logs (user_name, action_performed, severity, ip_address) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user_name, $action, $severity, $ip_address]);
        } catch (Exception $e) {}
    }
}

function set_alert($message, $type = 'info') {
    $_SESSION['alert_msg'] = $message;
    $_SESSION['alert_type'] = $type;
}

function show_alert() {
    if (isset($_SESSION['alert_msg'])) {
        $msg = $_SESSION['alert_msg'];
        $type = $_SESSION['alert_type'] ?? 'info';
        if ($type === 'error') $type = 'danger';
        
        echo "<div class='alert alert-{$type} alert-dismissible fade show border-0 shadow-sm rounded-3 py-3 mb-4' role='alert'>
                <div class='d-flex align-items-center'>
                    <i class='bi bi-info-circle-fill me-2 fs-5'></i>
                    <div>" . s($msg) . "</div>
                </div>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
              </div>";
              
        unset($_SESSION['alert_msg']);
        unset($_SESSION['alert_type']);
    }
}

// ==========================================
// RENDER COMPONENT HEADER & FOOTER
// ==========================================
function render_site_header($title = "Enterprise Group") {
    global $app_site_name, $app_primary_color, $app_secondary_color, $app_accent_color, $app_font_family, $app_logo_url, $is_logged, $app_whatsapp_number;
    $curr_file = basename($_SERVER['PHP_SELF']);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo s($title); ?> - <?php echo s($app_site_name); ?></title>
    <!-- CDN Bootstrap 5.3 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!-- Google Fonts Inter, Playfair Display, Space Grotesk -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --font-sans: 'Inter', sans-serif;
            --font-title: 'Playfair Display', serif;
            --font-mono: 'JetBrains Mono', monospace;
            --primary: <?php echo s($app_primary_color); ?>;
            --secondary: <?php echo s($app_secondary_color); ?>;
            --accent: <?php echo s($app_accent_color); ?>;
            --bg-site: #f8fafc;
        }
        body {
            font-family: var(--font-sans);
            background-color: var(--bg-site);
            color: #1e293b;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }
        .luxury-heading {
            font-family: var(--font-title);
            font-weight: 700;
        }
        .mono { font-family: var(--font-mono); }
        .text-accent { color: var(--accent); }
        .bg-accent { background-color: var(--accent); }
        .btn-accent {
            background-color: var(--accent);
            color: #ffffff;
            border: 1px solid var(--accent);
            transition: all 0.2s ease-in-out;
        }
        .btn-accent:hover {
            opacity: 0.95;
            background-color: #000000;
            color: #ffffff;
            border-color: #000000;
        }
        .bg-primary-theme { background-color: var(--primary); }
        .navbar {
            background-color: rgba(255, 255, 255, 0.95) !important;
            backdrop-filter: blur(8px);
            border-bottom: 1px solid #e2e8f0;
        }
        .navbar-brand {
            font-family: var(--font-title);
            font-weight: 700;
            letter-spacing: -0.01em;
        }
        .card-property {
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            overflow: hidden;
            background-color: #ffffff;
            transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.3s ease;
        }
        .card-property:hover {
            transform: translateY(-4px);
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.05), 0 10px 10px -5px rgba(0,0,0,0.04);
        }
        .footer-premium {
            background-color: #0f172a;
            color: #94a3b8;
            border-top: 4px solid var(--accent);
        }
        .footer-title {
            font-family: var(--font-title);
            color: #ffffff;
            font-weight: 600;
        }
        .badge-status {
            font-size: 0.75rem;
            font-weight: 600;
            letter-spacing: 0.05em;
            padding: 6px 12px;
            border-radius: 9999px;
        }
        .status-ForSale { background-color: #d1fae5; color: #065f46; }
        .status-ReadyToMove { background-color: #dbeafe; color: #1e40af; }
        .status-UnderConstruction { background-color: #fef3c7; color: #92400e; }
        .status-Upcoming { background-color: #fae8ff; color: #86198f; }
        .status-Sold { background-color: #fca5a5; color: #7f1d1d; }
        .hero-banner {
            background-size: cover;
            background-position: center;
            position: relative;
            background-color: #0f172a;
        }
        .thumbnail-gallery {
            cursor: pointer;
            transition: opacity 0.2s;
        }
        .thumbnail-gallery:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <header class="sticky-top">
        <nav class="navbar navbar-expand-lg navbar-light py-3">
            <div class="container">
                <a class="navbar-brand text-dark d-flex align-items-center gap-2" href="index.php">
                    <span class="fs-4 fw-bold tracking-tight d-flex align-items-center">
                        <i class="bi bi-buildings-fill text-accent me-1"></i> <?php echo s($app_site_name); ?>
                    </span>
                    <span class="badge text-uppercase bg-accent text-light fw-bold fs-9" style="font-size: 0.6rem; letter-spacing: 0.1em; padding: 3px 6px;">OWN PORTFOLIO</span>
                </a>
                <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navMenu">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-5 gap-3">
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($curr_file == 'index.php') ? 'active fw-bold text-accent' : ''; ?>" href="index.php">Acquisitions Portal</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($curr_file == 'properties.php' || $curr_file == 'property-details.php') ? 'active fw-bold text-accent' : ''; ?>" href="properties.php">Properties Portfolio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($curr_file == 'about.php') ? 'active fw-bold text-accent' : ''; ?>" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($curr_file == 'blogs.php' || $curr_file == 'blog-details.php') ? 'active fw-bold text-accent' : ''; ?>" href="blogs.php">Executive Journals</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($curr_file == 'faq.php') ? 'active fw-bold text-accent' : ''; ?>" href="faq.php">Queries (FAQ)</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo ($curr_file == 'contact.php') ? 'active fw-bold text-accent' : ''; ?>" href="contact.php">Advisory Desk</a>
                        </li>
                    </ul>
                    <div class="d-flex align-items-center gap-2 flex-wrap">
                        <?php if ($is_logged) { ?>
                            <a href="admin/dashboard.php" class="btn btn-dark btn-sm rounded-3 px-3 py-2"><i class="bi bi-shield-lock me-1"></i> Secure Panel</a>
                            <a href="logout.php" class="btn btn-outline-danger btn-sm rounded-3"><i class="bi bi-power"></i></a>
                        <?php } else { ?>
                            <a href="login.php" class="btn btn-outline-dark btn-sm rounded-3 px-3 py-2">Private Signature Log</a>
                            <a href="properties.php" class="btn btn-accent btn-sm rounded-3 px-3 py-2">Liquidate Portfolio</a>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <?php
}

function render_site_footer() {
    global $app_site_name, $app_footer_text, $app_contact_email, $app_contact_phone, $app_office_address, $app_whatsapp_number;
    ?>
    <footer class="footer-premium pt-5 pb-4 mt-auto">
        <div class="container">
            <div class="row g-4 mb-4">
                <div class="col-lg-5">
                    <span class="fs-4 fw-bold luxury-heading text-white mb-2 d-inline-block">
                        <i class="bi bi-buildings text-accent"></i> <?php echo s($app_site_name); ?>
                    </span>
                    <p class="small text-secondary mb-3 pr-lg-4" style="line-height:1.7;">
                        <?php echo s($app_footer_text); ?>
                    </p>
                    <div class="d-flex gap-2">
                        <a href="https://wa.me/<?php echo s($app_whatsapp_number); ?>" target="_blank" class="btn btn-sm btn-outline-success border-success-subtle text-success py-2 px-3 fw-medium">
                            <i class="bi bi-whatsapp me-2"></i> WhatsApp Advisory
                        </a>
                        <a href="tel:<?php echo s($app_contact_phone); ?>" class="btn btn-sm btn-outline-light py-2 px-3 fw-medium">
                            <i class="bi bi-telephone-outbound me-2"></i> Voice Hotline
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <h5 class="footer-title text-uppercase font-sans fs-6 mb-3 tracking-widest text-accent">Internal Resources</h5>
                    <ul class="list-unstyled d-flex flex-column gap-2 small">
                        <li><a href="index.php" class="text-secondary text-decoration-none hover:text-white">Properties Showcase</a></li>
                        <li><a href="properties.php" class="text-secondary text-decoration-none hover:text-white">Direct Acquisitions List</a></li>
                        <li><a href="blogs.php" class="text-secondary text-decoration-none hover:text-white">Research Journals</a></li>
                        <li><a href="faq.php" class="text-secondary text-decoration-none hover:text-white">Core FAQ Portal</a></li>
                        <li><a href="contact.php" class="text-secondary text-decoration-none hover:text-white">Corporate Advisory Desk</a></li>
                    </ul>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <h5 class="footer-title text-uppercase font-sans fs-6 mb-3 tracking-widest text-accent">Executive Hub Contact</h5>
                    <ul class="list-unstyled d-flex flex-column gap-2 small text-secondary">
                        <li class="d-flex align-items-start gap-2">
                            <i class="bi bi-geo-alt-fill text-accent mt-0.5"></i>
                            <span><?php echo s($app_office_address); ?></span>
                        </li>
                        <li class="d-flex align-items-center gap-2">
                            <i class="bi bi-envelope-at-fill text-accent"></i>
                            <span><?php echo s($app_contact_email); ?></span>
                        </li>
                        <li class="d-flex align-items-center gap-2">
                            <i class="bi bi-telephone-fill text-accent"></i>
                            <span><?php echo s($app_contact_phone); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="border-top border-secondary pt-4 mt-2 d-flex flex-wrap justify-content-between text-secondary style-none small align-items-center">
                <span>&copy; <?php echo date('Y'); ?> <?php echo s($app_site_name); ?>. Fully dynamic. Structured for Hostinger, cPanel & VPS execution.</span>
                <div class="d-flex gap-3 mt-2 mt-sm-0 text-white">
                    <span class="badge border border-secondary text-secondary p-2"><i class="bi bi-shield-check text-success me-1"></i> CSRF Secured</span>
                    <span class="badge border border-secondary text-secondary p-2"><i class="bi bi-database text-info me-1"></i> MySQL Normalized</span>
                </div>
            </div>
        </div>
    </footer>
    <!-- Static Floating WhatsApp Button -->
    <a href="https://wa.me/<?php echo s($app_whatsapp_number); ?>" target="_blank" class="position-fixed bg-success text-white rounded-circle shadow-lg d-flex align-items-center justify-content-center" style="width: 56px; height: 56px; bottom: 24px; right: 24px; z-index:1050; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.08)'" onmouseout="this.style.transform='scale(1)'">
        <i class="bi bi-whatsapp fs-3"></i>
    </a>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
    <?php
}

function render_admin_header($title = "Admin Portal") {
    require_login();
    global $app_site_name, $app_primary_color, $app_secondary_color, $app_accent_color;
    $curr_file = basename($_SERVER['PHP_SELF']);
    $role = $_SESSION['urole'] ?? 'Super Admin';
    $is_dev = ($role === 'Developer');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo s($title); ?> - Secure Console</title>
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: <?php echo s($app_primary_color); ?>;
            --secondary: <?php echo s($app_secondary_color); ?>;
            --accent: <?php echo s($app_accent_color); ?>;
            --sidebar-w: 260px;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f1f5f9;
            min-height: 100vh;
        }
        .admin-sidebar {
            width: var(--sidebar-w);
            background-color: #0f172a;
            color: #94a3b8;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            overflow-y: auto;
            border-right: 1px solid #1e293b;
        }
        .admin-main {
            margin-left: var(--sidebar-w);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .sidebar-brand {
            font-family: 'Playfair Display', serif;
            color: #ffffff;
            font-weight: 700;
            border-bottom: 1px solid #1e293b;
        }
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: #94a3b8;
            text-decoration: none;
            font-size: 0.88rem;
            font-weight: 500;
            transition: all 0.2s;
            border-left: 3px solid transparent;
        }
        .sidebar-link:hover, .sidebar-link.active {
            color: #ffffff;
            background-color: #1e293b;
            border-left-color: var(--accent);
        }
        .admin-navbar {
            background-color: #ffffff;
            border-bottom: 1px solid #e2e8f0;
        }
        .card-stat {
            border: 0;
            border-radius: 12px;
            background-color: #ffffff;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1);
        }
        .mono {
            font-family: 'JetBrains Mono', monospace;
        }
        @media(max-width: 991.98px) {
            .admin-sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            .admin-sidebar.show {
                transform: translateX(0);
            }
            .admin-main {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="sidebar-brand p-4 text-center">
            <span class="fs-5 fw-bold d-flex align-items-center justify-content-center gap-2">
                <i class="bi bi-shield-fill text-accent"></i> Console
            </span>
            <span class="badge text-uppercase bg-accent text-light fw-bold fs-9 mt-1" style="font-size: 0.58rem; letter-spacing: 0.1em;"><?php echo s($role); ?></span>
        </div>
        <nav class="py-3">
            <span class="text-secondary small text-uppercase px-4 d-block mb-2 font-semibold" style="font-size: 0.65rem; letter-spacing: 0.05em;">Acquisitions CRM</span>
            <a href="dashboard.php" class="sidebar-link <?php echo ($curr_file == 'dashboard.php') ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2"></i> Executive Dashboard
            </a>
            <a href="leads.php" class="sidebar-link <?php echo ($curr_file == 'leads.php') ? 'active' : ''; ?>">
                <i class="bi bi-people-fill"></i> Inquiries & CRM
            </a>
            <a href="site-visits.php" class="sidebar-link <?php echo ($curr_file == 'site-visits.php') ? 'active' : ''; ?>">
                <i class="bi bi-calendar-range-fill"></i> Site Tour Schedules
            </a>

            <span class="text-secondary small text-uppercase px-4 d-block mt-4 mb-2 font-semibold" style="font-size: 0.65rem; letter-spacing: 0.05em;">Direct Catalog</span>
            <a href="properties.php" class="sidebar-link <?php echo ($curr_file == 'properties.php') ? 'active' : ''; ?>">
                <i class="bi bi-buildings-fill"></i> Manage Properties
            </a>

            <span class="text-secondary small text-uppercase px-4 d-block mt-4 mb-2 font-semibold" style="font-size: 0.65rem; letter-spacing: 0.05em;">Brand CMS Modules</span>
            <a href="testimonials.php" class="sidebar-link <?php echo ($curr_file == 'testimonials.php') ? 'active' : ''; ?>">
                <i class="bi bi-chat-quote-fill"></i> Client Testimonials
            </a>
            <a href="faqs.php" class="sidebar-link <?php echo ($curr_file == 'faqs.php') ? 'active' : ''; ?>">
                <i class="bi bi-question-diamond-fill"></i> Manage FAQs
            </a>

            <span class="text-secondary small text-uppercase px-4 d-block mt-4 mb-2 font-semibold" style="font-size: 0.65rem; letter-spacing: 0.05em;">Rebranding Setup</span>
            <a href="rebranding.php" class="sidebar-link <?php echo ($curr_file == 'rebranding.php') ? 'active' : ''; ?>">
                <i class="bi bi-palette-fill"></i> Theme & Brand Customizer
            </a>

            <?php if ($is_dev) { ?>
                <span class="text-secondary small text-uppercase px-4 d-block mt-4 mb-2 font-semibold text-danger" style="font-size: 0.65rem; letter-spacing: 0.05em;">Security & Logins</span>
                <a href="developer.php" class="sidebar-link text-warning <?php echo ($curr_file == 'developer.php') ? 'active' : ''; ?>">
                    <i class="bi bi-terminal-fill"></i> Developer Control Terminal
                </a>
            <?php } ?>

            <span class="text-secondary small text-uppercase px-4 d-block mt-4 mb-2 font-semibold" style="font-size: 0.65rem; letter-spacing: 0.05em;">Public Exit</span>
            <a href="../index.php" class="sidebar-link text-info">
                <i class="bi bi-arrow-left-square"></i> Visit Public Portal
            </a>
            <a href="../logout.php" class="sidebar-link text-danger">
                <i class="bi bi-power"></i> Clean Logout
            </a>
        </nav>
    </aside>

    <!-- Main Section Layout -->
    <div class="admin-main">
        <header class="admin-navbar py-2 px-4 shadow-sm sticky-top d-flex justify-content-between align-items-center">
            <button class="btn btn-outline-dark btn-sm d-lg-none" onclick="document.getElementById('adminSidebar').classList.toggle('show')">
                <i class="bi bi-list"></i> Menu
            </button>
            <div class="small text-secondary d-none d-sm-block">
                Welcome back, executive <b class="text-dark"><?php echo s($_SESSION['uname']); ?></b>. Secure Sandbox Access.
            </div>
            <div class="d-flex align-items-center gap-2">
                <span class="badge border text-dark bg-light px-3 py-2"><i class="bi bi-lightning-charge-fill text-warning"></i> SQL Sandbox</span>
            </div>
        </header>
        <main class="p-4 flex-grow-1">
            <?php show_alert(); ?>
    <?php
}

function render_admin_footer() {
    ?>
        </main>
        <footer class="bg-white border-top py-3 text-center text-secondary small">
            <div>&copy; <?php echo date('Y'); ?> Secure Enterprise Broker-Free Control Panel. cPanel & Hostinger Optimized.</div>
        </footer>
    </div>
    <!-- Script core Bootstrap bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
    <?php
}
?>

