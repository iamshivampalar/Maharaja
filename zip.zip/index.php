<?php
/**
 * ProLandmark Elite - Premium Real Estate Brand Public Portal
 * Main landing page for developer-owned luxury portfolio.
 */
require_once 'config.php';

$is_logged = is_logged_in();

// Fetch 3 most viewed/featured properties
$featured_props = [];
if ($db) {
    try {
        $stmt = $db->query("SELECT p.*, c.name as category_name 
                            FROM properties p 
                            LEFT JOIN categories c ON p.category_id = c.id 
                            ORDER BY p.featured DESC, p.views DESC LIMIT 3");
        $featured_props = $stmt->fetchAll();
    } catch (Exception $e) {
        // Safe lock fallback
    }
}

// Fetch general counts for bento stats
$total_sqft = 0;
$average_p = 0;
if ($db) {
    try {
        $total_sqft = $db->query("SELECT SUM(area) FROM properties")->fetchColumn() ?: 0;
        $average_p = $db->query("SELECT AVG(price) FROM properties")->fetchColumn() ?: 0;
    } catch (Exception $e) {}
}

// Fetch client reviews
$reviews = [];
if ($db) {
    try {
        $reviews = $db->query("SELECT * FROM testimonials ORDER BY id DESC LIMIT 2")->fetchAll();
    } catch (Exception $e) {}
}

// Fetch latest journals
$journals = [];
if ($db) {
    try {
        $journals = $db->query("SELECT * FROM blogs ORDER BY id DESC LIMIT 2")->fetchAll();
    } catch (Exception $e) {}
}

render_site_header($app_tagline);
?>

<!-- 1. Hero Dynamic Screen Slider -->
<section class="hero-banner text-white py-5 d-flex align-items-center" style="background-image: linear-gradient(rgba(15, 23, 42, 0.75), rgba(15, 23, 42, 0.85)), url('https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80'); min-height: 85vh;">
    <div class="container py-lg-5">
        <div class="row align-items-center g-5">
            <div class="col-lg-7 text-start">
                <span class="badge border border-warning text-warning mb-3 px-3 py-2 text-uppercase fw-bold text-spacing" style="font-size: 0.75rem; letter-spacing: 0.15em;">DIRECT COMPANY OWNERSHIP</span>
                <h1 class="display-3 fw-bold mb-3 luxury-heading" style="line-height: 1.1;">Acquire Premium Real Estate <span class="text-accent">Directly From Developer</span></h1>
                <p class="fs-5 text-secondary pr-lg-5 mb-4" style="line-height: 1.7; max-width: 580px;">We design, develop, and own 100% of the properties displayed in our catalogs. Enjoy direct wire closures, direct title guarantees, and broker-free transaction integrity.</p>
                
                <!-- Quick Search Action Desk -->
                <div class="card p-3 border-0 bg-white shadow-sm rounded-4 mt-2">
                    <form action="properties.php" method="GET" class="row g-2 align-items-center text-dark">
                        <div class="col-md-4">
                            <label class="form-label text-secondary small fw-bold mb-1">Asset Category</label>
                            <select name="category" class="form-select border-0 bg-light select-sm py-2">
                                <option value="">All Architectures</option>
                                <option value="mansions">Luxurious Mansions</option>
                                <option value="pinnacle-apartments">Pinnacle Apartments</option>
                                <option value="corporate-hubs">Corporate Hubs</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label text-secondary small fw-bold mb-1">Acquisition Style</label>
                            <select name="status" class="form-select border-0 bg-light py-2">
                                <option value="">All Statuses</option>
                                <option value="Ready To Move">Ready To Move</option>
                                <option value="Under Construction">Under Construction</option>
                                <option value="Upcoming">Upcoming Release</option>
                            </select>
                        </div>
                        <div class="col-md-4 pt-sm-3">
                            <button type="submit" class="btn btn-accent w-full py-2.5 rounded-3 fw-bold d-flex align-items-center justify-content-center gap-1">
                                <i class="bi bi-search"></i> Inspect Catalog
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="col-lg-5">
                <!-- Highlight Card -->
                <div class="card bg-dark bg-opacity-40 border border-secondary border-opacity-30 rounded-4 p-4 text-start backdrop-blur-md">
                    <span class="text-accent fw-bold mono small text-uppercase tracking-wider">Spotlight Direct Landmark</span>
                    <h3 class="h4 mt-2 text-white fw-bold mb-2">The Obsidian Waterfront Estate</h3>
                    <p class="small text-secondary leading-relaxed mb-3">Cliffs of Metropolis - 14,500 Sq Ft luxury raw volcanic-stone architectural marvel, multi-tier custom vaults, 6 Beds, 8 Bathrooms.</p>
                    <div class="d-flex justify-content-between align-items-center border-top border-secondary border-opacity-30 pt-3 flex-wrap">
                        <div>
                            <span class="text-secondary small d-block">Fixed Price</span>
                            <span class="fs-4 fw-bold text-accent">$14.5M</span>
                        </div>
                        <a href="property-details.php?slug=the-obsidian-waterfront-estate" class="btn btn-sm btn-outline-light px-3 py-2 rounded-3">Explore Asset <i class="bi bi-arrow-right-short ms-1"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 2. Bento Institutional Advantage Matrix -->
<section class="container py-5">
    <div class="text-center max-w-2xl mx-auto mb-5">
        <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.15em;">The Platinum Protocol</span>
        <h2 class="display-6 mt-1 mb-2 fw-bold text-dark luxury-heading">Corporate Asset Standard</h2>
        <p class="text-secondary small mb-0" style="max-width: 580px; margin: 0 auto;">By circumventing brokers, we retain supreme design quality control and transfer the commission savings directly onto your asset pricing ledger.</p>
    </div>

    <div class="row g-4 align-items-stretch">
        <div class="col-md-4">
            <div class="bg-white border p-4 h-full rounded-4 d-flex flex-column justify-content-between">
                <div>
                     <div class="btn btn-lg bg-accent text-light p-2 mb-3 rounded-3 d-inline-flex justify-content-center align-items-center" style="width: 48px; height: 48px;"><i class="bi bi-patch-check fs-4"></i></div>
                     <h4 class="h5 fw-bold mb-2 text-dark">Developer Direct Pricing</h4>
                     <p class="small text-secondary mb-0">Unlike retail agents, we establish singular pricing models without broker commissions or hidden markup markups. You interact with our direct executive team.</p>
                </div>
                <div class="mono text-accent text-xs mt-3">LEDGER HONESTY CORE</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="bg-white border p-4 h-full rounded-4 d-flex flex-column justify-content-between">
                <div>
                     <div class="btn btn-lg bg-success text-light p-2 mb-3 rounded-3 d-inline-flex justify-content-center align-items-center" style="width: 48px; height: 48px;"><i class="bi bi-shield-check fs-4"></i></div>
                     <h4 class="h5 fw-bold mb-2 text-dark">Pre-Vetted Title Cleared</h4>
                     <p class="small text-secondary mb-0">All listed deeds, titles, and legal certificates are completely cleared and pre-registered under our parent hold brand. Closure delays are reduced from months to days.</p>
                </div>
                <div class="mono text-success text-xs mt-3">TITLE COMPLIANCE DEPT</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="bg-white border p-4 h-full rounded-4 d-flex flex-column justify-content-between">
                <div>
                     <div class="btn btn-lg bg-dark text-light p-2 mb-3 rounded-3 d-inline-flex justify-content-center align-items-center" style="width: 48px; height: 48px;"><i class="bi bi-buildings-fill fs-4"></i></div>
                     <h4 class="h5 fw-bold mb-2 text-dark">Dynamic Custom Bespoke</h4>
                     <p class="small text-secondary mb-0">Our construction arm is always ready to custom design layout adjustments or install premium tech upgrades prior to title hand-over.</p>
                </div>
                <div class="mono text-dark text-xs mt-3">ARCHITECTURAL BESPOKE DIVISION</div>
            </div>
        </div>
    </div>
</section>

<!-- 3. Current Live Properties Portfolio -->
<section class="py-5 bg-white border-top border-bottom">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end flex-wrap gap-2 mb-5">
            <div class="text-start">
                <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.1em;">OUR CURATED REALTY PORTFOLIO</span>
                <h2 class="display-6 fw-bold text-dark luxury-heading mb-1">Company-Owned Assets</h2>
                <p class="text-secondary small mb-0">Every development listed here is 100% owned and offered directly by the corporate pool.</p>
            </div>
            <a href="properties.php" class="btn btn-outline-dark rounded-3 px-4 py-2fw-bold">View Entire Catalog <i class="bi bi-arrow-right-short ms-1"></i></a>
        </div>

        <div class="row g-4 justify-content-center">
            <?php if (empty($featured_props)) { ?>
                <div class="text-center py-5">
                    <i class="bi bi-houses fs-1 text-secondary mb-2"></i>
                    <p class="text-muted small">No active properties initialized. Access index.php and install tables or insert values inside admin.</p>
                </div>
            <?php } else { 
                foreach ($featured_props as $prop) {
                ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card-property h-full d-flex flex-column justify-content-between">
                        <div>
                            <!-- Header Info -->
                            <div class="position-relative" style="height: 240px; background-color: #1e293b; overflow: hidden;">
                                <div class="position-absolute w-full h-full bg-cover-temp d-flex align-items-center justify-content-center" style="background-image: url('https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'); background-size: cover; background-position: center;">
                                    <div class="bg-dark bg-opacity-30 w-full h-full"></div>
                                </div>
                                <span class="position-absolute top-3 left-3 badge-status status-<?php echo str_replace(' ', '', $prop['status']); ?> badge"><?php echo s($prop['status']); ?></span>
                                <span class="position-absolute bottom-3 left-3 bg-dark text-white rounded-2 px-2.5 py-1 small fw-bold mono"><?php echo s($prop['type']); ?></span>
                            </div>
                            
                            <!-- Card Body -->
                            <div class="p-4 text-start">
                                <span class="text-accent font-sans text-uppercase fw-bold" style="font-size: 0.72rem; letter-spacing: 0.08em;"><?php echo s($prop['category_name'] ?: 'Curated Portfolio'); ?></span>
                                <h4 class="fw-bold text-dark fs-5 mt-1 mb-2 tracking-tight"><?php echo s($prop['title']); ?></h4>
                                <p class="text-secondary small line-clamp-2 mb-3" style="line-height:1.6; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;"><?php echo s($prop['short_description']); ?></p>
                                
                                <div class="d-flex gap-3 text-secondary border-top pt-3 small flex-wrap">
                                    <span class="d-flex align-items-center gap-1"><i class="bi bi-aspect-ratio text-accent"></i> <?php echo number_format($prop['area']); ?> Sq Ft</span>
                                    <span class="d-flex align-items-center gap-1"><i class="bi bi-heart text-accent"></i> <?php echo s($prop['bedrooms']); ?> Beds</span>
                                    <span class="d-flex align-items-center gap-1"><i class="bi bi-water text-accent"></i> <?php echo s($prop['bathrooms']); ?> Baths</span>
                                </div>
                            </div>
                        </div>

                        <!-- Card Footer -->
                        <div class="p-4 border-top bg-light d-flex justify-content-between align-items-center rounded-bottom">
                            <div>
                                <span class="text-secondary small d-block" style="font-size: 0.65rem; text-transform:uppercase;">Fixed developer offer</span>
                                <span class="fs-4 fw-bold text-dark"><?php echo format_price($prop['price']); ?></span>
                            </div>
                            <a href="property-details.php?slug=<?php echo s($prop['slug']); ?>" class="btn btn-dark btn-sm rounded-3 px-3 py-2 fw-medium">Inspect Direct</a>
                        </div>
                    </div>
                </div>
            <?php } 
            } ?>
        </div>
    </div>
</section>

<!-- 4. Real-time Bento Performance Metrology -->
<section class="container py-5">
    <div class="row g-4 align-items-center">
        <div class="col-lg-5 text-start">
            <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.1em;">OUR INVESTMENT STABILITY</span>
            <h2 class="display-6 fw-bold text-dark luxury-heading mb-3">Enterprise Capacity</h2>
            <p class="text-secondary mb-4 small" style="line-height: 1.7;">Instead of relying on unstable leveraged developer networks, we design, deploy and hold premium acquisitions securely on our structural balances. Real real estate, clean cashflows.</p>
            <div class="d-flex gap-2">
                <a href="contact.php" class="btn btn-accent px-4 py-2.5 rounded-3 fw-bold">Query Portfolio Allocation</a>
                <a href="about.php" class="btn btn-outline-dark px-4 py-2.5 rounded-3">Our History</a>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="row g-3">
                <div class="col-sm-6">
                    <div class="p-4 bg-white border rounded-4 text-start h-full d-flex flex-column justify-content-between shadow-sm">
                        <div>
                            <span class="text-secondary text-uppercase font-sans small tracking-wider">Asset Holdings Portfolio</span>
                            <div class="display-5 fw-bold text-dark mt-2 mb-1"><?php echo number_format($total_sqft); ?>+</div>
                        </div>
                        <p class="small text-muted mb-0 border-top pt-2 mt-2">Active square footage completely built, clean deeded, and held under direct title custody.</p>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="p-4 bg-white border rounded-4 text-start h-full d-flex flex-column justify-content-between shadow-sm">
                        <div>
                            <span class="text-secondary text-uppercase font-sans small tracking-wider">Median Investment Tranche</span>
                            <div class="display-5 fw-bold text-dark mt-2 mb-1"><?php echo format_price($average_p); ?></div>
                        </div>
                        <p class="small text-muted mb-0 border-top pt-2 mt-2">Average asset market validation pricing. Backed by solid limestone limestone structures.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 5. Editorial Executive Journals -->
<?php if (!empty($journals)) { ?>
<section class="py-5 bg-light border-top">
    <div class="container text-start">
        <div class="text-center mb-5 max-w-xl mx-auto">
            <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.1em;">EXECUTIVE EDITORIALS</span>
            <h2 class="h1 fw-bold text-dark luxury-heading">Corporate Journals</h2>
        </div>
        <div class="row g-4 justify-content-center">
            <?php foreach ($journals as $j) { ?>
                <div class="col-md-6 col-lg-5">
                    <div class="card p-4 border-0 shadow-sm rounded-4 bg-white h-full d-flex flex-column justify-content-between">
                        <div>
                            <span class="badge border text-accent border-warning px-2.5 py-1 text-uppercase mono mb-3" style="font-size: 0.65rem;"><?php echo s($j['tags']); ?></span>
                            <h4 class="fw-bold text-dark fs-5 mb-2 leading-snug"><a href="blog-details.php?slug=<?php echo s($j['slug']); ?>" class="text-dark text-decoration-none hover:text-accent"><?php echo s($j['title']); ?></a></h4>
                            <p class="text-secondary small line-clamp-3 mb-4" style="line-height:1.6; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;">The evolution of high-net-worth real estate acquisitions demands direct transactional simplicity. In this journal, we elaborate on spatial structures, carbon insulation integration, and asset structures directly developed...</p>
                        </div>
                        <div class="d-flex justify-content-between align-items-center border-top pt-3">
                            <span class="small text-muted">Auteur: <b class="text-dark"><?php echo s($j['author_name']); ?></b></span>
                            <a href="blog-details.php?slug=<?php echo s($j['slug']); ?>" class="text-accent fw-bold text-decoration-none small">Read Article <i class="bi bi-chevron-right fs-9"></i></a>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</section>
<?php } ?>

<!-- 6. Client Trust Segment -->
<?php if (!empty($reviews)) { ?>
<section class="py-5 bg-white border-top border-bottom">
    <div class="container text-start">
        <div class="row align-items-center g-5">
            <div class="col-lg-4">
                <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.1em;">ESTEEMED PARTNERS</span>
                <h3 class="display-6 fw-bold text-dark luxury-heading mt-1">Direct Trust</h3>
                <p class="text-secondary leading-relaxed small">We hold our architectural parameters and title delivery cycles to elite standards. Read firsthand reviews from corporate heads who acquired direct developments from our vault portfolio.</p>
            </div>
            <div class="col-lg-8">
                <div class="row g-3">
                    <?php foreach ($reviews as $rev) { ?>
                        <div class="col-md-6">
                            <div class="card p-4 bg-light border-0 rounded-4 shadow-sm h-full d-flex flex-column justify-content-between">
                                <div>
                                    <div class="text-warning mb-2 fs-6">
                                        <?php for($i=1; $i<=$rev['rating']; $i++) { echo '<i class="bi bi-star-fill"></i>'; } ?>
                                    </div>
                                    <p class="small text-secondary mb-3 italic" style="line-height:1.65;">"<?php echo s($rev['review']); ?>"</p>
                                </div>
                                <div class="border-top pt-3 small mt-2">
                                    <div class="fw-bold text-dark"><?php echo s($rev['client_name']); ?></div>
                                    <div class="text-muted text-xs"><?php echo s($rev['client_title']); ?></div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php } ?>

<!-- Endorsement CTA Site Visit -->
<section class="container py-5">
    <div class="bg-primary-theme text-white text-md-start p-4 p-lg-5 rounded-4 d-flex justify-content-between flex-wrap align-items-center g-4 shadow-lg position-relative overflow-hidden" style="background-image: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);">
        <div class="position-absolute border border-warning opacity-10 rounded-circle" style="width:250px; height:250px; top:-50px; right:-50px;"></div>
        <div class="m-0 col-md-7 position-relative">
            <span class="badge bg-warning text-dark text-uppercase fs-9 tracking-wider fw-bold mb-2">Book Exclusive Site Visit</span>
            <h2 class="fw-bold display-6 mb-2 luxury-heading" style="line-height: 1.15;">Schedule a High-Definition Advisory Visit</h2>
            <p class="text-secondary mb-0 small" style="line-height: 1.7; opacity: 0.9;">Choose a preferred date and allocate local executive time. We arrange armored private transportation or premium landing allocations if required.</p>
        </div>
        <div class="m-0 col-md-4 text-md-end mt-4 mt-md-0 position-relative">
            <a href="contact.php?action=book" class="btn btn-accent btn-lg w-full py-3 fs-6 rounded-3 fw-bold shadow-sm"><i class="bi bi-calendar-event me-2"></i> Lock Executive Visit Slot</a>
        </div>
    </div>
</section>

<?php
render_site_footer();
?>
