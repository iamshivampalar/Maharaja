<?php
/**
 * ProLandmark Elite - Dynamic Journal Reader
 * Detailed public editorial viewer with views analytics tracking.
 */
require_once 'config.php';

$is_logged = is_logged_in();
$slug = $_GET['slug'] ?? '';

$post = null;
if ($db && !empty($slug)) {
    try {
        $stmt = $db->prepare("SELECT * FROM blogs WHERE slug = ? LIMIT 1");
        $stmt->execute([$slug]);
        $post = $stmt->fetch();

        if ($post) {
            // Increment reading score views
            $db->prepare("UPDATE blogs SET views = views + 1 WHERE id = ?")->execute([$post['id']]);
        }
    } catch (Exception $e) {}
}

if (!$post) {
    header("Location: blogs.php");
    exit;
}

render_site_header($post['title']);
?>

<div class="bg-light border-bottom py-4">
    <div class="container text-start">
        <nav aria-label="breadcrumb" class="mb-2">
            <ol class="breadcrumb mb-0 small">
                <li class="breadcrumb-item"><a href="index.php" class="text-accent text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="blogs.php" class="text-accent text-decoration-none">Journals</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo s(substr($post['title'], 0, 40)); ?>...</li>
            </ol>
        </nav>
        <span class="badge border border-warning text-accent text-uppercase px-2.5 py-1 mb-2 mono" style="font-size:0.65rem;"><?php echo s($post['tags']); ?></span>
        <h1 class="h2 fw-bold text-dark luxury-heading mb-1"><?php echo s($post['title']); ?></h1>
        <div class="d-flex align-items-center gap-3 text-muted small mt-2">
            <span>By <b class="text-dark"><?php echo s($post['author_name']); ?></b></span>
            <span>&bull;</span>
            <span><i class="bi bi-clock"></i> Reading entry: <?php echo date('M d, Y', strtotime($post['created_at'])); ?></span>
            <span>&bull;</span>
            <span><i class="bi bi-eye"></i> View Score: <?php echo intval($post['views']) + 1; ?></span>
        </div>
    </div>
</div>

<div class="container py-5 text-start">
    <div class="row">
        <!-- Main Article Column -->
        <div class="col-lg-8 mx-auto">
            <article class="card p-4 p-md-5 border bg-white rounded-4 shadow-sm mb-4">
                <!-- Cover Image -->
                <div class="position-relative overflow-hidden mb-4 rounded-3 bg-dark" style="height:360px;">
                    <div class="position-absolute w-full h-full d-flex align-items-center justify-content-center bg-cover-temp" style="background-image: url('https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'); background-size: cover; background-size: center;">
                        <div class="bg-dark bg-opacity-10 w-full h-full"></div>
                    </div>
                </div>

                <!-- Editorial Content -->
                <div class="text-secondary small font-sans" style="line-height:1.8; font-size:1.02rem;">
                    <?php echo nl2br(($post['content'])); ?>
                </div>

                <div class="border-top pt-4 mt-5 d-flex justify-content-between align-items-center flex-wrap gap-2 text-muted small">
                    <span class="d-flex align-items-center gap-1"><i class="bi bi-award-fill text-warning"></i> Platinum Verification Signature Locked</span>
                    <a href="blogs.php" class="btn btn-outline-dark btn-sm rounded-3"><i class="bi bi-arrow-left-short"></i> All Journals</a>
                </div>
            </article>
        </div>
    </div>
</div>

<?php
render_site_footer();
?>
