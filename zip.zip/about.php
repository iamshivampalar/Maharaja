<?php
/**
 * ProLandmark Elite - Corporate Background & Heritage Portal
 * 100% Dynamic single-business White-Label presentation page.
 */
require_once 'config.php';

$is_logged = is_logged_in();

// Dynamic SEO parameter setup
$page_title = $app_about_heading ? s($app_about_heading) : "Corporate History & Direct Asset Ownership Model";
render_site_header($page_title);
?>

<!-- 1. Luxurious About Hero Header -->
<section class="text-white py-5 d-flex align-items-center position-relative" style="background-image: linear-gradient(rgba(15, 23, 42, 0.8), rgba(15, 23, 42, 0.9)), url('https://images.unsplash.com/photo-1600585154526-990dced4db0d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80'); min-height: 45vh; background-size: cover; background-position: center;">
    <div class="container py-lg-4 text-start position-relative" style="z-index: 2;">
        <span class="badge border border-warning text-warning mb-3 px-3 py-2 text-uppercase fw-bold text-spacing" style="font-size: 0.75rem; letter-spacing: 0.15em;">CORPORATE ADVISORY DISCLOSURE</span>
        <h1 class="display-4 fw-bold mb-3 luxury-heading" style="line-height: 1.15; max-width: 800px;"><?php echo s($app_about_heading); ?></h1>
        <p class="fs-5 text-secondary mb-0" style="max-width: 650px; line-height: 1.6;"><?php echo s($app_tagline); ?> — Dynamic organizational history, sovereign resources, and developer direct transparency models.</p>
    </div>
    <div class="position-absolute h-full w-full top-0 left-0 bg-dark opacity-10" style="background: radial-gradient(circle at 10% 20%, rgba(255,193,7,0.05) 0%, transparent 50%); pointer-events: none;"></div>
</section>

<!-- 2. Dynamic Performance Metrology Stats Rows -->
<section class="bg-white border-bottom py-4" style="margin-top: -1px;">
    <div class="container">
        <div class="row g-3 justify-content-center">
            <div class="col-md-4">
                <div class="p-3 d-flex align-items-center gap-3">
                    <div class="btn btn-lg bg-light text-accent rounded-circle d-flex align-items-center justify-content-center p-0" style="width: 52px; height: 52px; border: 1px solid var(--accent);"><i class="bi bi-calendar3 fs-4"></i></div>
                    <div class="text-start">
                        <span class="text-secondary small d-block text-uppercase tracking-wider" style="font-size: 0.7rem; font-weight:700;">Year Established</span>
                        <h4 class="fw-bold text-dark mb-0 fs-5 mt-0.5"><?php echo s($app_established_year); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4 border-sm-start border-sm-end">
                <div class="p-3 d-flex align-items-center gap-3">
                    <div class="btn btn-lg bg-light text-success rounded-circle d-flex align-items-center justify-content-center p-0" style="width: 52px; height: 52px; border: 1px solid #198754;"><i class="bi bi-building-check fs-4"></i></div>
                    <div class="text-start">
                        <span class="text-secondary small d-block text-uppercase tracking-wider" style="font-size: 0.7rem; font-weight:700;">Completed Capital Assets</span>
                        <h4 class="fw-bold text-dark mb-0 fs-5 mt-0.5"><?php echo s($app_completed_projects); ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3 d-flex align-items-center gap-3">
                    <div class="btn btn-lg bg-light text-dark rounded-circle d-flex align-items-center justify-content-center p-0" style="width: 52px; height: 52px; border: 1px solid #0f172a;"><i class="bi bi-safe2 fs-4"></i></div>
                    <div class="text-start">
                        <span class="text-secondary small d-block text-uppercase tracking-wider" style="font-size: 0.7rem; font-weight:700;">Audited Cash Capital</span>
                        <h4 class="fw-bold text-dark mb-0 fs-5 mt-0.5"><?php echo s($app_capital_reserves); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 3. Enterprise Core Introduction of Direct-Ownership Model -->
<section class="container py-5 text-start">
    <div class="row g-5 align-items-center">
        <div class="col-lg-6">
            <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.15em;">OUR PROPRIETARY MODEL</span>
            <h2 class="display-6 mt-1 mb-3 fw-bold text-dark luxury-heading">The Direct-Ownership Advantage</h2>
            <p class="text-secondary mb-4" style="line-height:1.75; font-size: 0.95rem;">
                <?php echo nl2br(s($app_about_body)); ?>
            </p>
            <div class="p-3 bg-light border rounded-3 border-opacity-70">
                <div class="d-flex align-items-start gap-2.5">
                    <i class="bi bi-shield-lock-fill text-accent fs-4 mt-0.5"></i>
                    <div>
                        <h5 class="fw-bold text-dark mb-1 small text-uppercase font-sans">100% Broker-Free Ledger</h5>
                        <p class="text-secondary mb-0 small">No registered agents, no unverified owner listings, and no hidden commission allocations. We represent our own properties exclusively.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="position-relative">
                <img src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Sovereign Asset" class="img-fluid rounded-4 shadow-sm border" style="max-height: 400px; width: 100%; object-fit: cover;">
                <div class="position-absolute bottom-3 right-3 bg-dark text-white rounded-3 p-3 shadow border border-secondary border-opacity-40" style="max-width: 250px;">
                    <div class="small fw-semibold text-accent font-sans text-uppercase tracking-wider">Deed Clearance Guarantee</div>
                    <p class="text-secondary mb-0 mt-1" style="font-size: 0.75rem; line-height: 1.4;">Every property in our library has pre-cleared absolute titles held directly in company escrow.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 4. Operational Milestones & Heritage -->
<section class="py-5 bg-light border-top border-bottom">
    <div class="container text-start">
        <div class="row g-5">
            <div class="col-lg-4">
                <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.12em;">ORGANIZATIONAL HERITAGE</span>
                <h2 class="display-6 mt-1 mb-3 fw-bold text-dark luxury-heading">Our Structural History</h2>
                <p class="text-secondary small leading-relaxed mb-4">Discover the core values that shaped our growth from a boutique private developer into an enterprise sovereign asset holding company.</p>
                
                <div class="card border border-warning border-opacity-30 bg-warning bg-opacity-10 p-3 rounded-3">
                    <div class="d-flex align-items-center gap-2">
                        <i class="bi bi-patch-check text-warning fs-4"></i>
                        <span class="fw-bold text-dark small font-sans text-uppercase">Certified Sovereign Entity</span>
                    </div>
                    <p class="small text-secondary mb-0 mt-1">Zero reliance on unstable retail debt pools. Total corporate liquidity matches active assets on the balance sheet.</p>
                </div>
            </div>
            
            <div class="col-lg-8">
                <div class="card p-4 p-md-5 border-0 shadow-sm bg-white rounded-4">
                    <h4 class="fw-bold tracking-tight mb-4 text-dark"><i class="bi bi-journal-richtext text-accent me-2"></i>History & Legacy Disclosures</h4>
                    <p class="text-secondary mb-0 leading-relaxed" style="line-height: 1.8; font-size: 0.95rem;">
                        <?php echo nl2br(s($app_about_history)); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 5. Mission & Vision Statement Dual Card layout -->
<section class="container py-5">
    <div class="row g-4 text-start">
        <div class="col-md-6">
            <div class="card p-4 h-full border rounded-4 bg-white shadow-sm d-flex flex-column justify-content-between">
                <div>
                    <div class="btn bg-accent text-light rounded-3 p-2 d-inline-flex align-items-center justify-content-center mb-4" style="width: 48px; height: 48px;"><i class="bi bi-compass fs-4"></i></div>
                    <h4 class="fw-bold text-dark mb-2 font-sans text-uppercase fs-5 tracking-wide">Enterprise Mission</h4>
                    <p class="text-secondary small" style="line-height:1.7;"><?php echo s($app_about_mission); ?></p>
                </div>
                <div class="mono text-accent text-xs mt-3">DIRECT ETHICS CORE</div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card p-4 h-full border rounded-4 bg-white shadow-sm d-flex flex-column justify-content-between">
                <div>
                    <div class="btn bg-dark text-light rounded-3 p-2 d-inline-flex align-items-center justify-content-center mb-4" style="width: 48px; height: 48px;"><i class="bi bi-eye fs-4 text-accent"></i></div>
                    <h4 class="fw-bold text-dark mb-2 font-sans text-uppercase fs-5 tracking-wide">Strategic Vision</h4>
                    <p class="text-secondary small" style="line-height:1.7;"><?php echo s($app_about_vision); ?></p>
                </div>
                <div class="mono text-dark text-xs mt-3">LONG-TERM STRUCTURAL STANDARDS</div>
            </div>
        </div>
    </div>
</section>

<!-- 6. Editorial Philosophy of Broker-Free Integrity -->
<section class="py-5 bg-dark text-white border-top border-bottom" style="background-image: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);">
    <div class="container text-start">
        <div class="text-center mb-5 max-w-2xl mx-auto">
            <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.15em;">WHITE-LABEL INTEGRITY SYSTEM</span>
            <h2 class="display-6 mt-1 mb-2 fw-bold text-white luxury-heading">The Direct Acquisition Philosophy</h2>
            <p class="text-secondary small mb-0" style="max-width: 580px; margin: 0 auto;">Standard real estate marketplaces prioritize quantity, listing unvetted third-party properties to capture broker commissions. We reject this paradigm. By serving only assets owned directly on our structural ledger, transparency remains pristine.</p>
        </div>
        
        <div class="row g-4 justify-content-center">
            <div class="col-md-4">
                <div class="p-4 rounded-4 bg-secondary bg-opacity-10 border border-secondary border-opacity-20 h-full">
                    <span class="badge bg-accent text-white py-1 px-2 mb-3 text-uppercase font-sans fs-9" style="font-size:0.6rem;">Pillar #1</span>
                    <h5 class="fw-bold text-white mb-2">Zero Intermediate markups</h5>
                    <p class="small text-secondary mb-0" style="line-height: 1.6;">By removing sales agents and middle conduits, 100% of spatial planning cost-efficiencies are retained and passed directly onto your tranche valuation.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-4 rounded-4 bg-secondary bg-opacity-10 border border-secondary border-opacity-20 h-full">
                    <span class="badge bg-warning text-dark py-1 px-2 mb-3 text-uppercase font-sans fs-9" style="font-size:0.6rem;">Pillar #2</span>
                    <h5 class="fw-bold text-white mb-2">Pristine Construction Controls</h5>
                    <p class="small text-secondary mb-0" style="line-height: 1.6;">Our in-house project engineers construct each villa with monolithic slab structures, Venice hardwood cuts, and active ecological carbon insulation filters.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-4 rounded-4 bg-secondary bg-opacity-10 border border-secondary border-opacity-20 h-full">
                    <span class="badge bg-info text-dark py-1 px-2 mb-3 text-uppercase font-sans fs-9" style="font-size:0.6rem;">Pillar #3</span>
                    <h5 class="fw-bold text-white mb-2">Unrestricted Instant Closures</h5>
                    <p class="small text-secondary mb-0" style="line-height: 1.6;">Because we hold the underlying real physical titles under our corporate registration, deeds can be wire-coordinated and executed inside hours.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- 7. Endorsement CTA Site Visit -->
<section class="container py-5">
    <div class="bg-primary-theme text-white text-md-start p-4 p-lg-5 rounded-4 d-flex justify-content-between flex-wrap align-items-center g-4 shadow-lg position-relative overflow-hidden" style="background-image: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);">
        <div class="position-absolute border border-warning opacity-10 rounded-circle" style="width:250px; height:250px; top:-50px; right:-50px;"></div>
        <div class="m-0 col-md-7 position-relative">
            <span class="badge bg-warning text-dark text-uppercase fs-9 tracking-wider fw-bold mb-2">DIRECT COMMUNICATION DIRECT</span>
            <h2 class="fw-bold display-6 mb-2 luxury-heading" style="line-height: 1.15;">Establish Direct Contact with Our Advisory Desk</h2>
            <p class="text-secondary mb-0 small" style="line-height: 1.7; opacity: 0.9;">No third-party forms. All queries go directly to the corporate executive staff. Get in touch to schedule an official helicopter landing profile or site tour.</p>
        </div>
        <div class="m-0 col-md-4 text-md-end mt-4 mt-md-0 position-relative">
            <a href="contact.php" class="btn btn-accent btn-lg w-full py-3 fs-6 rounded-3 fw-bold shadow-sm"><i class="bi bi-headset me-2"></i> Query Advisory Staff</a>
        </div>
    </div>
</section>

<?php
render_site_footer();
?>
