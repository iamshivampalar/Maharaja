<?php
/**
 * ProLandmark Elite - Curated Research Journals (Blogs Index)
 * Showcase market trend updates, structural steel materials, and direct developer closures.
 */
require_once 'config.php';

$is_logged = is_logged_in();

$posts = [];
if ($db) {
    try {
        $posts = $db->query("SELECT * FROM blogs ORDER BY id DESC")->fetchAll();
    } catch (Exception $e) {}
}

render_site_header("Executive Journals Portal");
?>

<section class="py-5 bg-white border-bottom">
    <div class="container text-start">
        <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.12em;">DIRECT INVESTMENT STRATEGY</span>
        <h1 class="display-5 fw-bold text-dark luxury-heading mb-1"><i class="bi bi-journal-bookmark-fill text-accent"></i> Executive Journals</h1>
        <p class="text-secondary small">Insightful briefings on luxury architecture, structural engineering, real estate economics, and wealth direct placements.</p>
    </div>
</section>

<div class="container py-5 text-start">
    <div class="row g-4 justify-content-center">
        <?php if (empty($posts)) { ?>
            <div class="col-8">
                <div class="card p-5 border border-dashed rounded-4 text-center bg-white shadow-sm">
                    <i class="bi bi-bookmark-dash fs-1 text-secondary opacity-35 mb-2"></i>
                    <h4 class="fw-bold text-dark mb-1">Publications queue is empty</h4>
                    <p class="text-secondary small mb-0">Our editors are compiling the next tranche of architectural research briefs.</p>
                </div>
            </div>
        <?php } else { 
            foreach ($posts as $pst) {
            ?>
            <div class="col-md-6 col-lg-4">
                <div class="card p-4 border border-1 shadow-sm bg-white h-full d-flex flex-column justify-content-between rounded-4">
                    <div>
                        <span class="badge border border-warning text-accent text-uppercase px-2.5 py-1 mb-3 mono" style="font-size:0.65rem;"><?php echo s($pst['tags']); ?></span>
                        <h4 class="fw-bold text-dark fs-5 mb-2"><a href="blog-details.php?slug=<?php echo s($pst['slug']); ?>" class="text-dark text-decoration-none hover:text-accent"><?php echo s($pst['title']); ?></a></h4>
                        <p class="text-secondary small line-clamp-3 mb-4" style="line-height:1.65; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;">Detailed briefings detailing luxury raw structure foundations, direct acquisitions, Venice structural timbers, and portfolio allocations held in direct development catalogs...</p>
                    </div>

                    <div class="d-flex justify-content-between align-items-center border-top pt-3 mt-3">
                        <span class="small text-muted">Auteur: <b class="text-dark"><?php echo s($pst['author_name']); ?></b></span>
                        <a href="blog-details.php?slug=<?php echo s($pst['slug']); ?>" class="text-accent fw-bold text-decoration-none small">Read Journal <i class="bi bi-chevron-right fs-9"></i></a>
                    </div>
                </div>
            </div>
        <?php } 
        } ?>
    </div>
</div>

<?php
render_site_footer();
?>
