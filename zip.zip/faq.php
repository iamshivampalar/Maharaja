<?php
/**
 * ProLandmark Elite - Curated FAQ Portal
 * Captures frequently questioned issues categorized neatly inside polished Bootstrap accordions.
 */
require_once 'config.php';

$is_logged = is_logged_in();

$faqs_by_category = [];
if ($db) {
    try {
        $stmt = $db->query("SELECT * FROM faqs ORDER BY category ASC, id DESC");
        while ($row = $stmt->fetch()) {
            $faqs_by_category[$row['category']][] = $row;
        }
    } catch (Exception $e) {}
}

render_site_header("Queries & FAQ Center");
?>

<section class="py-5 bg-white border-bottom">
    <div class="container text-start">
        <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.12em;">DIRECT TRANSPARENCY DEPT</span>
        <h1 class="display-5 fw-bold text-dark luxury-heading mb-1"><i class="bi bi-question-diamond text-accent"></i> Queries & FAQ Center</h1>
        <p class="text-secondary small">Find immediate answers regarding absolute legal deeds, wire transfer closures, developer direct titles, and schedule coordinators.</p>
    </div>
</section>

<div class="container py-5 text-start">
    <div class="row">
        <div class="col-lg-8 mx-auto">
            <?php if (empty($faqs_by_category)) { ?>
                <div class="card p-5 border border-dashed rounded-4 text-center bg-white shadow-sm">
                    <i class="bi bi-info-circle fs-1 text-secondary opacity-35 mb-2"></i>
                    <h4 class="fw-bold text-dark mb-1">FAQ entries under preparation</h4>
                    <p class="text-secondary small mb-3">Our legal council and client advisors are currently drafting core operations manuals.</p>
                    <a href="index.php" class="btn btn-dark rounded-3 px-4 py-2">Back to Dashboard</a>
                </div>
            <?php } else { 
                $accordion_index = 0;
                foreach ($faqs_by_category as $cat_name => $items) {
                    $accordion_index++;
                ?>
                <div class="mb-5">
                    <span class="badge border border-warning text-accent text-uppercase px-2.5 py-1 mb-3 mono" style="font-size: 0.68rem; letter-spacing: 0.05em;"><i class="bi bi-folder2-open"></i> <?php echo s($cat_name); ?></span>
                    
                    <div class="accordion shadow-sm rounded-3 overflow-hidden border" id="acc_<?php echo $accordion_index; ?>">
                        <?php 
                        $item_index = 0;
                        foreach ($items as $faq) { 
                            $item_index++;
                            $unique_id = "collapse_{$accordion_index}_{$item_index}";
                            $head_id = "heading_{$accordion_index}_{$item_index}";
                            ?>
                            <div class="accordion-item bg-white border-bottom border-light">
                                <h2 class="accordion-header" id="<?php echo $head_id; ?>">
                                    <button class="accordion-button collapsed fw-bold text-dark py-3.5 fs-7 bg-white text-start focus-none" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo $unique_id; ?>">
                                        <i class="bi bi-patch-question-fill text-accent me-2"></i> <?php echo s($faq['question']); ?>
                                    </button>
                                </h2>
                                <div id="<?php echo $unique_id; ?>" class="accordion-collapse collapse" data-bs-parent="#acc_<?php echo $accordion_index; ?>">
                                    <div class="accordion-body text-secondary small py-4" style="line-height:1.75; background-color:#fafafa;">
                                        <?php echo nl2br(s($faq['answer'])); ?>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            <?php } 
            } ?>
        </div>
    </div>
</div>

<?php
render_site_footer();
?>
