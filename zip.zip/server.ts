import express from "express";
import path from "path";
import { exec, spawn } from "child_process";
import fs from "fs";

const app = express();
const PORT = 3000;

// Test if PHP is available on this system
exec("php -v", (error, stdout, stderr) => {
  if (error) {
    console.error("PHP not found or failed to execute:", stderr || error.message);
  } else {
    console.log("PHP is available:\n", stdout);
  }
});

// Middleware to parse raw body for PHP standard forwarding
app.use(express.raw({ type: "*/*", limit: "50mb" }));

// Custom PHP execution route handler
const handlePHPRequest = (req: express.Request, res: express.Response) => {
  const urlPath = req.path === "/" ? "/index.php" : req.path;
  const filePath = path.join(process.cwd(), urlPath);

  // If file doesn't exist, try resolving as a static asset first, or rewrite to index.php if appropriate
  if (!fs.existsSync(filePath) || !filePath.endsWith(".php")) {
    const staticFilePath = path.join(process.cwd(), req.path);
    if (fs.existsSync(staticFilePath) && fs.statSync(staticFilePath).isFile()) {
      return res.sendFile(staticFilePath);
    }
    // If it is a clean folder route or routing route, fall back to index.php
    if (fs.existsSync(path.join(filePath, "index.php"))) {
      return res.redirect(path.join(req.path, "index.php"));
    }
    return res.status(404).send("File not found");
  }

  // Construct standard gateway context for the PHP process
  const context = {
    get: req.query,
    cookie: req.cookies || {},
    server: {
      REQUEST_METHOD: req.method,
      REQUEST_URI: req.originalUrl,
      QUERY_STRING: req.url.split("?")[1] || "",
      DOCUMENT_ROOT: process.cwd(),
      SCRIPT_FILENAME: filePath,
      SCRIPT_NAME: urlPath,
      PHP_SELF: urlPath,
      HTTP_HOST: req.get("host") || "localhost",
      HTTP_USER_AGENT: req.get("user-agent") || "",
      HTTP_ACCEPT: req.get("accept") || "",
      HTTP_COOKIE: req.get("cookie") || "",
      CONTENT_TYPE: req.get("content-type") || "",
      CONTENT_LENGTH: req.get("content-length") || "",
      REMOTE_ADDR: req.ip || "127.0.0.1",
      SERVER_NAME: "localhost",
      SERVER_PORT: "3000",
      SERVER_PROTOCOL: "HTTP/1.1",
      HTTPS: req.secure ? "on" : "off",
    }
  };

  // We write a simple bootstrapper inline to bridge Express parameters with plain PHP execution
  const gatewayScript = `<?php
    // Extracted bootstrap
    $ctx = json_decode(base64_decode("${Buffer.from(JSON.stringify(context)).toString("base64")}"), true);
    $_GET = $ctx['get'] ?? [];
    $_COOKIE = $ctx['cookie'] ?? [];
    
    // Parse cookies from headers manually if cookie parser middleware is not present
    if (empty($_COOKIE) && isset($ctx['server']['HTTP_COOKIE'])) {
        parse_str(str_replace('; ', '&', $ctx['server']['HTTP_COOKIE']), $_COOKIE);
    }

    // Merge $_SERVER
    foreach ($ctx['server'] as $k => $v) {
        $_SERVER[$k] = $v;
    }

    // If request is POST, populate $_POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (strpos($_SERVER['CONTENT_TYPE'], 'application/x-www-form-urlencoded') !== false) {
            parse_str(file_get_contents('php://input'), $_POST);
        } else if (strpos($_SERVER['CONTENT_TYPE'], 'multipart/form-data') !== false) {
            // Decoded in php natively if raw payload is fed to stdin
        } else if (strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
            $_POST = json_decode(file_get_contents('php://input'), true) ?? [];
        }
    }

    // Include the actual target file
    include "${filePath.replace(/\\/g, "/")}";
  `;

  // Spawn PHP process feeding gatewayScript as code or executing via temp file
  const tempScriptPath = path.join(process.cwd(), `.gateway_${Date.now()}_${Math.random().toString(36).substring(7)}.php`);
  fs.writeFileSync(tempScriptPath, gatewayScript);

  const phpProcess = spawn("php", ["-d", "variables_order=EGPCS", "-f", tempScriptPath], {
    env: { ...process.env },
  });

  let responseData = Buffer.alloc(0);
  let errorData = "";

  // If request contains body, write to PHP stdin
  if (req.body && req.body.length > 0) {
    phpProcess.stdin.write(req.body);
  }
  phpProcess.stdin.end();

  phpProcess.stdout.on("data", (chunk: Buffer) => {
    responseData = Buffer.concat([responseData, chunk]);
  });

  phpProcess.stderr.on("data", (chunk) => {
    errorData += chunk.toString();
  });

  phpProcess.on("close", (code) => {
    // Delete temp gateway script
    try {
      if (fs.existsSync(tempScriptPath)) fs.unlinkSync(tempScriptPath);
    } catch (e) {}

    if (code !== 0) {
      console.error(`PHP Process exited with code ${code}. Errors:`, errorData);
      return res.status(500).send(`<pre>Internal PHP Error:\n${errorData}\nCode: ${code}</pre>`);
    }

    // Parse Headers and Body from PHP response
    // PHP outputs headers followed by double newline if any header was set, or we can just parse response raw.
    const responseString = responseData.toString("utf-8");
    const headerSplitIdx = responseString.indexOf("\r\n\r\n");
    // Some versions of PHP might output \n\n instead
    const headerSplitIdxLF = responseString.indexOf("\n\n");
    
    let isHeaderFormat = false;
    let headersSection = "";
    let bodySection = responseString;
    let bodyBuffer = responseData;

    // Check if the output looks like custom CGI header-styled output. If not, just send raw body.
    if (responseString.startsWith("X-Powered-By:") || responseString.startsWith("Set-Cookie:") || responseString.startsWith("Location:") || responseString.startsWith("Content-type:")) {
      isHeaderFormat = true;
      const splitIdx = headerSplitIdx !== -1 ? headerSplitIdx : headerSplitIdxLF;
      const splitLen = headerSplitIdx !== -1 ? 4 : 2;
      
      headersSection = responseString.substring(0, splitIdx);
      bodySection = responseString.substring(splitIdx + splitLen);
      bodyBuffer = responseData.slice(splitIdx + splitLen);
    }

    if (isHeaderFormat) {
      const headers = headersSection.split(/\r?\n/);
      headers.forEach((header) => {
        const colonIdx = header.indexOf(":");
        if (colonIdx !== -1) {
          const key = header.substring(0, colonIdx).trim();
          const val = header.substring(colonIdx + 1).trim();
          
          if (key.toLowerCase() === "location") {
            return res.redirect(val);
          }
          if (key.toLowerCase() === "set-cookie") {
            res.append("Set-Cookie", val);
          } else {
            res.setHeader(key, val);
          }
        }
      });
    }

    // Send content
    res.send(bodyBuffer);
  });
};

// Handle all page requests through PHP handler if they match a PHP route or clean paths
app.all("*.php", handlePHPRequest);
app.all("/", handlePHPRequest);

// Serve arbitrary clean path routes (useful for REST API endpoints as well)
app.use((req, res, next) => {
  const possiblePhpFile = path.join(process.cwd(), `${req.path}.php`);
  if (fs.existsSync(possiblePhpFile)) {
    req.url = `${req.path}.php`;
    return handlePHPRequest(req, res);
  }
  next();
});

// Serve asset folders
app.use("/assets", express.static(path.join(process.cwd(), "assets")));
app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
