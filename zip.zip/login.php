<?php
/**
 * ProLandmark Elite - Executive Signature Access Desk
 * Dual authentication for administrators and developers.
 */
require_once 'config.php';

$is_logged = is_logged_in();
if ($is_logged) {
    header("Location: admin/dashboard.php");
    exit;
}

$error_msg = "";
if (isset($_POST['authenticate'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error_msg = "CSRF verification mismatch. Try again.";
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (empty($email) || empty($password)) {
            $error_msg = "Email and security credentials are required.";
        } else {
            try {
                $stmt = $db->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $user = $stmt->fetch();

                if ($user && password_verify($password, $user['password'])) {
                    // Start secure session parameters
                    $_SESSION['uid'] = $user['id'];
                    $_SESSION['uname'] = $user['name'];
                    $_SESSION['uemail'] = $user['email'];
                    $_SESSION['urole'] = $user['role'];

                    log_activity("User Authenticated: " . $user['name'] . " (" . $user['role'] . ")", "Info");
                    header("Location: admin/dashboard.php");
                    exit;
                } else {
                    $error_msg = "Declined. Personal key signature or email mismatch.";
                }
            } catch (Exception $e) {
                $error_msg = "Auth node warning: " . $e->getMessage();
            }
        }
    }
}

render_site_header("Executive Security Portal");
?>

<div class="row pt-5 align-items-center" style="min-height: 70vh;">
    <div class="col-sm-10 col-md-8 col-lg-5 mx-auto text-start">
        <div class="card p-4 p-md-5 border-0 shadow-lg bg-white rounded-4">
            <div class="text-center mb-4">
                <span class="badge border border-warning text-accent text-uppercase mb-2" style="font-size: 0.65rem; letter-spacing: 0.1em; padding: 4px 10px;">Security Vault Access</span>
                <h2 class="fw-bold tracking-tight text-dark m-0 luxury-heading">Executive Sign-in</h2>
                <p class="text-secondary small mt-1">Provide credential keys to enter the Super Admin & Developer Control Centers.</p>
            </div>

            <?php if (!empty($error_msg)) { ?>
                <div class="alert alert-danger border-0 small py-2.5 mb-4 rounded-3 d-flex align-items-center">
                    <i class="bi bi-exclamation-triangle-fill fs-6 me-2"></i>
                    <div><?php echo s($error_msg); ?></div>
                </div>
            <?php } ?>

            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">

                <div class="mb-3">
                    <label class="form-label small fw-semibold text-secondary">Authorized Email Address</label>
                    <div class="input-group bg-light rounded-3 border">
                        <span class="input-group-text border-0 bg-transparent text-secondary"><i class="bi bi-envelope-fill"></i></span>
                        <input type="email" name="email" class="form-control border-0 bg-transparent py-2.5" placeholder="admin@platinum.local" required autocomplete="email">
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label small fw-semibold text-secondary">Security Password Access-Key</label>
                    <div class="input-group bg-light rounded-3 border">
                        <span class="input-group-text border-0 bg-transparent text-secondary"><i class="bi bi-lock-fill"></i></span>
                        <input type="password" name="password" class="form-control border-0 bg-transparent py-2.5" placeholder="••••••••" required autocomplete="current-password">
                    </div>
                </div>

                <button type="submit" name="authenticate" class="btn btn-dark w-full py-3 fs-6 rounded-3 fw-bold mb-3"><i class="bi bi-shield-lock-fill me-1"></i> Authenticate Credentials</button>
            </form>

            <div class="border-top pt-3 text-center">
                <span class="text-secondary small text-xs">Forgot security password configuration? Contact legal counsel/developer division.</span>
                <div class="p-2 bg-light rounded-3 border mt-3 text-start mb-0">
                    <div class="fw-bold text-dark text-xs mb-1 d-flex gap-1 align-items-center"><i class="bi bi-unlock text-accent"></i> Sandbox Authentication Key ring:</div>
                    <ul class="list-unstyled mb-0 text-muted small" style="font-size: 0.72rem;">
                        <li><strong>Super Admin:</strong> <code>admin@platinum.local</code> / <code>admin123</code></li>
                        <li><strong>Developer Control:</strong> <code>dev@platinum.local</code> / <code>dev123</code></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
render_site_footer();
?>
