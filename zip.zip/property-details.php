<?php
/**
 * ProLandmark Elite - Landmark Inspection View
 * Public facing detailed analyzer for individual company-owned luxury assets.
 */
require_once 'config.php';

$is_logged = is_logged_in();
$slug = $_GET['slug'] ?? '';

$property = null;
if ($db && !empty($slug)) {
    try {
        // Fetch property details
        $stmt = $db->prepare("SELECT p.*, c.name as category_name 
                                FROM properties p 
                                LEFT JOIN categories c ON p.category_id = c.id 
                                WHERE p.slug = ? LIMIT 1");
        $stmt->execute([$slug]);
        $property = $stmt->fetch();

        if ($property) {
            // Increment popularity views
            $db->prepare("UPDATE properties SET views = views + 1 WHERE id = ?")->execute([$property['id']]);
        }
    } catch (Exception $e) {
        $db_error = $e->getMessage();
    }
}

// Redirect if invalid slug
if (!$property) {
    header("Location: properties.php");
    exit;
}

// Handle Direct Booking / Inquiry submission over AJAX/PHP Post
$form_msg = "";
$form_status = "";
if (isset($_POST['submit_inquiry'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $form_msg = "CSRF protection signature failed. Refresh page.";
        $form_status = "danger";
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $type = $_POST['type'] ?? 'Inquiry';
        $visit_date = $_POST['visit_date'] ?? '';
        $visit_time = $_POST['visit_time'] ?? '';

        if (empty($name) || empty($email) || empty($phone)) {
            $form_msg = "All formal identification fields (Name, Email, Phone) are mandatory.";
            $form_status = "warning";
        } else {
            try {
                $db->beginTransaction();

                // 1. Insert into leads registry
                $lead_stmt = $db->prepare("INSERT INTO leads (property_id, name, email, phone, message, type, status) VALUES (?, ?, ?, ?, ?, ?, 'New')");
                $lead_stmt->execute([$property['id'], $name, $email, $phone, $message, $type]);
                $lead_id = $db->lastInsertId();

                // 2. If it's a Site Visit booking, schedule the itinerary object
                if ($type === 'Site Visit' && !empty($visit_date)) {
                    $visit_stmt = $db->prepare("INSERT INTO site_visits (lead_id, property_id, visit_date, visit_time, visitor_name, visitor_email, visitor_phone, status, admin_notes) VALUES (?, ?, ?, ?, ?, ?, ?, 'Upcoming', ?)");
                    $visit_stmt->execute([$lead_id, $property['id'], $visit_date, $visit_time, $name, $email, $phone, "Client requested direct site visit for " . $property['title']]);
                    
                    // Update lead status to Site Visit Scheduled
                    $db->prepare("UPDATE leads SET status = 'Site Visit Scheduled' WHERE id = ?")->execute([$lead_id]);
                }

                $db->commit();
                
                log_activity("New direct advisory acquisition inquiry logged for: " . $property['title'], "Info");
                $form_msg = "Formal Acquisition Inquiry logged! Our portfolio manager will contact you via voice line within the hour.";
                $form_status = "success";
            } catch (Exception $e) {
                $db->rollBack();
                $form_msg = "Database binding anomaly: " . $e->getMessage();
                $form_status = "danger";
            }
        }
    }
}

render_site_header($property['title']);
?>

<section class="py-4 bg-light border-bottom">
    <div class="container text-start">
        <nav aria-label="breadcrumb" class="mb-2">
            <ol class="breadcrumb mb-0 small">
                <li class="breadcrumb-item"><a href="index.php" class="text-accent text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="properties.php" class="text-accent text-decoration-none">Properties</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo s($property['title']); ?></li>
            </ol>
        </nav>
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div>
                <span class="badge-status status-<?php echo str_replace(' ', '', $property['status']); ?> badge mb-2"><?php echo s($property['status']); ?></span>
                <h1 class="h2 fw-bold text-dark luxury-heading mb-1"><?php echo s($property['title']); ?></h1>
                <p class="text-secondary small mb-0"><i class="bi bi-geo-alt-fill text-accent"></i> <?php echo s($property['address']); ?>, <?php echo s($property['city']); ?>, <?php echo s($property['state']); ?></p>
            </div>
            <div class="text-md-end">
                <span class="text-secondary small d-block uppercase" style="font-size: 0.65rem; letter-spacing: 0.05em;">ESTABLISHED VALUATION</span>
                <span class="h2 fw-bold text-dark d-block"><?php echo format_price($property['price']); ?></span>
                <span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary border-opacity-20 rounded-pill mt-1" style="font-size: 0.7rem; padding: 4px 10px;">ID: PL-<?php echo $property['id']; ?></span>
            </div>
        </div>
    </div>
</section>

<div class="container py-5 text-start">
    <?php if (!empty($form_msg)) { ?>
        <div class="alert alert-<?php echo $form_status; ?> border-0 shadow-sm rounded-3 py-3 mb-4 d-flex align-items-center">
            <i class="bi bi-patch-check-fill fs-4 me-2"></i>
            <div><strong>Acquisition Desk:</strong> <?php echo s($form_msg); ?></div>
        </div>
    <?php } ?>

    <div class="row g-4">
        <!-- Main Portfolio Content details -->
        <div class="col-lg-8">
            <!-- Media Slide Sandbox Cover -->
            <div class="card p-2 border rounded-4 bg-white shadow-sm mb-4">
                <div class="position-relative" style="height: 480px; background-color:#1e293b; overflow:hidden; border-radius:12px;">
                    <div class="position-absolute w-full h-full d-flex align-items-center justify-content-center" style="background-image: url('https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'); background-size: cover; background-position: center;">
                        <div class="bg-dark bg-opacity-20 w-full h-full"></div>
                    </div>
                    <span class="position-absolute bottom-3 left-3 bg-dark bg-opacity-70 text-white rounded-3 px-3 py-1.5 small"><i class="bi bi-camera me-1"></i> Developer Cinematic Cover</span>
                </div>
                <!-- Mini slide images -->
                <div class="row g-2 mt-2">
                    <div class="col-3">
                        <div class="thumbnail-gallery ratio ratio-4x3 rounded-3" style="background-image: url('https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80'); background-size:cover; background-position:center;"></div>
                    </div>
                    <div class="col-3">
                        <div class="thumbnail-gallery ratio ratio-4x3 rounded-3" style="background-image: url('https://images.unsplash.com/photo-1628744504166-48a040366b04?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80'); background-size:cover; background-position:center;"></div>
                    </div>
                    <div class="col-3">
                        <div class="thumbnail-gallery ratio ratio-4x3 rounded-3" style="background-image: url('https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80'); background-size:cover; background-position:center;"></div>
                    </div>
                    <div class="col-3 d-flex align-items-center justify-content-center bg-light rounded-3 font-sans small text-secondary fw-semibold border">
                        <i class="bi bi-images me-1"></i> Portfolio
                    </div>
                </div>
            </div>

            <!-- Spatial Parameters Bento Panel -->
            <div class="card p-4 border rounded-4 bg-white shadow-sm mb-4">
                <h3 class="h5 fw-bold text-dark luxury-heading mb-3 pb-2 border-bottom">Architectural Details</h3>
                <div class="row g-3">
                    <div class="col-6 col-sm-3 text-center border-end">
                        <span class="text-secondary small text-uppercase">Asset Area</span>
                        <div class="h5 fw-bold text-dark mt-1 mb-0"><?php echo number_format($property['area']); ?> <span class="small font-sans fw-normal text-secondary text-xs">Sq Ft</span></div>
                    </div>
                    <div class="col-6 col-sm-3 text-center border-end">
                        <span class="text-secondary small text-uppercase">Bedrooms</span>
                        <div class="h5 fw-bold text-dark mt-1 mb-0"><?php echo s($property['bedrooms']); ?> Beds</div>
                    </div>
                    <div class="col-6 col-sm-3 text-center border-sm-end">
                        <span class="text-secondary small text-uppercase">Bathrooms</span>
                        <div class="h5 fw-bold text-dark mt-1 mb-0"><?php echo s($property['bathrooms']); ?> Baths</div>
                    </div>
                    <div class="col-6 col-sm-3 text-center">
                        <span class="text-secondary small text-uppercase">Parking Space</span>
                        <div class="h5 fw-bold text-dark mt-1 mb-0"><?php echo s($property['parking']); ?> Slots</div>
                    </div>
                </div>
            </div>

            <!-- Core Elaborative Description -->
            <div class="card p-4 border rounded-4 bg-white shadow-sm mb-4">
                <h3 class="h5 fw-bold text-dark luxury-heading mb-3">Architectural Philosophy</h3>
                <p class="text-secondary small mb-4" style="line-height:1.75;"><?php echo nl2br(s($property['description'])); ?></p>

                <?php if (!empty($property['highlights'])) { ?>
                    <h5 class="fw-bold mb-2">Executive Highlights</h5>
                    <ul class="row g-2 list-unstyled small text-secondary mb-0">
                        <?php 
                        $hl_list = explode(',', $property['highlights']);
                        foreach ($hl_list as $hl) {
                            if (!empty(trim($hl))) {
                                echo "<li class='col-sm-6 d-flex align-items-center gap-2'><i class='bi bi-patch-check-fill text-success fs-7'></i> " . s(trim($hl)) . "</li>";
                            }
                        }
                        ?>
                    </ul>
                <?php } ?>
            </div>

            <!-- Virtual 3D Matterport Tour block -->
            <?php if (!empty($property['virtual_tour_url'])) { ?>
                <div class="card p-4 border rounded-4 bg-white shadow-sm mb-4">
                    <h3 class="h5 fw-bold text-dark luxury-heading mb-3"><i class="bi bi-unity text-accent"></i> 3D Virtual Walkthrough Tour</h3>
                    <p class="text-secondary small mb-3">Interact with the real-world scale model of are owned assets via our responsive laser scan integration.</p>
                    <div class="ratio ratio-16x9 rounded-3 overflow-hidden bg-dark border">
                        <iframe src="<?php echo s($property['virtual_tour_url']); ?>" allowfullscreen allow="xr-spatial-tracking"></iframe>
                    </div>
                </div>
            <?php } ?>

            <!-- Proximity Metrology Map Dashboard -->
            <div class="card p-4 border rounded-4 bg-white shadow-sm mb-4">
                <h3 class="h5 fw-bold text-dark luxury-heading mb-3"><i class="bi bi-geo-fill text-accent"></i> Core Proximity Infrastructure</h3>
                <p class="text-secondary small mb-3">Check local distances below, fully pre-arranged by company land registries:</p>
                <div class="row g-3 text-secondary small">
                    <div class="col-sm-6 p-2 rounded-3 border bg-light bg-opacity-50">
                        <strong class="text-dark d-block mb-1"><i class="bi bi-mortarboard-fill text-primary"></i> Academic Institutions</strong>
                        <span><?php echo s($property['nearby_schools'] ?: 'Private academies within 1.5 km commute radius'); ?></span>
                    </div>
                    <div class="col-sm-6 p-2 rounded-3 border bg-light bg-opacity-50">
                        <strong class="text-dark d-block mb-1"><i class="bi bi-heart-pulse-fill text-danger"></i> Medical Infrastructure</strong>
                        <span><?php echo s($property['nearby_hospitals'] ?: 'Regional Level 1 emergency care blocks within 2.2 km'); ?></span>
                    </div>
                    <div class="col-sm-6 p-2 rounded-3 border bg-light bg-opacity-50">
                        <strong class="text-dark d-block mb-1"><i class="bi bi-cart4 text-warning"></i> Premium Retail Spheres</strong>
                        <span><?php echo s($property['nearby_markets'] ?: 'Bespoke organic grocery chains and luxury high-streets (3 mins)'); ?></span>
                    </div>
                    <div class="col-sm-6 p-2 rounded-3 border bg-light bg-opacity-50">
                        <strong class="text-dark d-block mb-1"><i class="bi bi-train-front-fill text-info"></i> Transit Interchanges</strong>
                        <span><?php echo s($property['nearby_metro'] ?: 'State express interchanges and helipad access coordinates'); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Video Walkthrough Tour -->
            <?php if (!empty($property['video_url'])) { ?>
                <div class="card p-4 border rounded-4 bg-white shadow-sm mb-4">
                    <h3 class="h5 fw-bold text-dark luxury-heading mb-3"><i class="bi bi-film text-accent"></i> Asset Walkthrough Video</h3>
                    <div class="ratio ratio-16x9 rounded-3 overflow-hidden bg-dark border">
                        <iframe src="<?php echo s($property['video_url']); ?>" allowfullscreen></iframe>
                    </div>
                </div>
            <?php } ?>
        </div>

        <!-- Right Side Direct Acquisition advisory form -->
        <div class="col-lg-4">
            <div class="sticky-top" style="top: 100px;">
                <!-- Advisory desk Contact Card -->
                <div class="card p-4 border rounded-4 bg-white shadow-sm mb-4">
                    <div class="text-center mb-4">
                        <span class="badge bg-dark bg-opacity-5 text-dark border p-2 mb-2"><i class="bi bi-telephone-inbound-fill text-accent me-1"></i> Direct Advisory Desk</span>
                        <h4 class="fw-bold tracking-tight text-dark m-0">Direct Asset Inquiry</h4>
                        <p class="text-secondary small mt-1 mb-0">Speak straight with the actual asset owner, bypassing retial broker markup pipelines.</p>
                    </div>

                    <form method="POST" action="">
                        <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                        
                        <div class="mb-3">
                            <label class="form-label small fw-semibold text-secondary">Contact Option</label>
                            <select name="type" id="typeSelector" class="form-select border bg-light py-2" onchange="toggleSiteVisitForm()">
                                <option value="Inquiry">Direct Document Inquiry</option>
                                <option value="Site Visit">Schedule Private Site Visit</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-semibold text-secondary">Your Name</label>
                            <input type="text" name="name" class="form-control border bg-light py-2" placeholder="Marcus Vance" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-semibold text-secondary">Your Private Email</label>
                            <input type="email" name="email" class="form-control border bg-light py-2" placeholder="marcus@vancecapital.com" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-semibold text-secondary">Direct Telephone</label>
                            <input type="tel" name="phone" class="form-control border bg-light py-2" placeholder="+1 (555) 0199" required>
                        </div>

                        <!-- Site Visit Conditional Parameters -->
                        <div id="siteVisitSection" style="display: none;" class="p-3 bg-light rounded-3 border border-dashed mb-3">
                            <h5 class="fw-bold text-dark mb-2" style="font-size: 0.85rem;"><i class="bi bi-calendar-check text-accent"></i> Date & Time Allocation</h5>
                            <div class="mb-2">
                                <label class="form-label small text-muted mb-1" style="font-size: 0.72rem;">Preferred Date</label>
                                <input type="date" name="visit_date" class="form-control border bg-white py-1.5 fs-7">
                            </div>
                            <div>
                                <label class="form-label small text-muted mb-1" style="font-size: 0.72rem;">Preferred Hour Slot</label>
                                <select name="visit_time" class="form-select border bg-white py-1.5 fs-7">
                                    <option value="09:00 AM - 12:00 PM">Morning: 09:00 AM - 12:00 PM</option>
                                    <option value="12:00 PM - 03:00 PM">Midday: 12:00 PM - 03:00 PM</option>
                                    <option value="03:00 PM - 06:00 PM">Evening: 03:00 PM - 06:00 PM</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-semibold text-secondary">Aquisition Message Notes</label>
                            <textarea name="message" class="form-control border bg-light" rows="3" placeholder="State preferred closing windows or title allocations..."></textarea>
                        </div>

                        <button type="submit" name="submit_inquiry" class="btn btn-accent w-full py-2.5 rounded-3 fw-bold"><i class="bi bi-chevron-right me-1"></i> File Official Request</button>
                    </form>

                    <div class="d-flex justify-content-center border-top pt-3 gap-2 text-xs text-muted mt-3">
                        <span><i class="bi bi-shield-lock-fill text-success"></i> 256-Bit Encrypted</span>
                        <span>&bull;</span>
                        <span><i class="bi bi-person-fill-check text-success"></i> Strict Direct Ownership</span>
                    </div>
                </div>

                <!-- Auxiliary PDF Download card -->
                <div class="card p-3 border rounded-4 bg-dark text-white text-start">
                    <h5 class="fw-bold mb-1 mr-0" style="font-size: 0.9rem;"><i class="bi bi-file-earmark-pdf-fill text-danger"></i> Asset Prospectus Brochure</h5>
                    <p class="text-secondary mb-3 mt-1" style="font-size: 0.75rem;">Download complete engineering blueprints, core legal deeds, and survey validation maps.</p>
                    <a href="index.php?download=pdf" onclick="alert('Corporate Asset Deed is compiled dynamically and sent on direct physical signoff. For sandbox testing, secure download link mapped successfully.'); return false;" class="btn btn-sm btn-outline-light w-full py-2">Express Export PDF Deck</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function toggleSiteVisitForm() {
    const selector = document.getElementById('typeSelector');
    const sect = document.getElementById('siteVisitSection');
    if (selector.value === 'Site Visit') {
        sect.style.display = 'block';
    } else {
        sect.style.display = 'none';
    }
}
</script>

<?php
render_site_footer();
?>
