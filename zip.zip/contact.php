<?php
/**
 * ProLandmark Elite - Advisory Desk Contact & Site Visit Booking Portal
 * Integrates WhatsApp quick-links, physical headquarters blocks, dynamic Google Maps iframes, and AJAX inquiry logs.
 */
require_once 'config.php';

$is_logged = is_logged_in();

// Pre-fill fields if requested from CTAs
$pre_action = $_GET['action'] ?? 'contact';
$sel_type = ($pre_action === 'book') ? 'Site Visit' : 'Inquiry';

$form_msg = "";
$form_status = "";

if (isset($_POST['submit_contact'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $form_msg = "CSRF verification mismatch. Refresh page.";
        $form_status = "danger";
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $type = $_POST['type'] ?? 'Inquiry';
        $visit_date = $_POST['visit_date'] ?? null;
        $visit_time = $_POST['visit_time'] ?? null;

        if (empty($name) || empty($email) || empty($phone)) {
            $form_msg = "All operational parameters (Name, Email, Phone) are mandatory.";
            $form_status = "warning";
        } else {
            try {
                $db->beginTransaction();

                // Insert lead file
                $stmt = $db->prepare("INSERT INTO leads (name, email, phone, message, type, status) VALUES (?, ?, ?, ?, ?, 'New')");
                $stmt->execute([$name, $email, $phone, $message, $type]);
                $lead_id = $db->lastInsertId();

                if ($type === 'Site Visit' && !empty($visit_date)) {
                    $v_stmt = $db->prepare("INSERT INTO site_visits (lead_id, visit_date, visit_time, visitor_name, visitor_email, visitor_phone, status, admin_notes) VALUES (?, ?, ?, ?, ?, ?, 'Upcoming', ?)");
                    $v_stmt->execute([$lead_id, $visit_date, $visit_time, $name, $email, $phone, "Client initiated site tour book from contact page."]);
                    
                    $db->prepare("UPDATE leads SET status = 'Site Visit Scheduled' WHERE id = ?")->execute([$lead_id]);
                }

                $db->commit();
                log_activity("Logged general advisory client letter from: " . $name, "Info");
                $form_msg = "Thank you! Your direct direct letter was received on our secure desk. An executive advisor will initiate contact shortly.";
                $form_status = "success";
            } catch (Exception $e) {
                $db->rollBack();
                $form_msg = "Writing error: " . $e->getMessage();
                $form_status = "danger";
            }
        }
    }
}

render_site_header("Advisory Desk");
?>

<section class="py-5 bg-white border-bottom">
    <div class="container text-start">
        <span class="text-accent font-sans text-uppercase fw-bold text-spacing small" style="letter-spacing: 0.12em;">EXECUTIVE COMMUNICATIONS UNIT</span>
        <h1 class="display-5 fw-bold text-dark luxury-heading mb-1"><i class="bi bi-chat-left-text text-accent"></i> Core Advisory Desk</h1>
        <p class="text-secondary small">Initiate direct wire discussions, request asset prospectus deeds, or allocate site walkthrough itineraries.</p>
    </div>
</section>

<div class="container py-5 text-start">
    <?php if (!empty($form_msg)) { ?>
        <div class="alert alert-<?php echo $form_status; ?> border-0 shadow-sm rounded-3 py-3 mb-4 d-flex align-items-center">
            <i class="bi bi-patch-check-fill fs-4 me-2 text-white"></i>
            <div><strong>Advisory desk response:</strong> <?php echo s($form_msg); ?></div>
        </div>
    <?php } ?>

    <div class="row g-5">
        <!-- Contact Form Box -->
        <div class="col-lg-6">
            <div class="card p-4 p-md-5 border-0 shadow-sm bg-white rounded-4">
                <h3 class="fw-bold text-dark luxury-heading mb-3" style="font-size:1.45rem;">Direct Communication Request</h3>
                <p class="text-secondary small mb-4 mt-1">Submit your parameters. This desk contains zero external brokers. You correspond straight with the actual corporate holder.</p>

                <form method="POST" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Classification of request</label>
                        <select name="type" id="contSelector" class="form-select border bg-light py-2" onchange="toggleContactVisitForm()">
                            <option value="Inquiry" <?php echo ($sel_type === 'Inquiry') ? 'selected' : ''; ?>>General Document Request Inquiry</option>
                            <option value="Site Visit" <?php echo ($sel_type === 'Site Visit') ? 'selected' : ''; ?>>Book Exclusive Site Walkthrough</option>
                        </select>
                    </div>

                    <div class="row g-2">
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-semibold text-secondary">Your Private Name</label>
                            <input type="text" name="name" class="form-control border bg-light py-2" placeholder="e.g. Marcus Vance" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-semibold text-secondary">Private Email Address</label>
                            <input type="email" name="email" class="form-control border bg-light py-2" placeholder="e.g. marcus@vance.com" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-secondary">Personal Active Telephone Hotline</label>
                        <input type="tel" name="phone" class="form-control border bg-light py-2" placeholder="e.g. +1 (800) 555-0199" required>
                    </div>

                    <!-- Visit scheduler panel conditional -->
                    <div id="contVisitSection" <?php echo ($sel_type === 'Site Visit') ? 'style="display:block;"' : 'style="display:none;"'; ?> class="p-3 bg-light rounded-3 border border-dashed mb-3">
                        <h5 class="fw-bold text-dark mb-2" style="font-size:0.82rem;"><i class="bi bi-calendar2-range text-accent"></i> Date Coordinates Schedule Settings</h5>
                        <div class="row g-2">
                            <div class="col-6">
                                <label class="form-label text-secondary small" style="font-size:0.7rem;">Target Date</label>
                                <input type="date" name="visit_date" class="form-control bg-white border py-1.5 fs-7">
                            </div>
                            <div class="col-6">
                                <label class="form-label text-secondary small" style="font-size:0.7rem;">Preferred Hour Slot</label>
                                <select name="visit_time" class="form-select bg-white border py-1.5 fs-7">
                                    <option value="09:00 AM - 12:00 PM">Morning: 09:00 AM - 12:00 PM</option>
                                    <option value="12:00 PM - 03:00 PM">Midday: 12:00 PM - 03:00 PM</option>
                                    <option value="03:00 PM - 06:00 PM">Evening: 03:00 PM - 06:00 PM</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-semibold text-secondary">Inquiry Statement Letter / Details</label>
                        <textarea name="message" class="form-control border bg-light" rows="4" placeholder="Detail acquisition timelines or parameters..."></textarea>
                    </div>

                    <button type="submit" name="save_contact" class="btn btn-dark w-full py-2.5 rounded-3 fw-bold"><i class="bi bi-envelope-open me-1"></i> File Direct Inquiry Statement</button>
                </form>
            </div>
        </div>

        <!-- Headquarters Info & Maps -->
        <div class="col-lg-6">
            <div class="card p-4 border rounded-4 bg-white shadow-sm mb-4">
                <h4 class="fw-bold mb-3 text-dark luxury-heading" style="font-size:1.25rem;"><i class="bi bi-buildings text-accent"></i> Headquarters Executive Hub</h4>
                <div class="d-flex flex-column gap-3 small text-secondary">
                    <div class="d-flex align-items-start gap-2.5">
                        <i class="bi bi-geo-alt-fill text-accent text-xl mt-0.5"></i>
                        <div>
                            <strong class="text-dark d-block">Corporate Office Seat</strong>
                            <span><?php echo s($app_office_address); ?></span>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-2.5">
                        <i class="bi bi-envelope-fill text-accent text-xl"></i>
                        <div>
                            <strong class="text-dark d-block">Private Advisory Vector</strong>
                            <span><?php echo s($app_contact_email); ?></span>
                        </div>
                    </div>

                    <div class="d-flex align-items-center gap-2.5">
                        <i class="bi bi-telephone-fill text-accent text-xl"></i>
                        <div>
                            <strong class="text-dark d-block">Voice Direct Desk</strong>
                            <span><?php echo s($app_contact_phone); ?></span>
                        </div>
                    </div>
                </div>

                <div class="row g-2 mt-4">
                    <div class="col-sm-6">
                        <a href="https://wa.me/<?php echo s($app_whatsapp_number); ?>" target="_blank" class="btn btn-outline-success border-success-subtle w-full text-success py-2.5 text-xs font-semibold rounded-3"><i class="bi bi-whatsapp me-1"></i> Advisory whatsapp</a>
                    </div>
                    <div class="col-sm-6">
                        <a href="tel:<?php echo s($app_contact_phone); ?>" class="btn btn-outline-dark w-full py-2.5 text-xs font-semibold rounded-3"><i class="bi bi-telephone-plus me-1"></i> Hotline call desk</a>
                    </div>
                </div>
            </div>

            <!-- Interative Google maps frame -->
            <?php if (!empty($app_maps_embed)) { ?>
                <div class="card p-2 border rounded-4 bg-white shadow-sm overflow-hidden" style="height: 330px;">
                    <?php echo $app_maps_embed; ?>
                </div>
            <?php } else { ?>
                <div class="card p-2 border rounded-4 bg-white shadow-sm overflow-hidden" style="height: 330px;">
                    <!-- Static Fallback map placeholder standard map embed -->
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12087.640055050882!2d-73.98784408459424!3d40.75798997932688!2m3!1f0!2f0!3f0!3m2!1i1024!2i1024!4f13.1!3m3!1m2!1s0x89c25859e9c99d21%3A0xe54ef37d2f9af241!2sTimes%20Square!5e0!3m2!1sen!2sus!4v1689234857489!5m2!1sen!2sus" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            <?php } ?>
        </div>
    </div>
</div>

<script>
function toggleContactVisitForm() {
    const sel = document.getElementById('contSelector');
    const sect = document.getElementById('contVisitSection');
    if (sel.value === 'Site Visit') {
        sect.style.display = 'block';
    } else {
        sect.style.display = 'none';
    }
}
</script>

<?php
render_site_footer();
?>
