<?php
/**
 * ProLandmark Elite - Curator Property Directory
 * Premium search & filtering matrix for executive assets.
 */
require_once 'config.php';

$is_logged = is_logged_in();

// Handle search query builder
$keyword = $_GET['keyword'] ?? '';
$cat_slug = $_GET['category'] ?? '';
$status = $_GET['status'] ?? '';
$type = $_GET['type'] ?? '';
$beds = $_GET['beds'] ?? '';
$price_max = $_GET['price_max'] ?? '';
$sort = $_GET['sort'] ?? 'views_desc';

$sql = "SELECT p.*, c.name as category_name, c.slug as category_slug 
        FROM properties p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE 1=1";

$params = [];

if (!empty($keyword)) {
    $sql .= " AND (p.title LIKE ? OR p.description LIKE ? OR p.city LIKE ? OR p.address LIKE ?)";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
}

if (!empty($cat_slug)) {
    $sql .= " AND c.slug = ?";
    $params[] = $cat_slug;
}

if (!empty($status)) {
    $sql .= " AND p.status = ?";
    $params[] = $status;
}

if (!empty($type)) {
    $sql .= " AND p.type = ?";
    $params[] = $type;
}

if (!empty($beds)) {
    $sql .= " AND p.bedrooms >= ?";
    $params[] = intval($beds);
}

if (!empty($price_max)) {
    $sql .= " AND p.price <= ?";
    $params[] = intval($price_max);
}

// Sorting logic
switch ($sort) {
    case 'price_asc':
        $sql .= " ORDER BY p.price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY p.price DESC";
        break;
    case 'area_desc':
        $sql .= " ORDER BY p.area DESC";
        break;
    case 'newest':
        $sql .= " ORDER BY p.id DESC";
        break;
    case 'views_desc':
    default:
        $sql .= " ORDER BY p.views DESC";
        break;
}

$properties = [];
$categories = [];
$cities = [];

if ($db) {
    try {
        // Fetch properties matching criteria
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $properties = $stmt->fetchAll();

        // Fetch categories list for filters map
        $categories = $db->query("SELECT * FROM categories ORDER BY name ASC")->fetchAll();
        
        // Fetch distinct cities in database to expand filters
        $cities = $db->query("SELECT DISTINCT city FROM properties ORDER BY city ASC")->fetchAll();
    } catch (Exception $e) {
        $db_error = $e->getMessage();
    }
}

render_site_header("Corporate Asset Directory");
?>

<section class="py-5 bg-white border-bottom">
    <div class="container text-start">
        <h1 class="display-5 fw-bold text-dark luxury-heading mb-1"><i class="bi bi-buildings text-accent"></i> Properties Portfolio</h1>
        <p class="text-secondary small">Review exclusive real estate assets completely pre-vetted, designed, owned, and offered directly from our institutional pool.</p>
    </div>
</section>

<div class="container py-5 text-start">
    <div class="row g-4">
        <!-- Sidebar Filter Form Dashboard -->
        <div class="col-lg-4">
            <div class="card p-4 border rounded-4 bg-white sticky-top shadow-sm" style="top: 100px; z-index:10;">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
                    <h5 class="fw-bold m-0 d-flex align-items-center gap-1"><i class="bi bi-funnel-fill text-accent"></i> Filter Portfolio</h5>
                    <a href="properties.php" class="text-muted text-xs text-decoration-none">Reset filters</a>
                </div>

                <form method="GET" action="properties.php" class="d-flex flex-column gap-3">
                    <div>
                        <label class="form-label small fw-semibold text-secondary">Keyword Search</label>
                        <div class="input-group bg-light rounded-3">
                            <span class="input-group-text border-0 bg-transparent text-secondary"><i class="bi bi-search"></i></span>
                            <input type="text" name="keyword" value="<?php echo s($keyword); ?>" class="form-control border-0 bg-transparent py-2" placeholder="Title, address, city...">
                        </div>
                    </div>

                    <div>
                        <label class="form-label small fw-semibold text-secondary">Architectural Range</label>
                        <select name="category" class="form-select border rounded-3 bg-light py-2">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $cat) { ?>
                                <option value="<?php echo s($cat['slug']); ?>" <?php echo ($cat_slug == $cat['slug']) ? 'selected' : ''; ?>>
                                    <?php echo s($cat['name']); ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div>
                        <label class="form-label small fw-semibold text-secondary">Development Status</label>
                        <select name="status" class="form-select border rounded-3 bg-light py-2">
                            <option value="">All Statuses</option>
                            <option value="For Sale" <?php echo ($status == 'For Sale') ? 'selected' : ''; ?>>For Sale</option>
                            <option value="Ready To Move" <?php echo ($status == 'Ready To Move') ? 'selected' : ''; ?>>Ready To Move</option>
                            <option value="Under Construction" <?php echo ($status == 'Under Construction') ? 'selected' : ''; ?>>Under Construction</option>
                            <option value="Upcoming" <?php echo ($status == 'Upcoming') ? 'selected' : ''; ?>>Upcoming Release</option>
                        </select>
                    </div>

                    <div>
                        <label class="form-label small fw-semibold text-secondary">Property Type</label>
                        <select name="type" class="form-select border rounded-3 bg-light py-2">
                            <option value="">All Types</option>
                            <option value="Apartment" <?php echo ($type == 'Apartment') ? 'selected' : ''; ?>>Apartment</option>
                            <option value="Villa" <?php echo ($type == 'Villa') ? 'selected' : ''; ?>>Villa</option>
                            <option value="Office" <?php echo ($type == 'Office') ? 'selected' : ''; ?>>Premium Office</option>
                            <option value="Land" <?php echo ($type == 'Land') ? 'selected' : ''; ?>>Development Land</option>
                        </select>
                    </div>

                    <div>
                        <label class="form-label small fw-semibold text-secondary">Minimum Bedrooms</label>
                        <select name="beds" class="form-select border rounded-3 bg-light py-2">
                            <option value="">Any Range</option>
                            <option value="2" <?php echo ($beds == '2') ? 'selected' : ''; ?>>2+ Beds</option>
                            <option value="4" <?php echo ($beds == '4') ? 'selected' : ''; ?>>4+ Beds</option>
                            <option value="6" <?php echo ($beds == '6') ? 'selected' : ''; ?>>6+ Beds</option>
                        </select>
                    </div>

                    <div>
                        <label class="form-label small fw-semibold text-secondary">Maximum Budget ($)</label>
                        <input type="number" name="price_max" value="<?php echo s($price_max); ?>" class="form-control border bg-light py-2" placeholder="e.g. 15000000">
                    </div>

                    <div>
                        <label class="form-label small fw-semibold text-secondary">Corporate Order</label>
                        <select name="sort" class="form-select border rounded-3 bg-light py-2">
                            <option value="views_desc" <?php echo ($sort == 'views_desc') ? 'selected' : ''; ?>>Sort: Corporate Popularity</option>
                            <option value="price_asc" <?php echo ($sort == 'price_asc') ? 'selected' : ''; ?>>Sort: Budget (Low to High)</option>
                            <option value="price_desc" <?php echo ($sort == 'price_desc') ? 'selected' : ''; ?>>Sort: Budget (High to Low)</option>
                            <option value="area_desc" <?php echo ($sort == 'area_desc') ? 'selected' : ''; ?>>Sort: Square Footage (Descending)</option>
                            <option value="newest" <?php echo ($sort == 'newest') ? 'selected' : ''; ?>>Sort: Fresh Release Listings</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-dark py-2.5 rounded-3 fw-bold mt-2"><i class="bi bi-funnel"></i> Apply Filter Criteria</button>
                </form>
            </div>
        </div>

        <!-- Property Grid Container -->
        <div class="col-lg-8">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2 pb-2">
                <span class="text-secondary small fw-medium">Database query matches <b class="text-dark"><?php echo count($properties); ?></b> company-owned assets.</span>
                <div class="badge bg-secondary p-2 bg-opacity-10 text-secondary"><i class="bi bi-shield-shaded me-1"></i> Under Direct Custody</div>
            </div>

            <?php if (isset($db_error)) { ?>
                <div class="alert alert-danger p-3 border-0 rounded-3">
                    <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i>
                    <strong>System Error:</strong> <?php echo s($db_error); ?>
                </div>
            <?php } ?>

            <?php if (empty($properties)) { ?>
                <div class="card border border-dashed rounded-4 p-5 text-center bg-white">
                    <div class="py-5">
                        <i class="bi bi-search fs-1 text-secondary opacity-50 mb-3 block"></i>
                        <h4 class="fw-bold text-dark mb-1">No Matching Assets Registered</h4>
                        <p class="text-secondary small mb-4">Adjust your parameters or reset filter panels to review adjacent direct portfolios.</p>
                        <a href="properties.php" class="btn btn-accent rounded-3 px-4 py-2">Clear Parameters</a>
                    </div>
                </div>
            <?php } else { ?>
                <div class="row g-4">
                    <?php foreach ($properties as $prop) { ?>
                        <div class="col-md-6">
                            <div class="card-property h-full d-flex flex-column justify-content-between">
                                <div>
                                    <div class="position-relative" style="height: 220px; background-color: #1e293b; overflow: hidden;">
                                        <div class="position-absolute w-full h-full d-flex align-items-center justify-content-center bg-cover-temp" style="background-image: url('https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&q=80'); background-size: cover; background-position: center;">
                                            <div class="bg-dark bg-opacity-30 w-full h-full"></div>
                                        </div>
                                        <span class="position-absolute top-3 left-3 badge-status status-<?php echo str_replace(' ', '', $prop['status']); ?> badge"><?php echo s($prop['status']); ?></span>
                                        <span class="position-absolute bottom-3 left-3 bg-dark text-white rounded-2 px-2.5 py-1 small fw-bold mono"><?php echo s($prop['type']); ?></span>
                                    </div>
                                    
                                    <div class="p-4 text-start">
                                        <span class="text-accent font-sans text-uppercase fw-bold" style="font-size: 0.72rem; letter-spacing: 0.08em;"><?php echo s($prop['category_name'] ?: 'Luxury Estate'); ?></span>
                                        <h4 class="fw-bold text-dark fs-5 mt-1 mb-2 tracking-tight"><?php echo s($prop['title']); ?></h4>
                                        <p class="text-secondary small mb-3 description-trim-2" style="line-height:1.6; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;"><?php echo s($prop['short_description']); ?></p>
                                        
                                        <div class="d-flex gap-3 text-secondary border-top pt-3 small flex-wrap">
                                            <span class="d-flex align-items-center gap-1"><i class="bi bi-aspect-ratio text-accent"></i> <?php echo number_format($prop['area']); ?> Sq Ft</span>
                                            <?php if ($prop['bedrooms'] > 0) { ?>
                                                <span class="d-flex align-items-center gap-1"><i class="bi bi-heart text-accent"></i> <?php echo s($prop['bedrooms']); ?> Beds</span>
                                            <?php } ?>
                                            <?php if ($prop['bathrooms'] > 0) { ?>
                                                <span class="d-flex align-items-center gap-1"><i class="bi bi-water text-accent"></i> <?php echo s($prop['bathrooms']); ?> Baths</span>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="p-4 border-top bg-light d-flex justify-content-between align-items-center rounded-bottom mt-auto">
                                    <div>
                                        <span class="text-secondary small d-block" style="font-size: 0.65rem; text-transform:uppercase;">Direct developer valuation</span>
                                        <span class="fs-4 fw-bold text-dark"><?php echo format_price($prop['price']); ?></span>
                                    </div>
                                    <a href="property-details.php?slug=<?php echo s($prop['slug']); ?>" class="btn btn-dark btn-sm rounded-3 px-3 py-2 fw-medium">Inspect Direct</a>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
    </div>
</div>

<?php
render_site_footer();
?>
