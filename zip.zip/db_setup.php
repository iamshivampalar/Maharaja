<?php
/**
 * ProLandmark Elite - Enterprise Database Deployment & Backup Engine
 * Fully compatible with standard cPanel hosting environment.
 */
require_once 'config.php';

$mysql_schema = "
-- =========================================================================
-- PROLANDMARK ELITE - HIGH-END ENTERPRISE SCHEMA (MySQL 8 READY)
-- =========================================================================

CREATE TABLE IF NOT EXISTS site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    site_name VARCHAR(255) NOT NULL,
    company_name VARCHAR(255) NOT NULL,
    tagline VARCHAR(255) DEFAULT NULL,
    logo_url TEXT,
    favicon_url TEXT,
    primary_color VARCHAR(50) DEFAULT '#0f172a',
    secondary_color VARCHAR(50) DEFAULT '#1e293b',
    accent_color VARCHAR(50) DEFAULT '#c5a880',
    font_family VARCHAR(100) DEFAULT 'Inter',
    footer_text TEXT,
    contact_email VARCHAR(255) DEFAULT 'contact@elitepartners.com',
    contact_phone VARCHAR(100) DEFAULT '+1 (800) 555-0199',
    whatsapp_number VARCHAR(100) DEFAULT '18005550199',
    office_address TEXT,
    maps_embed TEXT,
    seo_meta_title VARCHAR(255) DEFAULT NULL,
    seo_meta_description TEXT,
    about_heading TEXT,
    about_body TEXT,
    about_history TEXT,
    about_mission TEXT,
    about_vision TEXT,
    established_year VARCHAR(255) DEFAULT NULL,
    completed_projects VARCHAR(255) DEFAULT NULL,
    capital_reserves VARCHAR(255) DEFAULT NULL,
    active_theme VARCHAR(50) DEFAULT 'luxury'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('Super Admin', 'Developer') DEFAULT 'Super Admin',
    ip_restriction VARCHAR(255) DEFAULT NULL,
    tfa_enabled TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) UNIQUE NOT NULL,
    slug VARCHAR(255) NOT NULL,
    icon_class VARCHAR(100) DEFAULT 'bi-building'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS properties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT DEFAULT NULL,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    description TEXT NOT NULL,
    short_description TEXT NOT NULL,
    highlights TEXT,
    features TEXT,
    amenities TEXT,
    address TEXT NOT NULL,
    city VARCHAR(255) NOT NULL,
    state VARCHAR(255) NOT NULL,
    country VARCHAR(100) DEFAULT 'United States',
    pin_code VARCHAR(50) DEFAULT NULL,
    latitude DOUBLE DEFAULT 0,
    longitude DOUBLE DEFAULT 0,
    price INT NOT NULL,
    area INT NOT NULL,
    bedrooms INT DEFAULT 0,
    bathrooms INT DEFAULT 0,
    parking INT DEFAULT 0,
    balconies INT DEFAULT 0,
    floor_plan_url TEXT,
    brochure_url TEXT,
    video_url TEXT,
    virtual_tour_url TEXT,
    nearby_schools TEXT,
    nearby_hospitals TEXT,
    nearby_markets TEXT,
    nearby_metro TEXT,
    status ENUM('For Sale', 'Ready To Move', 'Under Construction', 'Sold', 'Upcoming') DEFAULT 'Ready To Move',
    type ENUM('Apartment', 'Flat', 'Villa', 'House', 'Farm House', 'Commercial', 'Office', 'Shop', 'Land', 'Plot', 'Warehouse') DEFAULT 'Apartment',
    featured TINYINT(1) DEFAULT 0,
    views INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS property_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    property_id INT NOT NULL,
    image_url TEXT NOT NULL,
    sort_order INT DEFAULT 0,
    FOREIGN KEY(property_id) REFERENCES properties(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS leads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    property_id INT DEFAULT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(255) NOT NULL,
    message TEXT,
    type ENUM('Inquiry', 'Contact Form', 'Site Visit') DEFAULT 'Inquiry',
    status ENUM('New', 'Contacted', 'Interested', 'Site Visit Scheduled', 'Negotiation', 'Closed') DEFAULT 'New',
    assigned_to INT DEFAULT NULL,
    notes TEXT,
    interaction_history TEXT,
    reminder_date DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS site_visits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lead_id INT DEFAULT NULL,
    property_id INT DEFAULT NULL,
    visit_date DATE NOT NULL,
    visit_time VARCHAR(100) NOT NULL,
    visitor_name VARCHAR(255) NOT NULL,
    visitor_email VARCHAR(255) NOT NULL,
    visitor_phone VARCHAR(255) NOT NULL,
    status ENUM('Upcoming', 'Completed', 'Cancelled') DEFAULT 'Upcoming',
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blogs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    author_name VARCHAR(255) DEFAULT 'Media Relations',
    content TEXT NOT NULL,
    featured_image TEXT,
    meta_title VARCHAR(255) DEFAULT NULL,
    meta_desc TEXT,
    tags TEXT,
    views INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS testimonials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_name VARCHAR(255) NOT NULL,
    client_title VARCHAR(255) NOT NULL,
    rating INT DEFAULT 5,
    review TEXT NOT NULL,
    video_testimonial_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS faqs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(255) NOT NULL,
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_name VARCHAR(255),
    action_performed TEXT NOT NULL,
    severity VARCHAR(50) DEFAULT 'Info',
    ip_address VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- SEED INITAL ORGANIZATIONAL PROFILE
INSERT IGNORE INTO site_settings (id, site_name, company_name, tagline, primary_color, secondary_color, accent_color, font_family, footer_text, office_address, seo_meta_title, seo_meta_description, active_theme) VALUES 
(1, 'Platinum Holdings', 'Platinum Holdings Real Estate Group', 'Elite Developer-Owned Acquisitions', '#0f172a', '#1e293b', '#c5a880', 'Inter', 'Platinum Holdings Real Estate Group. All assets fully owned, developed and distributed directly.', '742 Platinum Boulevard, Tower A, Elite Metropolis', 'Platinum Holdings - Luxury Real Estate Portfolio', 'Discover ultra-private real estate assets and direct developer acquisitions.', 'luxury');
";

$message = "";
$status_class = "";

if (isset($_POST['install_mysql'])) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $message = "CSRF Verification challenge failed.";
        $status_class = "danger";
    } else {
        try {
            $test_db = get_db_connection();
            if ($test_db && strpos($_SESSION['sys_db_mode'] ?? '', 'MySQL') !== false) {
                // Split queries and execute sequentially to avoid multi-statement blocks execution failures
                $queries = explode(';', $mysql_schema);
                $exec_count = 0;
                foreach ($queries as $q) {
                    $q_trimmed = trim($q);
                    if (!empty($q_trimmed)) {
                        $test_db->exec($q_trimmed);
                        $exec_count++;
                    }
                }
                $message = "Database installation completed successfully! Executed " . $exec_count . " relational statements.";
                $status_class = "success";
                log_activity("Executed production MySQL database setup builder", "Warning");
            } else {
                $message = "Warning: The application is running in SQLite Fallback Sandbox. Configure your MySQL details inside config.php first to build MySQL tables.";
                $status_class = "warning";
            }
        } catch (PDOException $e) {
            $message = "Execution failed: " . $e->getMessage();
            $status_class = "danger";
        }
    }
}

render_site_header("System Database Manager");
?>

<div class="row pt-4">
    <div class="col-lg-8 mx-auto">
        <div class="card mb-4 border-0 shadow-sm p-4 bg-white rounded-3">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                <div>
                    <h1 class="h3 fw-bold tracking-tight mb-1 luxury-heading"><i class="bi bi-database-check text-accent me-2"></i>Database Deployment Center</h1>
                    <p class="text-secondary small mb-0">Prepare, test, and build database structures for production deployment or private sandbox testing.</p>
                </div>
                <a href="index.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i> Public Catalog</a>
            </div>

            <?php if (!empty($message)) { ?>
                <div class="alert alert-<?php echo $status_class; ?> d-flex align-items-center py-3 mb-4 border-0 rounded-3">
                    <i class="bi bi-info-circle-fill fs-5 me-2"></i>
                    <div><strong>System Response:</strong> <?php echo s($message); ?></div>
                </div>
            <?php } ?>

            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <div class="p-3 bg-light rounded-3 border">
                        <span class="text-secondary small text-uppercase tracking-wider">Active Connectivity Mode</span>
                        <div class="fw-bold text-dark fs-5 mt-1 d-flex align-items-center gap-1">
                            <i class="bi bi-circle-fill text-success fs-8"></i>
                            <?php echo s($_SESSION['sys_db_mode'] ?? 'Connecting...'); ?>
                        </div>
                        <p class="small text-muted mt-2 mb-0">The core includes smart failover: if MySQL configurations fail inside <code>config.php</code>, it auto-initializes standard SQLite schemas locally.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="p-3 bg-light rounded-3 border">
                        <span class="text-secondary small text-uppercase tracking-wider">Production Setup Standards</span>
                        <div class="fw-bold text-success fs-5 mt-1 d-flex align-items-center gap-1">
                            <i class="bi bi-patch-check-fill"></i>
                            Enterprise / cPanel Ready
                        </div>
                        <p class="small text-muted mt-2 mb-0">Fully normalized using traditional SQL foreign keys, indexes, and optimized query constraints designed for cPanel Shared Hosting packages.</p>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <h5 class="fw-bold mb-2">Automated MySQL Table Builder</h5>
                <p class="text-secondary small">Clicking this will automatically execute full table constructs inside your configured MySQL database server.</p>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo get_csrf_token(); ?>">
                    <button type="submit" name="install_mysql" class="btn btn-dark"><i class="bi bi-play-circle me-1"></i> Auto-Install SQL Structs</button>
                </form>
            </div>

            <div>
                <h5 class="fw-bold mb-2">Manual phpMyAdmin / SQL Import Script</h5>
                <p class="text-secondary small">For custom hosts like Hostinger or generic cPanel instances, you can copy the full normalized SQL database creation script below, paste it into your phpMyAdmin query window, and click Go.</p>
                <div class="position-relative">
                    <pre class="bg-dark text-light p-3 rounded-3 overflow-auto mono text-start mb-0" style="font-size: 0.82rem; max-height: 250px;"><?php echo s($mysql_schema); ?></pre>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
render_site_footer();
?>
